package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local Run,D=require('abyss_run'),require('abyss_data')
for _,c in ipairs({{id='burning_blood',hp=26,max=80},{id='black_blood',hp=32,max=80},{id='meat_on_the_bone',hp=38,max=80},{id='face_of_cleric',hp=27,max=81}})do
 local r=Run.new(D,42);if c.id~='burning_blood'then assert(Run.obtainRelic(r,c.id))end
 r.hp=20;assert(Run.obtainPotion(r,'smoke_bomb'));assert(Run.startCombat(r,'cultist_solo'))
 local gold,wins=r.gold,r.victories;assert(Run.usePotion(r,1));assert(r.phase=='map' and r.lastResult.outcome=='escaped')
 print('SMOKE '..c.id..' actualHp='..r.hp..' expectedSourceHp='..c.hp..' actualMax='..r.maxHp..' expectedSourceMax='..c.max)
 assert(r.hp==20 and r.maxHp==80,'diagnostic expects current missing callback, not source parity')
 assert(r.gold==gold and r.victories==wins and r.rewards==nil)
end
print('M3_SMOKE_HEALING_DIFFERENCE_CONFIRMED 4 actual public Smoke cases; no source parity claim')
