package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local Run,D,C,View=require('abyss_run'),require('abyss_data'),require('abyss_combat'),require('abyss_relic_view_ui')
local r=Run.new(D,42)
local ids={'letter_opener','kunai','shuriken','ornamental_fan','stone_calendar','captains_wheel','pocketwatch'}
for _,id in ipairs(ids)do assert(Run.obtainRelic(r,id))end
assert(Run.startCombat(r,'cultist_solo'))
local function play(id)
 for _,c in ipairs(r.combat.hand)do if c.cardId==id then assert(Run.play(r,c.uid,1));return end end
 error('probe missing '..id)
end
play('defend');r.combat.enemies[1].hp=1;play('strike');assert(r.phase=='reward')
for _,id in ipairs(ids)do
 print('POST_VICTORY '..id..' counter='..tostring(r.relicCounters[id])..' status='..tostring(View.status(r,id)))
 assert(r.relicCounters[id]~=-1,'unexpected: candidate already clears source victory counter')
end
assert(not Run.finishCombat(r));assert(Run.claimCardReward(r,0));dofile('tests/lua/support/finish_combat_rewards.lua')(r);assert(r.phase=='map')
for _,id in ipairs(ids)do print('POST_ROOM '..id..' counter='..tostring(r.relicCounters[id])..' status='..tostring(View.status(r,id)))end
assert(Run.startCombat(r,'cultist_solo'))
for _,id in ipairs(ids)do print('NEXT_BATTLE '..id..' counter='..tostring(r.combat.relicCounters[id]))end
print('M3_ITEM_POSTVICTORY_PROBE_CONFIRMED seven counters remain visible after victory; next battle resets')
