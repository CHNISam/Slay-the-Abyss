"""Normal-value M2 test using the installed official UI/log runner.

Only readiness observation changes: the game intentionally replaces the bottom
platform HP bar with the real top HUD. All actions, subscription and collection
remain in the installed runner. No game state or saved map is changed here.
"""
import hashlib
import importlib.util
import json
import re
import sys
import time
from pathlib import Path

source=Path('D:/MiliastraTools/genshin-miliastra-mcp/src/playtest_runner.py')
sys.path.insert(0,str(source.parent))
spec=importlib.util.spec_from_file_location('m2_native_runner',source)
backend=importlib.util.module_from_spec(spec)
spec.loader.exec_module(backend)

class TopHudRun(backend.Run):
    def read(self,kind,region=None,scale=None):
        if kind=='game' and region==(0.3,0.88,0.7,1):
            items=super().read(kind,region=(0,0,0.25,0.12),scale=1)
            if any(re.search(r'\d{2,}\s*/\s*\d{2,}',row['text']) for row in items):
                self.result['projectHudReadiness']={'region':[0,0,0.25,0.12],
                    'observedAt':time.time(),'texts':[row['text'] for row in items]}
            return items
        return super().read(kind,region=region,scale=scale)

request=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
assert not request.get('mapPath') and not request.get('luaLive')
assert request['clientScriptLog'] is True
report=json.loads(Path('F:/New folder/.artifacts/m2-session/autoplay-candidate.json').read_text())
run=TopHudRun(request)
run.result.update({'verifiedOfficialSave':request['verifiedOfficialSave'],
    'candidateSha256':report['candidate']['sha256'],'sourceCommit':report['sourceCommit'],
    'normalValues':True,'physicalInputCertified':False,
    'installedRunnerSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'launcher':str(Path(__file__).resolve())})
run.run()
