local UI=require('abyss_map_ui')
local function pair()
 local writes=0
 local icon={alive=true};local ring={alive=true}
 for _,c in ipairs({icon,ring})do function c:SetSizeDelta(w,h)self.size={w,h};writes=writes+1 end end
 local box={GetChild=function(_,n)return n=='icon' and icon or ring end}
 return {box=box,size=44,scale=.5}, {box=box,size=44,scale=.83},icon,ring,function()return writes end
end
for _,mode in ipairs({'false','throw'})do
 local a,b,icon,ring,count=pair();UI.paintRoom(a)
 local setter=icon.SetSizeDelta;local attempts=0
 icon.SetSizeDelta=function(self,w,h)
  attempts=attempts+1;setter(self,w,h)
  if attempts==1 then if mode=='throw' then error('setter interrupted after mutation')else return false end end
 end
 local ok=pcall(UI.paintRoom,b)
 assert(ok==(mode=='false'))
 UI.paintRoom(a)
 assert(attempts==2,'old owner promise revived after '..mode)
 assert(math.abs(icon.size[1]-a.size*require('abyss_map_layout').sts.iconPerScale*UI.drawScale(a))<1e-8)
 UI.paintRoom(a);assert(attempts==2)
 print('PASS owner recovery after '..mode..' setter mutates native state')
end
local a,b,icon=pair();UI.paintRoom(a)
local function up(fn,wanted)
 for i=1,20 do local name,value=debug.getupvalue(fn,i);if not name then break end;if name==wanted then return value end end
 error('missing upvalue '..wanted)
end
local cache=up(up(UI.paintRoom,'roomSize'),'roomSizes')
assert(getmetatable(cache).__mode=='k','cache must have weak native keys')
local entry=cache[icon];assert(entry and type(entry.owner)=='table' and next(entry.owner)==nil)
assert(entry.control==nil and entry.fx==nil and entry.box==nil,'cache values must not retain native owners')
local retained=setmetatable({icon},{__mode='v'})
a,b,icon,entry=nil,nil,nil,nil
local canCollect=pcall(collectgarbage,'collect')
if canCollect then assert(retained[1]==nil,'weak cache retained retired native key');print('PASS weak native cache releases control')
else print('UNVERIFIED Fengari has no collectgarbage implementation; structural weak-key/no-backreference checks PASS')end
