package.loaded['abyss_battle_render_actors']=dofile('/workspace/cloud-reports/mobile-loading-intent-baseline.lua')
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Theme=require('abyss_theme')
local ui,root=F.fixture();assert(F.start(ui,'ironclad'))
assert(require('abyss_run').startCombat(ui.run,'cultist_solo'));ui:refresh()
local actor=F.actorControl(root:GetChild('battlePanel'),'enemy1')
local icon=actor:GetChild('intentIcon');local original=icon.SetImage;local old=Theme.icon.intent.buff
assert(icon.imageId==old)
local attempts=0
icon.SetImage=function(self,...)
 attempts=attempts+1;original(self,...)
 if attempts==1 then return false end
end
Theme.icon.intent.buff=123456789;ui:update(1/60)
assert(icon.imageId==123456789)
Theme.icon.intent.buff=old;ui:update(1/60)
assert(icon.imageId==old,'failed replacement left old intent promise alive; actual='..icon.imageId..' expected='..old..' attempts='..attempts)
print('INTENT_FAILED_PROMISE_PASS')
