import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve,join} from 'node:path';
const [repo,log,out]=process.argv.slice(2);
const {page}=await import(pathToFileURL(join(repo,'scripts/node-ui-preview.mjs')));
const raw=readFileSync(log,'utf8').split('\n').find(x=>x.startsWith('PARITY_SCENES '));
if(!raw)throw Error('No current Host scene output');
const scenes=JSON.parse(raw.slice('PARITY_SCENES '.length));
function arrays(node){
  if(!Array.isArray(node.children))node.children=[];
  for(const child of node.children)arrays(child);
}
mkdirSync(out,{recursive:true});
for(const scene of scenes){arrays(scene.tree);writeFileSync(join(out,scene.name+'.html'),page(scene.tree));}
writeFileSync(join(out,'provenance.json'),JSON.stringify({sourceLog:resolve(log),sourceRepo:resolve(repo),scenes:scenes.map(s=>s.name),boundary:'Actual Host mock state and generated control geometry; browser system font and stand-in glyphs, not official native or physical device evidence.'},null,2));
