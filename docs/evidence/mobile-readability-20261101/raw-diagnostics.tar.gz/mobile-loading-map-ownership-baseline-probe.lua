package.loaded['abyss_map_ui']=dofile('/workspace/cloud-reports/mobile-loading-map-baseline.lua')
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Map,UI=require('abyss_map'),require('abyss_map_ui')
local root=F.control({children=require('abyss_map_controls').controls})
local first=Map.generate(F.Data,42)
local ui=UI.new(root,first,function()end,'click',{imageSource='static',color=function(r,g,b,a)return {r=r,g=g,b=b,a=a}end})
local function check(label)
 for _,fx in ipairs(ui.activeFx)do if fx.visible then
  local expected=fx.size*require('abyss_map_layout').sts.iconPerScale*UI.drawScale(fx)
  local actual=fx.box:GetChild('icon').size[1]
  assert(math.abs(actual-expected)<1e-8,label..' stale room size actual='..actual..' expected='..expected)
 end end
end
ui:update(.1);check('first')
for seed=1,10 do
 ui.map=Map.generate(F.Data,seed);ui:render();check('new '..seed)
 ui.map=first;ui:render();check('return '..seed)
 ui:update(.1);check('update '..seed)
end
print('MAP_OWNERSHIP_PROBE_PASS')
