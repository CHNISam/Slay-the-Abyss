local MapUI=require('abyss_map_ui')
local Actors=require('abyss_battle_render_actors')
local Theme=require('abyss_theme')
local function control()
 local state={textWrites=0,imageWrites=0,sizeWrites=0}
 local c={SetVisible=function()end,SetAnchoredPosition=function()end}
 function c:SetSizeDelta(w,h)
  state.sizeWrites=state.sizeWrites+1
  if state.failSize then state.failSize=false;return false end
  state.width,state.height=w,h
 end
 function c:SetImage(source,id)
  state.imageWrites=state.imageWrites+1
  if state.failImage then state.failImage=false;return false end
  state.source,state.image=source,id
 end
 return setmetatable(c,{__index=function(_,k)
  if k=='text' then error('native text readback must not be needed')end
 end,__newindex=function(self,k,v)
  if k=='text'then
   state.textWrites=state.textWrites+1
   state.text=v
   if state.failText then state.failText=false;error('one rejected text write after mutation')end
  else rawset(self,k,v)end
 end}),state
end
local function box()
 local children,states={},{}
 for _,name in ipairs({'icon','ring','intentIcon','intent','intentHit','intentBadge','intentExtra','intentLabel'})do children[name],states[name]=control()end
 return {GetChild=function(_,name)return assert(children[name])end},children,states
end

local b,children,states=box()
local draw=Actors.install({}, {}, {platform={imageSource='static'}},{picture=function(c,id)return c:SetImage('static',type(id)=='table' and id.id or id)end,tint=function()end,ink=function()end}).renderEnemyIntent
draw(b,{kind='attack',value='6'},100,nil,true,1)
states.intent.failText=true
assert(not pcall(draw,b,{kind='attack',value='7'},100,nil,true,1))
draw(b,{kind='attack',value='6'},100,nil,true,1)
assert(states.intent.text=='6','failed text replacement preserved stale promise; actual='..states.intent.text)
print('INTENT_TEXT_FAILED_PROMISE_PASS')
