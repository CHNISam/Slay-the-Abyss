import json,sys,pathlib
from playwright.sync_api import sync_playwright
out=pathlib.Path(sys.argv[1]); rows=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
    page=browser.new_page(viewport={'width':1280,'height':720})
    for f in sorted(out.glob('*.html')):
        page.set_content(f.read_text()); page.evaluate('document.fonts.ready');
        clipped=page.locator('.clip').all_text_contents()
        page.screenshot(path=str(out/(f.stem+'.png')))
        page.set_viewport_size({'width':844,'height':390})
        page.add_style_tag(content='#c{transform:scale(0.5416666666666666);transform-origin:top left}body{overflow:hidden}')
        page.screenshot(path=str(out/(f.stem+'-landscape.png')))
        page.set_viewport_size({'width':1280,'height':720})
        rows.append({'scene':f.stem,'clipped':clipped})
    browser.close()
(out/'text-fit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print(json.dumps(rows,ensure_ascii=False))
