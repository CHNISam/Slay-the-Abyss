-- Pinned319009 facts and pure-data plans. The core owns all effects/choices.
local M={}
local Actors=require('abyss_actor')
local MAX=2147483647
local function copy(v,path)
 local kind=type(v)
 if kind~='table'then assert(kind=='nil'or kind=='string'or kind=='boolean'or kind=='number'and v==v and math.abs(v)<math.huge,'non-data final card field');return v end
 path=path or {};assert(not getmetatable(v)and not path[v],'non-plain or cyclic final card data');path[v]=true
 local t={};for k,x in pairs(v)do assert(type(k)=='string'or type(k)=='number','invalid final card key');t[k]=copy(x,path)end;path[v]=nil;return t
end
local function int(v,min)assert(type(v)=='number'and v==v and v%1==0 and v>=(min or 0)and v<=MAX,'invalid Watcher final amount');return v end
local function e(op,n,extra)local a=extra or {};a.op=op;if n~=nil then a.value=n end;return a end
local function power(id,n)return e('gainWatcherFinalPower',n or 1,{status=id})end
local function make(id,n,pile,extra)local x=extra or {};x.cardId=id;x.pile=pile or 'draw';x.upgraded=x.upgraded==true;x.randomSpot=x.pile=='draw' or nil;return e('watcherFinalGenerate',n or 1,x)end
local specs={
 {'foreign_influence','ForeignInfluence','异界之援','skill','uncommon',0,{e('watcherFinalForeignInfluence',0)},{e('watcherFinalForeignInfluence',1)},{exhaust=true}},
 {'conclude','Conclude','终结','attack','uncommon',1,{e('damageAll',12),e('watcherFinalEndTurnEarly',1)},{e('damageAll',16),e('watcherFinalEndTurnEarly',1)}},
 {'meditate','Meditate','冥想','skill','uncommon',1,{e('watcherFinalMeditate',1),e('changeStance',nil,{stance='Calm'}),e('watcherFinalEndTurnEarly',1)},
  {e('watcherFinalMeditate',2),e('changeStance',nil,{stance='Calm'}),e('watcherFinalEndTurnEarly',1)}},
 {'swivel','Swivel','旋转','skill','uncommon',2,{e('block',8),power('free_attack')},{e('block',11),power('free_attack')}},
 {'wave_of_the_hand','WaveOfTheHand','挥手','skill','uncommon',1,{power('wave_of_the_hand',1)},{power('wave_of_the_hand',2)}},
 {'foresight','Wireheading','预见','power','uncommon',1,{power('foresight',3)},{power('foresight',4)}},
 {'alpha','Alpha','阿尔法','skill','rare',1,{make('beta')},nil,{exhaust=true,upgradeFlags={innate=true}}},
 {'blasphemy','Blasphemy','渎神','skill','rare',1,{e('changeStance',nil,{stance='Divinity'}),power('end_turn_death')},nil,{exhaust=true,upgradeFlags={selfRetain=true}}},
 {'conjure_blade','ConjureBlade','化剑为犁','skill','rare',-1,{e('watcherFinalConjureBlade',0)},{e('watcherFinalConjureBlade',1)},{costMode='all_energy',exhaust=true,experimental=true}},
 {'deus_ex_machina','DeusExMachina','机械降神','skill','rare',-2,{},nil,{exhaust=true,onDrawFinal={op='watcherFinalDeusExMachina',value=2},upgradeFlags={onDrawFinal={op='watcherFinalDeusExMachina',value=3}}}},
 {'deva_form','DevaForm','天人形态','power','rare',3,{power('deva_form')},nil,{ethereal=true,upgradeFlags={ethereal=false}}},
 {'judgment','Judgement','审判','skill','rare',1,{e('watcherFinalJudgment',30)},{e('watcherFinalJudgment',40)}},
 {'lesson_learned','LessonLearned','修习','attack','rare',2,{e('watcherFinalLessonLearned',10)},{e('watcherFinalLessonLearned',13)},{exhaust=true}},
 {'master_reality','MasterReality','创造现实','power','rare',1,{power('master_reality')},nil,{upgradeFlags={cost=0}}},
 {'omniscience','Omniscience','全知','skill','rare',4,{e('watcherFinalOmniscience',2)},nil,{exhaust=true,upgradeFlags={cost=3}}},
 {'ragnarok','Ragnarok','诸神黄昏','attack','rare',3,{e('watcherFinalRagnarok',5,{times=5})},{e('watcherFinalRagnarok',6,{times=6})}},
 {'spirit_shield','SpiritShield','精神护盾','skill','rare',2,{e('watcherFinalSpiritShield',3)},{e('watcherFinalSpiritShield',4)}},
 {'wish','Wish','许愿','skill','rare',3,{e('watcherFinalWish',0)},{e('watcherFinalWish',1)},{exhaust=true,sourceTags={HEALING=true}}},
 {'establishment','Establishment','确立基础','power','rare',1,{power('establishment')},nil,{upgradeFlags={innate=true}}},
 {'vault','Vault','腾跃','skill','rare',3,{e('watcherFinalSkipEnemiesTurn',1),e('watcherFinalEndTurnEarly',1)},nil,{exhaust=true,upgradeFlags={cost=2}}},
}
local text={
 foreign_influence={'从3张随机攻击中选择1张加入手牌。消耗。','从3张随机攻击中选择1张加入手牌，本回合费用为0。消耗。'},
 conclude={'对所有敌人造成12点伤害。结束你的回合。','对所有敌人造成16点伤害。结束你的回合。'},
 meditate={'从弃牌堆取回1张牌并保留。进入平静。结束你的回合。','从弃牌堆取回2张牌并保留。进入平静。结束你的回合。'},
 swivel={'获得8点格挡。你的下一张攻击免费。','获得11点格挡。你的下一张攻击免费。'},
 wave_of_the_hand={'本回合每当你获得格挡，对所有敌人施加1层虚弱。','本回合每当你获得格挡，对所有敌人施加2层虚弱。'},
 foresight={'每回合开始时占卜3。','每回合开始时占卜4。'},
 alpha={'将1张贝塔随机放入抽牌堆。消耗。','先天。将1张贝塔随机放入抽牌堆。消耗。'},
 blasphemy={'进入神格。下回合开始时失去99999生命。消耗。','保留。进入神格。下回合开始时失去99999生命。消耗。'},
 conjure_blade={'消耗所有能量。将1张可攻击X次的终结随机放入抽牌堆。消耗。','消耗所有能量。将1张可攻击X+1次的终结随机放入抽牌堆。消耗。'},
 deus_ex_machina={'不能打出。抽到时消耗本牌，将2张奇迹加入手牌。','不能打出。抽到时消耗本牌，将3张奇迹加入手牌。'},
 deva_form={'虚无。之后每回合恢复能量时获得递增能量，首次1点，逐回合加1。','之后每回合恢复能量时获得递增能量，首次1点，逐回合加1。'},
 judgment={'若目标生命不高于30，将其生命置为0。','若目标生命不高于40，将其生命置为0。'},
 lesson_learned={'造成10点伤害。若本次击杀非仆从，随机升级永久牌组中的1张牌。消耗。','造成13点伤害。若本次击杀非仆从，随机升级永久牌组中的1张牌。消耗。'},
 master_reality={'本场战斗中新生成的非状态、非诅咒牌获得升级。','本场战斗中新生成的非状态、非诅咒牌获得升级。'},
 omniscience={'从抽牌堆选1张牌，免费打出2次，然后消耗原牌。消耗。','从抽牌堆选1张牌，免费打出2次，然后消耗原牌。消耗。'},
 ragnarok={'对随机敌人造成5点伤害，共5次。','对随机敌人造成6点伤害，共6次。'},
 spirit_shield={'每有1张其他手牌，获得3点基础格挡。','每有1张其他手牌，获得4点基础格挡。'},
 wish={'选择：获得3力量、25金币或6多层护甲。消耗。','选择：获得4力量、30金币或8多层护甲。消耗。'},
 establishment={'回合结束时，保留的手牌在本场战斗中的费用降低1。','先天。回合结束时，保留的手牌在本场战斗中的费用降低1。'},
 vault={'跳过敌方回合，结束你的回合并开始额外的玩家回合。消耗。','跳过敌方回合，结束你的回合并开始额外的玩家回合。消耗。'},
}
local powers={
 free_attack={'旋转','FreeAttackPower','buff',5,'接下来的攻击免费，每张非purge攻击消耗1层，不在回合末自动消失。'},
 wave_of_the_hand={'挥手','WaveOfTheHandPower','buff',5,'本轮每次格挡正数回调后，对所有敌人施加等同层数的虚弱；轮末移除。'},
 foresight={'预见','WireheadingPower','buff',5,'回合开始时占卜等同层数，抽牌堆空则先洗牌。'},
 end_turn_death={'渎神','EndTurnDeath','buff',5,'下个回合开始时失去99999生命；此为增益而非可用纯净移除的减益。'},
 deva_form={'天人形态','DevaForm','buff',5,'恢复能量时获得当前递增值，之后按层数提高递增值。'},
 master_reality={'创造现实','MasterRealityPower','buff',5,'生成非状态、非诅咒牌的源构造／效果入口调用升级。'},
 establishment={'确立基础','EstablishmentPower','buff',25,'回合末按源顺序安排保留手牌的战斗降费。'},
 omega={'欧米伽','OmegaPower','buff',5,'玩家回合末对全体敌人造成等同层数的无来源反伤类型伤害。'},
 plated_armor={'多层护甲','Plated Armor','buff',5,'回合末获得等同层数的固定格挡；被普通攻击实际伤害后减少1层。'},
}
M.ops={gainWatcherFinalPower=true,watcherFinalForeignInfluence=true,watcherFinalEndTurnEarly=true,watcherFinalMeditate=true,watcherFinalGenerate=true,
 watcherFinalConjureBlade=true,watcherFinalJudgment=true,watcherFinalLessonLearned=true,watcherFinalOmniscience=true,watcherFinalRagnarok=true,watcherFinalSpiritShield=true,watcherFinalWish=true,watcherFinalSkipEnemiesTurn=true,watcherFinalExpungerHits=true}
local function derivative(id,source,name,kind,cost,effects,upgrade,desc,updesc)
 return {id=id,sourceId=source,name=name,color='colorless',type=kind,rarity='special',cost=cost,effects=effects,upgrade=upgrade,text=desc,upgradeText=updesc or desc}
end
function M.withCards(data)
 assert(type(data)=='table'and data.cards and data.cards.cards and data.statuses and data.statuses.statuses,'missing Watcher final data')
 local out,ids,statuses=copy(data),{},{}
 for _,c in ipairs(out.cards.cards)do assert(not ids[c.id],'duplicate input card');ids[c.id]=true end
 for _,s in ipairs(out.statuses.statuses)do assert(not statuses[s.id],'duplicate input status');statuses[s.id]=true end
 local function add(c)assert(not ids[c.id],'Watcher final card already exists: '..c.id);ids[c.id]=true;out.cards.cards[#out.cards.cards+1]=c end
 for _,s in ipairs(specs)do
  local c={id=s[1],sourceId=s[2],sts_name=s[2]=='Wireheading'and 'Foresight'or s[2]=='Judgement'and 'Judgment'or s[2],name=s[3],type=s[4],rarity=s[5],cost=s[6],color='purple',
   effects=copy(s[7]),upgrade={effects=copy(s[8]or s[7])},text=text[s[1]][1],upgradeText=text[s[1]][2]}
  for k,v in pairs(s[9]or {})do if k=='upgradeFlags'then for uk,uv in pairs(v)do c.upgrade[uk]=copy(uv)end else c[k]=copy(v)end end
  add(c)
 end
 local beta=derivative('beta','Beta','贝塔','skill',2,{make('omega')},{cost=1},'将1张欧米伽随机放入抽牌堆。消耗。');beta.exhaust=true;add(beta)
 add(derivative('omega','Omega','欧米伽','power',3,{power('omega',50)},{effects={power('omega',60)}},'回合结束时对所有敌人造成50点伤害。','回合结束时对所有敌人造成60点伤害。'))
 add(derivative('expunger','Expunger','终结','attack',1,{e('watcherFinalExpungerHits',9)},{effects={e('watcherFinalExpungerHits',15)}},'造成9点伤害，次数由生成时的X决定。','造成15点伤害，次数由生成时的X决定。'))
 local opts={
  derivative('become_almighty','BecomeAlmighty','成为神明','power',-2,{e('gainStatus',3,{status='strength'})},{effects={e('gainStatus',4,{status='strength'})}},'获得3力量。','获得4力量。'),
  derivative('fame_and_fortune','FameAndFortune','名利双收','skill',-2,{e('gainGold',25)},{effects={e('gainGold',30)}},'获得25金币。','获得30金币。'),
  derivative('live_forever','LiveForever','长生不老','power',-2,{power('plated_armor',6)},{effects={power('plated_armor',8)}},'获得6多层护甲。','获得8多层护甲。'),
 }
 for _,c in ipairs(opts)do c.optionOnly=true;add(c)end
 if not ids.miracle then
  local c=derivative('miracle','Miracle','奇迹','skill',0,{e('energy',1)},{effects={e('energy',2)}},'保留。获得1能量。消耗。','保留。获得2能量。消耗。');c.selfRetain=true;c.exhaust=true;add(c)
 end
 for _,id in ipairs({'free_attack','wave_of_the_hand','foresight','end_turn_death','deva_form','master_reality','establishment','omega','plated_armor'})do
  local s=powers[id];assert(not statuses[id],'Watcher final status already exists: '..id)
  out.statuses.statuses[#out.statuses.statuses+1]={id=id,sourceId=s[2],name=s[1],kind=s[3],priority=s[4],stack=(id=='end_turn_death'or id=='master_reality')and 'none'or 'intensity',decay='none',description=s[5]}
 end
 return out
end
local function plan()return {top={},bottom={},immediate={},updates={},consumeAllEnergy=false}end
local function amount(s,id)assert(powers[id],'unknown Watcher final Power');return int(s.player.statuses[id]or 0)end
local function action(p,a,where)p[where or 'bottom'][#p[where or 'bottom']+1]=a end
local function target(context)local t=context and context.target;assert(t and type(t.id)=='string','missing final target');return t end
function M.adaptDefinition(state,instance,definition)
 local out=copy(definition)
 if instance.exhaust~=nil then assert(type(instance.exhaust)=='boolean','invalid instance exhaust');out.exhaust=instance.exhaust end
 if instance.cardId=='spirit_shield'then
  local count=0;for _,c in ipairs(state.hand)do if c~=instance and c.uid~=instance.uid then count=count+1 end end
  out.effects={e('block',count*(instance.upgraded and 4 or 3))}
 elseif instance.cardId=='expunger'then out.effects={e('watcherFinalExpungerHits',instance.upgraded and 15 or 9,{times=int(instance.expungerHits or 0)})}end
 return out
end
function M.prepareEffect(state,effect,context)
 assert(type(effect)=='table'and M.ops[effect.op],'unknown Watcher final effect');local out=copy(effect)
 if effect.value~=nil then int(effect.value)end
 if effect.op=='watcherFinalLessonLearned'then local t=target(context);out.normalAmount=int(Actors.attackAmount(state,state.player,t,effect.value));out.targetId=t.id
 elseif effect.op=='watcherFinalRagnarok'then int(effect.times,1) -- damage/target are recalculated for every random hit, not here.
 elseif effect.op=='watcherFinalSpiritShield'then
  local using=context and context.instance;local count=0
  for _,c in ipairs(state.hand)do if not using or c.uid~=using.uid then count=count+1 end end
  out.baseBlock=int(count*effect.value)
 elseif effect.op=='watcherFinalConjureBlade'then
  local energy=context and context.energyOnUse;if energy==nil or energy==-1 then energy=state.energy end
  out.energyOnUse=int(energy);out.freeToPlayOnce=context and context.freeToPlayOnce==true or false
  out.chemicalX=context and context.chemicalX==true or false
 end
 return out
end
function M.planEffect(state,effect,context)
 assert(type(effect)=='table'and M.ops[effect.op],'unknown Watcher final effect');context=context or {};local p=plan()
 if effect.op=='gainWatcherFinalPower'then
  assert(powers[effect.status],'unknown Watcher final Power');int(effect.value,1)
  action(p,e('applyWatcherFinalPower',effect.value,{status=effect.status,targetId=state.player.id}))
 elseif effect.op=='watcherFinalForeignInfluence'then
  action(p,e('foreignInfluenceChoice',3,{zeroCostForTurn=effect.value==1,poolContract='full_CardLibrary_attack_nonhealing_unlocked',
   rarityRng='cardRandomRng',shuffleRng='cardRandomRng',selectionRng='cardRng',selectionSort='sourceId_Java_compareTo',
   rarityRoll={common=55,uncommon=30,rare=15},uniqueBy='sourceId'}))
 elseif effect.op=='watcherFinalEndTurnEarly'then action(p,e('pressEndTurnEarly',1))
 elseif effect.op=='watcherFinalMeditate'then action(p,e('pileChoiceFinal',int(effect.value,1),{mode='meditate',source='discard',destination='hand',optional=false}))
 elseif effect.op=='watcherFinalGenerate'then action(p,copy(effect))
 elseif effect.op=='watcherFinalConjureBlade'then
  local energy=int(effect.energyOnUse);local hits=energy+int(effect.value)+(effect.chemicalX and 2 or 0);int(hits)
  action(p,make('expunger',1,'draw',{instanceFields={expungerHits=hits}}));p.consumeAllEnergy=not effect.freeToPlayOnce
 elseif effect.op=='watcherFinalJudgment'then
  local t=target(context);if t.hp<=int(effect.value)then action(p,e('instantKill',0,{targetId=t.id,sourceIsNil=true}),'top')end
 elseif effect.op=='watcherFinalLessonLearned'then
  local t=target(context);action(p,e('lessonDamageAndUpgrade',int(effect.normalAmount),{targetId=t.id,rng='miscRng',excludeHalfDead=true,excludeMinion=true,upgradeBeforeVictoryClear=true}))
 elseif effect.op=='watcherFinalOmniscience'then action(p,e('pileChoiceFinal',1,{mode='omniscience',source='draw',destination='autoplay',playAmount=int(effect.value,1),optional=false}))
 elseif effect.op=='watcherFinalRagnarok'then
  for _=1,int(effect.times,1)do action(p,e('randomAttackRecalculate',int(effect.value),{rng='cardRandomRng',sourceCardUid=context.instance and context.instance.uid}))end
 elseif effect.op=='watcherFinalSpiritShield'then action(p,e('block',int(effect.baseBlock)))
 elseif effect.op=='watcherFinalWish'then action(p,e('optionChoiceFinal',1,{mode='wish',upgraded=effect.value==1,optionIds={'become_almighty','fame_and_fortune','live_forever'},optional=false}))
 elseif effect.op=='watcherFinalSkipEnemiesTurn'then action(p,e('setSkipMonsterTurn',1))
 elseif effect.op=='watcherFinalExpungerHits'then
  for _=1,int(effect.times or 0)do action(p,e('damage',int(effect.value),{targetId=target(context).id}))end
 end
 return p
end
function M.planHook(state,id,hook,context)
 local p=plan();local n=amount(state,id);if n==0 then return p end;context=context or {}
 if id=='foresight'and hook=='turn_start'then
  if #state.draw==0 then action(p,e('shuffleEmptyDraw',1),'top')end;action(p,e('scry',n))
 elseif id=='end_turn_death'and hook=='turn_start'then
  action(p,e('loseHp',99999,{targetId=state.player.id,sourceId=state.player.id}));action(p,e('removeWatcherFinalPower',nil,{status=id}))
 elseif id=='deva_form'and hook=='energy_recharge'then
  local gain=int(state.devaEnergyGain or 1,1);action(p,e('energy',gain),'immediate');p.updates.devaEnergyGain=int(gain+n,1)
 elseif id=='establishment'and hook=='turn_end'then action(p,e('discountRetainedFinal',n))
 elseif id=='omega'and hook=='turn_end'and context.isPlayer~=false then action(p,e('damageAll',n,{damageType='THORNS',sourceIsNil=true,fixed=true}))
 elseif id=='wave_of_the_hand'and hook=='round_end'then action(p,e('removeWatcherFinalPower',nil,{status=id}))
 elseif id=='plated_armor'and hook=='turn_end_pre_cards'then action(p,e('block',n,{fixed=true}))end
 return p
end
function M.planPowerApplied(state,id,value)
 assert(powers[id],'unknown Watcher final Power');int(value,1);local p=plan()
 if id=='deva_form'then p.updates.devaEnergyGain=amount(state,id)>0 and int((state.devaEnergyGain or 1)+1,1)or 1 end
 if id=='plated_armor'then local old=amount(state,id);p.updates.plated_armor=old>0 and math.min(999,old+value)or value end
 return p
end
function M.planUseCard(state,card)
 local p=plan();local n=amount(state,'free_attack')
 if n>0 and card.type=='attack'and not card.purgeOnUse and not card.dontTriggerOnUseCard then
  p.updates.free_attack=n-1
  if n==1 then action(p,e('removeWatcherFinalPower',nil,{status='free_attack'}),'top')end
 end
 return p
end
function M.freeAttack(state,card)return card.type=='attack'and amount(state,'free_attack')>0 end
function M.planGainedBlock(state,floatBeforeMonsterModifiers)
 assert(type(floatBeforeMonsterModifiers)=='number'and floatBeforeMonsterModifiers==floatBeforeMonsterModifiers and math.abs(floatBeforeMonsterModifiers)<math.huge,'invalid block callback')
 local p=plan();local n=amount(state,'wave_of_the_hand')
 if floatBeforeMonsterModifiers>0 and n>0 then
  for _,enemy in ipairs(state.enemies)do action(p,e('applyStatus',n,{status='weak',targetId=enemy.id,isSourceMonster=false}))end
 end
 return p
end
function M.planHpLost(state,context)
 local p=plan();local n=amount(state,'plated_armor')
 if n>0 and context.damageType=='NORMAL'and context.damage>0 and context.sourceId and context.sourceId~=state.player.id then
  action(p,e('reduceWatcherFinalPower',1,{status='plated_armor'}))
 end
 return p
end
function M.planDrawn(state,instance)
 local p=plan();if instance.cardId~='deus_ex_machina'then return p end
 action(p,e('exhaustSpecificFinal',1,{uid=int(instance.uid,1),source='hand'}),'top')
 action(p,make('miracle',instance.upgraded and 3 or 2,'hand'),'top')
 return p -- top is desired execution order; host must reverse-push.
end
function M.planRetainDiscount(state,instance,bareDefinition)
 local n=amount(state,'establishment');if n==0 or not(instance.retain or bareDefinition.selfRetain)then return nil end
 local base=int(instance.combatCost~=nil and instance.combatCost or bareDefinition.cost,-2)
 local turn=int(instance.turnCost~=nil and instance.turnCost or base,-2)
 if turn>0 then local nextCost=math.max(0,turn-n);return {uid=instance.uid,combatCost=nextCost,turnCost=nextCost}
 elseif base>=0 then return {uid=instance.uid,combatCost=math.max(0,base-n),turnCost=0}end
 return nil
end
function M.planMeditateChoice(state,uids,autoAll)
 assert(type(uids)=='table','invalid Meditate selection');local p=plan();local seen,space={},10-#state.hand
 for _,uid in ipairs(uids)do
  int(uid,1);assert(not seen[uid],'duplicate Meditate UID');seen[uid]=true
  local c;for _,candidate in ipairs(state.discard)do if candidate.uid==uid then c=candidate end end;assert(c,'Meditate UID not in discard')
  local canMove=space>0;if canMove then space=space-1 end
  p.updates[#p.updates+1]={uid=uid,retain=(autoAll==true or canMove)and true or nil,moveToHand=canMove,handHook=false}
 end
 return p
end
function M.planOmniscienceChoice(state,uid,playAmount)
 int(uid,1);int(playAmount,1);local selected
 for _,c in ipairs(state.draw)do if c.uid==uid then selected=c end end;assert(selected,'Omniscience UID not in draw')
 local p=plan();p.move={uid=uid,from='draw',to='limbo',handHook=false,drawHook=false,instanceFields={exhaust=true}}
 for i=1,playAmount do action(p,e('queueFinalAuto',1,{uid=uid,copy=i>1,copyMode=i>1 and 'statEquivalentNewSource' or nil,
  autoplayCard=true,randomTarget=true,purgeOnUse=i>1,exhaustOnUseOnce=false,sourceExhaust=true,immediate=false,energySnapshot='enqueue_action_execution'}))end
 return p
end
function M.planLessonResult(targetActor,permanentCandidates)
 assert(type(permanentCandidates)=='table','missing master deck upgrade candidates');local p=plan()
 local dead=targetActor.isDying or targetActor.hp<=0
 if dead and not targetActor.halfDead and not(targetActor.statuses and(targetActor.statuses.minion or 0)~=0)and not targetActor.isMinion and #permanentCandidates>0 then
  action(p,e('upgradePermanentRandom',1,{rng='miscRng',candidateKeys=copy(permanentCandidates),beforeVictoryClear=true}))
 end
 return p
end
function M.planGenerated(state,card,stage)
 assert(stage=='hand_action_constructor'or stage=='hand_effect'or stage=='discard_effect'or stage=='draw_action_update','unsupported generation stage')
 local p=plan()
 if amount(state,'master_reality')>0 and card.type~='status'and card.type~='curse'then action(p,e('upgradeGeneratedFinal',1,{stage=stage}))end
 return p
end
function M.wishChoices(upgraded)
 assert(type(upgraded)=='boolean','invalid Wish upgrade');local n=upgraded and 1 or 0
 return {
  {id='become_almighty',sourceId='BecomeAlmighty',upgraded=upgraded,effects={e('gainStatus',3+n,{status='strength'})}},
  {id='fame_and_fortune',sourceId='FameAndFortune',upgraded=upgraded,effects={e('gainGold',25+n*5)}},
  {id='live_forever',sourceId='LiveForever',upgraded=upgraded,effects={power('plated_armor',6+n*2)}},
 }
end
function M.planWishChoice(id,upgraded)
 for _,option in ipairs(M.wishChoices(upgraded))do if option.id==id then local p=plan();p.bottom=copy(option.effects);return p end end
 error('invalid Wish option')
end
return M
