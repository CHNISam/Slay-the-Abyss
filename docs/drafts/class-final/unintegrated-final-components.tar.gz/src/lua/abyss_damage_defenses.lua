-- Shared receive-stage adapter. Source semantics remain owned by the existing
-- Silent/Defect Final helpers; this module does not implement a second Buffer.
local M={intangiblePriority=75}
local MAX=2147483647
local kinds={NORMAL=true,THORNS=true,HP_LOSS=true}
local function integer(n)return type(n)=='number'and n==n and n%1==0 and n>=0 and n<=MAX end
local function amount(n)assert(integer(n),'invalid incoming damage amount');return n end
local function actor(owner)
 assert(type(owner)=='table'and getmetatable(owner)==nil and type(owner.statuses)=='table','invalid incoming damage actor')
 amount(owner.hp);amount(owner.block or 0);return owner
end
local function info(record)
 assert(type(record)=='table'and getmetatable(record)==nil,'invalid incoming damage info')
 assert(kinds[record.type],'explicit source damage type required')
 actor(record.target);if record.owner~=nil then actor(record.owner)end
 return record
end
function M.info(owner,target,damageType)
 return info({owner=owner,target=target,type=damageType})
end
-- Call after attack/final-receive arithmetic, BEFORE Block is consumed. Source
-- Player.damage repeats the Intangible cap for all NORMAL/THORNS/HP_LOSS types.
function M.beforeBlock(state,record,value)
 assert(type(state)=='table','missing damage state');actor(state.player)
 info(record);amount(value)
 return require('abyss_silent_final_cards').capIncomingDamage(state,record.target,value)
end
-- Call at onAttackedToChangeDamage/onAttacked stage, after actual Block. The
-- existing Defect helper owns Buffer consumption and StaticDischarge plans.
function M.afterBlock(state,record,value)
 assert(type(state)=='table','missing damage state');actor(state.player)
 info(record);amount(value)
 return require('abyss_defect_final_cards').incomingPlan(state,record,value)
end
-- Pure composition/preview. Never assign Block, HP, Power stacks or queue here.
-- Hosts already consuming Block should call the two stage adapters instead.
function M.planHit(state,record,value)
 info(record);amount(value)
 local before=M.beforeBlock(state,record,value)
 local block=record.target.block or 0
 local blocked=record.type=='HP_LOSS'and 0 or math.min(before,block)
 local postBlock=before-blocked
 local after=M.afterBlock(state,record,postBlock)
 return {raw=value,beforeBlock=before,blocked=blocked,blockAfter=block-blocked,
  postBlock=postBlock,amount=after.amount,top=after.top,bottom=after.bottom}
end
-- Source queues reactions before HP deduction. Execute them only after the
-- entire hit and death/outcome checks; never allow a dead player's channel.
function M.mayExecuteQueued(state)
 assert(type(state)=='table'and type(state.player)=='table','missing damage state')
 if state.player.hp<=0 or(state.phase~='player'and state.phase~='enemy')then return false end
 for _,enemy in ipairs(state.enemies or {})do if enemy.hp>0 and not enemy.escaped then return true end end
 return false
end
-- Buffer must reduce between distinct DamageActions, not after a whole times
-- loop. Static Discharge also needs the real queue rather than inline channel.
function M.needsQueue(state,record)
 local statuses=actor(state.player).statuses
 local buffer,static=statuses.buffer,statuses.static_discharge
 if buffer~=nil then amount(buffer);return true end
 if static~=nil then amount(static)end
 if not static or static==0 then return false end
 if record then info(record);return record.target==state.player and record.type=='NORMAL'and record.owner~=nil and record.owner~=state.player end
 return true
end
return M
