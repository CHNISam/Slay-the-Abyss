-- Final Silent definitions and source action contracts, pinned STS1 319009.
-- Plans are pure data; shared Combat owns identity, selections and auto play.
local M={}
M.ops={distraction=true,setup=true,bulletTime=true,doppelganger=true,nightmare=true,alchemize=true,gainSilentFinalPower=true}
local MAX=2147483647
local function integer(n)return type(n)=='number'and n==n and n%1==0 and n>=0 and n<=MAX end
local function check(n)assert(integer(n),'invalid Silent final integer');return n end
local function copy(x)if type(x)~='table'then return x end;local y={};for k,v in pairs(x)do y[k]=copy(v)end;return y end
local function e(op,value,extra)local t=extra or {};t.op=op;t.value=value;return t end
local function power(id,n)return e('gainSilentFinalPower',n,{status=id})end
local defs={
 {id='distraction',sourceId='Distraction',name='声东击西',type='skill',rarity='uncommon',cost=1,exhaust=true,effects={e('distraction',1)},upgrade={cost=0},text='随机获得一张技能牌。本回合该牌费用为0。消耗。'},
 {id='endless_agony',sourceId='Endless Agony',name='无尽苦痛',type='attack',rarity='uncommon',cost=0,exhaust=true,effects={e('damage',4)},upgrade={effects={e('damage',6)}},text='造成4点伤害。抽到此牌时，获得一张复制。消耗。',upgradeText='造成6点伤害。抽到此牌时，获得一张复制。消耗。'},
 {id='masterful_stab',sourceId='Masterful Stab',name='精巧刺击',type='attack',rarity='uncommon',cost=0,effects={e('damage',12)},upgrade={effects={e('damage',16)}},text='造成12点伤害。本场战斗每次受到生命伤害，此牌费用增加1。',upgradeText='造成16点伤害。本场战斗每次受到生命伤害，此牌费用增加1。'},
 {id='setup',sourceId='Setup',name='计划',type='skill',rarity='uncommon',cost=1,effects={e('setup',1)},upgrade={cost=0},text='将一张手牌放在抽牌堆顶。若其基础费用大于0，下次打出免费。'},
 {id='well_laid_plans',sourceId='Well Laid Plans',name='早有计划',type='power',rarity='uncommon',cost=1,effects={power('well_laid_plans',1)},upgrade={effects={power('well_laid_plans',2)}},text='回合结束时可以保留至多1张牌。',upgradeText='回合结束时可以保留至多2张牌。'},
 {id='bullet_time',sourceId='Bullet Time',name='子弹时间',type='skill',rarity='rare',cost=3,effects={e('bulletTime',1)},upgrade={cost=2},text='本回合不能抽牌。当前所有非X且可打出手牌的本回合费用变为0。'},
 {id='burst',sourceId='Burst',name='爆发',type='skill',rarity='rare',cost=1,effects={power('burst',1)},upgrade={effects={power('burst',2)}},text='本回合下一张技能牌打出两次。',upgradeText='本回合下两张技能牌打出两次。'},
 {id='corpse_explosion',sourceId='Corpse Explosion',name='尸爆',type='skill',rarity='rare',cost=2,effects={e('applyStatus',6,{status='poison'}),e('applyStatus',1,{status='corpse_explosion'})},upgrade={effects={e('applyStatus',9,{status='poison'}),e('applyStatus',1,{status='corpse_explosion'})}},text='给予6层中毒。此敌人死亡时，对所有敌人造成等同其最大生命值的伤害。',upgradeText='给予9层中毒。此敌人死亡时，对所有敌人造成等同其最大生命值的伤害。'},
 {id='doppelganger',sourceId='Doppelganger',name='分身',type='skill',rarity='rare',cost=-1,costMode='all_energy',experimental=true,exhaust=true,effects={e('doppelganger',0)},upgrade={effects={e('doppelganger',1)}},text='下一回合额外获得X能量并抽X张牌。消耗。',upgradeText='下一回合额外获得X+1能量并抽X+1张牌。消耗。'},
 {id='nightmare',sourceId='Nightmare',name='噩梦',type='skill',rarity='rare',cost=3,exhaust=true,effects={e('nightmare',3)},upgrade={cost=2},text='选择一张手牌。下一回合获得其3张复制。消耗。'},
 {id='phantasmal_killer',sourceId='Phantasmal Killer',name='幻影杀手',type='skill',rarity='rare',cost=1,effects={power('phantasmal',1)},upgrade={cost=0},text='下一回合你的普通攻击伤害翻倍。'},
 {id='tools_of_the_trade',sourceId='Tools of the Trade',name='必备工具',type='power',rarity='rare',cost=1,effects={power('tools_of_the_trade',1)},upgrade={cost=0},text='每回合开始时，额外抽1张牌，再丢弃1张牌。'},
 {id='alchemize',sourceId='Alchemize',name='炼药',type='skill',rarity='rare',cost=1,exhaust=true,tags={'HEALING'},effects={e('alchemize',1)},upgrade={cost=0},text='获得一瓶随机药水。消耗。'},
 {id='wraith_form',sourceId='Wraith Form v2',name='幽魂形态',type='power',rarity='rare',cost=3,effects={power('intangible',2),power('wraith_form',-1)},upgrade={effects={power('intangible',3),power('wraith_form',-1)}},text='获得2回合无实体。每回合结束时失去1点敏捷。',upgradeText='获得3回合无实体。每回合结束时失去1点敏捷。'},
}
local powers={
 {id='well_laid_plans',name='早有计划',kind='buff',stack='intensity',decay='none',priority=5,description='回合结束时，可以选择保留至多等同层数的手牌。'},
 {id='burst',name='爆发',kind='buff',stack='intensity',decay='none',priority=5,description='接下来的技能牌额外打出一次，直到层数耗尽或本回合结束。'},
 {id='corpse_explosion',name='尸爆',kind='debuff',stack='intensity',decay='none',priority=5,description='死亡时，对其余敌人造成最大生命值乘以层数的THORNS伤害。'},
 {id='nightmare',name='噩梦',kind='buff',stack='intensity',decay='none',priority=5,description='下回合抽牌前，获得已选模板对应层数的复制，随后移除。'},
 {id='phantasmal',name='幻影',kind='buff',stack='intensity',decay='none',priority=5,description='下回合开始时获得双倍伤害，再减少1层。'},
 {id='double_damage',name='双倍伤害',kind='buff',stack='intensity',decay='none',priority=6,description='普通伤害翻倍。每轮结束减少1层。'},
 {id='tools_of_the_trade',name='必备工具',kind='buff',stack='intensity',decay='none',priority=25,description='常规抽牌后，额外抽等同层数的牌，再手动丢弃等量牌。'},
 {id='intangible',name='无实体',kind='buff',stack='intensity',decay='none',priority=75,description='所有大于1的伤害及生命损失降为1；普通伤害随后仍由格挡抵消。每轮结束减少1层。'},
 {id='wraith_form',name='幽魂形态',kind='debuff',stack='intensity',decay='none',priority=5,allowNegative=true,description='在玩家回合结束时，失去相应敏捷。此状态的原始层数为负数。'},
}
local powerIds={draw_next_turn=true}
for _,definition in ipairs(powers)do powerIds[definition.id]=true end
function M.withCardDefinitions(data)
 local out=copy(data);local seen={};for _,c in ipairs(out.cards.cards)do seen[c.id]=true end
 for _,c in ipairs(defs)do
  assert(not seen[c.id],'Silent final card collision: '..c.id)
  local card=copy(c);card.sts_name=card.sourceId;card.upgradeText=card.upgradeText or card.text
  out.cards.cards[#out.cards.cards+1]=card;seen[c.id]=true
 end
 seen={};for _,p in ipairs(out.statuses.statuses)do seen[p.id]=true end
 for _,p in ipairs(powers)do if not seen[p.id]then out.statuses.statuses[#out.statuses.statuses+1]=copy(p)end end
 return out
end
-- These two cards require unavailable *complete source pools*, not current
-- implemented subsets. No caller-supplied boolean can certify completeness.
function M.canPlay(_state,card)
 if card.id=='distraction'then return false,'unsupported_complete_skill_pool' end
 if card.id=='alchemize'then return false,'unsupported_complete_potion_pool' end
 return true
end
function M.prepareEffect(_state,effect)
 if effect.op=='distraction'then error('unsupported_complete_skill_pool',0)end
 if effect.op=='alchemize'then error('unsupported_complete_potion_pool',0)end
 return copy(effect)
end
function M.planEffect(state,effect,context)
 context=context or {};local plan={top={},bottom={},consumeAllEnergy=false}
 if effect.op=='setup'then plan.top[1]=e('finalHandChoice',1,{mode='setup'})
 elseif effect.op=='bulletTime'then plan.top={e('applyNoDraw',1),e('zeroHandTurnCosts',0)}
 elseif effect.op=='nightmare'then assert(effect.value==3,'invalid Nightmare copies');plan.top[1]=e('finalHandChoice',1,{mode='nightmare',copies=3})
 elseif effect.op=='doppelganger'then
  assert(effect.value==0 or effect.value==1,'invalid Doppelganger upgrade')
  local n=context.energyOnUse;if n==nil or n==-1 then n=state.energy end;check(n)
  assert(context.chemicalX==nil or context.chemicalX==0 or context.chemicalX==false,'Chemical X not supported')
  assert(context.freeToPlayOnce==nil or type(context.freeToPlayOnce)=='boolean','invalid X free flag')
  n=n+0.0+effect.value;check(n)
  if n>0 then
   plan.bottom={e('nextEnergy',n),power('draw_next_turn',n)}
   plan.consumeAllEnergy=context.freeToPlayOnce~=true
  end
 elseif effect.op=='gainSilentFinalPower'then
  assert(powerIds[effect.status],'unknown Silent final Power')
  if effect.status=='wraith_form'then
   assert(type(effect.value)=='number'and effect.value%1==0 and effect.value<0 and effect.value>=-MAX,'invalid Wraith Form Power')
  else check(effect.value)end
  if effect.constructorAmount~=nil then assert(effect.status=='double_damage'and effect.constructorAmount==1,'invalid constructor amount')end
  plan.top[1]=copy(effect);plan.top[1].op='applyFinalPower'
 elseif effect.op=='distraction' or effect.op=='alchemize'then M.prepareEffect(state,effect)
 else return nil end
 return plan
end
local fields={'cardId','upgraded','combatCost','turnCost','freeToPlayOnce','damageBonus',
 'glassKnifeReduction','storedDiscardCost','shivAccuracyBonus','retainedDamageBonus','retainedBlockBonus','retainedCostReduction','misc'}
function M.copyTemplate(state,instance,resetTurn,sameSource)
 assert(type(instance)=='table' and integer(instance.uid)and instance.uid>0,'invalid copy instance')
 assert(type(resetTurn)=='boolean'and type(sameSource)=='boolean','invalid copy flags')
 assert(state.catalog.cards[instance.cardId],'unknown copy card')
 assert((state.player.statuses.master_reality or 0)==0,'unsupported_copy_MasterReality')
 local out={};for _,field in ipairs(fields)do if instance[field]~=nil then out[field]=copy(instance[field])end end
 if resetTurn then out.turnCost=nil end -- resetAttributes: current turn cost <- base combat cost
 if sameSource then
  assert(integer(instance.sourceUid)and instance.sourceUid>0,'missing sourceUid for same-instance copy')
  out.sourceUid=instance.sourceUid
 end
 return out
end
-- Actual draw only; generated copies do not trigger this hook again.
function M.onDraw(state,instance)
 if instance.cardId~='endless_agony'then return {}end
 return {e('makeStatCardCopy',1,{template=M.copyTemplate(state,instance,false,false)})}
end
-- Source updateCardsOnDamage excludes exhaust, limbo and cardInUse. A positive
-- damage *event*, not each HP point, increases cost by one and preserves diff.
function M.onHpLost(state,owner,amount)
 check(amount);if owner~=state.player or amount==0 then return false end
 local changes,seen={},{}
 for _,name in ipairs({'hand','discard','draw'})do
  for _,instance in ipairs(state[name])do
   if instance.cardId=='masterful_stab'then
    assert(not seen[instance],'duplicate Masterful Stab instance');seen[instance]=true
    local base=instance.combatCost or state.catalog.cards.masterful_stab.cost
    local turn=instance.turnCost or base;check(base);check(turn);check(base+0.0+1);check(turn+0.0+1)
    changes[#changes+1]={card=instance,base=base+1,turn=turn+1}
   end
  end
 end
 for _,change in ipairs(changes)do change.card.combatCost,change.card.turnCost=change.base,change.turn end
 return #changes>0
end
-- Pure onUse plan: host consumes the old Burst immediately, handles TOP removal,
-- and enqueues a real automatic card command after original card actions.
function M.planOnUse(state,card,instance,context)
 context=context or {};local n=state.player.statuses.burst or 0;check(n)
 local plan={top={},bottom={},cardQueue={},consumeBurst=false}
 if card.type~='skill' or instance.purgeOnUse or n==0 then return plan end
 plan.consumeBurst=true
 if n==1 then plan.top[1]=e('removeFinalPower',0,{status='burst'})end
 plan.cardQueue[1]={template=M.copyTemplate(state,instance,false,true),purgeOnUse=true,
  autoplay=true,targetId=context.targetId,energyOnUse=context.energyOnUse or -1}
 return plan
end
-- Selection adapter keeps validation/token/pause/rollback in the shared chooser.
function M.planChoice(state,mode,instance)
 if mode=='setup'then
  local def=assert(state.catalog.cards[instance.cardId]);local cost=instance.combatCost or def.cost
  if instance.upgraded and instance.combatCost==nil and def.upgrade and def.upgrade.cost~=nil then cost=def.upgrade.cost end
  return {e('setupToDrawTop',1,{uid=instance.uid,freeToPlayOnce=cost>0})}
 elseif mode=='nightmare'then
  return {e('returnChoiceHandTop',1,{uid=instance.uid}),e('applyNightmare',3,{template=M.copyTemplate(state,instance,true,false)})}
 end
 error('unknown final choice mode',0)
end
function M.planHook(state,id,hook)
 local n=state.player.statuses[id];if n==nil then return {}end
 if id=='wraith_form'then assert(type(n)=='number'and n%1==0 and n<0 and n>=-MAX,'invalid Wraith Form amount')else check(n)end
 if hook=='turn_start_pre_draw'and id=='nightmare'then
  return {e('makeStatCardCopy',n,{template=copy(assert(state.nightmareTemplate,'missing Nightmare template'))}),e('removeFinalPower',0,{status=id})}
 elseif hook=='turn_start_pre_draw'and id=='phantasmal'then
  local incoming=power('double_damage',n);incoming.constructorAmount=1
  return {incoming,e('reduceFinalPower',1,{status=id})}
 elseif hook=='turn_start_post_draw'and id=='tools_of_the_trade'then
  return {e('draw',n),e('requestDiscard',n)}
 elseif hook=='turn_end'and id=='wraith_form'then return {e('gainStatus',n,{status='dexterity'})}
 elseif hook=='turn_end'and id=='burst'then return {e('removeFinalPower',0,{status=id})}
 elseif hook=='turn_end'and id=='well_laid_plans'then
  return {e('finalRetainChoice',n,{upTo=true,skipIfRetainAll=true})}
 elseif hook=='round_end'and(id=='double_damage'or id=='intangible')then return {e('reduceFinalPower',1,{status=id})}end
 return {}
end
function M.planCorpseDeath(state,owner)
 local n=owner.statuses.corpse_explosion or 0;check(n);if n==0 or owner.hp>0 or owner.escaped then return {}end
 local alive=false;for _,enemy in ipairs(state.enemies)do if enemy~=owner and enemy.hp>0 and not enemy.escaped then alive=true end end
 if not alive then return {}end
 local amount=owner.maxHp+0.0;check(amount);amount=amount*n;check(amount)
 return {e('corpseExplosionDamage',amount,{damageType='THORNS',sourceNull=true})}
end
-- These adapters return values only. Host applies Intangible BEFORE Block and
-- also on HP_LOSS/THORNS paths, never on healing. Source checks Power presence.
function M.capIncomingDamage(state,owner,amount)
 check(amount)
 if owner==state.player and owner.statuses.intangible~=nil and amount>1 then return 1 end
 return amount
end
function M.damageMultiplier(state,source,damageType)
 assert(damageType=='NORMAL' or damageType=='THORNS' or damageType=='HP_LOSS','unknown source damage type')
 if source==state.player and source.statuses.double_damage~=nil and damageType=='NORMAL'then return 2 end
 return 1
end

return M
