-- UUID/source identity and combat instance identity are independent namespaces.
-- Returned created cards are unattached: host must acquire them in one transaction.
local M={}
local MAX=2147483647
local pileNames={'hand','draw','discard','exhaust','limbo'}
local copied={misc=true,timesUpgraded=true,combatCost=true,turnCost=true,damageBonus=true,storedDiscardCost=true,
 retainedBlockBonus=true,retainedDamageBonus=true,retainedCostReduction=true,shivAccuracyBonus=true,expungerHits=true,
 freeToPlayOnce=true,inBottleLightning=true,inBottleFlame=true,inBottleTornado=true,isSeen=true,isLocked=true}
local booleans={freeToPlayOnce=true,inBottleLightning=true,inBottleFlame=true,inBottleTornado=true,isSeen=true,isLocked=true}
local ignored={uid=true,sourceUid=true,upgraded=true,cardId=true,retain=true,retainedTurn=true,ethereal=true,
 exhaust=true,exhaustOnUseOnce=true,purgeOnUse=true,dontTriggerOnUseCard=true,isInAutoplay=true,ignoreEnergyOnUse=true,energyOnUse=true}
local transientBooleans={retain=true,ethereal=true,exhaust=true,exhaustOnUseOnce=true,purgeOnUse=true,dontTriggerOnUseCard=true,isInAutoplay=true,ignoreEnergyOnUse=true}
local function integer(v,lo)return type(v)=='number'and v==v and v%1==0 and v>=(lo or 0)and v<=MAX end
local function uid(v)return type(v)=='number'and v==v and v>0 and v<math.huge and v%1==0 and v+1.0>v end
local function watermark(v)return v==0 or uid(v)end
local function dense(t)
 assert(type(t)=='table'and not getmetatable(t),'invalid identity list');local n=0
 for k in next,t do assert(integer(k,1),'invalid identity list index');n=n+1 end
 for i=1,n do assert(rawget(t,i)~=nil,'sparse identity list')end
 return n
end
local function plain(value,path)
 local kind=type(value)
 if kind=='table'then
  assert(not getmetatable(value)and not path[value],'non-data identity instance');path[value]=true
  for k,v in next,value do assert(type(k)=='string'or k==0 or uid(k),'invalid identity key');plain(v,path)end;path[value]=nil
 else assert(kind=='boolean'or kind=='string'or kind=='number'and value==value and math.abs(value)<math.huge,'non-data identity field')end
end
local function template(s,c,requireUid)
 assert(type(c)=='table'and not getmetatable(c)and type(c.cardId)=='string'and s.catalog.cards[c.cardId],'unknown identity template')
 plain(c,{})
 assert((not requireUid and c.uid==nil)or uid(c.uid),'invalid identity UID')
 assert(c.sourceUid==nil or uid(c.sourceUid),'invalid identity sourceUid')
 assert(c.upgraded==nil or type(c.upgraded)=='boolean','invalid identity upgrade')
 for k,v in next,c do
  assert(copied[k]or ignored[k],'unsupported identity stat field: '..tostring(k))
  if booleans[k]or transientBooleans[k]then assert(type(v)=='boolean','invalid identity boolean')
  elseif k=='retainedTurn'or k=='energyOnUse'then assert(integer(v),'invalid identity temporary amount')
  elseif copied[k]then assert(integer(v,k=='misc'and -MAX-1 or(k=='combatCost'or k=='turnCost')and -2 or 0),'invalid identity stat amount')end
 end
 if c.timesUpgraded~=nil then assert((c.upgraded==true)==(c.timesUpgraded>0),'inconsistent identity upgrade count')end
 return c
end
local function battle(s)
 assert(type(s)=='table'and s.catalog and type(s.catalog.cards)=='table','invalid identity state')
 local byUid,byObject,ordered,maxUid,maxSource={},{},{},0,0
 local function add(c)
  template(s,c,true)
  assert(not byUid[c.uid]or byUid[c.uid]==c,'combat UID belongs to different objects')
  byUid[c.uid]=c;maxUid=math.max(maxUid,c.uid);maxSource=math.max(maxSource,c.sourceUid or 0)
  if not byObject[c]then byObject[c]=true;ordered[#ordered+1]=c end
 end
 for _,name in ipairs(pileNames)do if s[name]~=nil then dense(s[name]);for _,c in ipairs(s[name])do add(c)end
  else assert(name=='limbo','missing identity pile')end end
 if s.cardInUse then add(s.cardInUse)end
 return {byUid=byUid,ordered=ordered,maxUid=maxUid,maxSource=maxSource}
end
local function masters(s,deck)
 dense(deck);local byUid,ordered,maxUid={},{},0
 for _,c in ipairs(deck)do template(s,c,true);assert(not byUid[c.uid],'duplicate permanent source UID')
  assert(c.sourceUid==nil or c.sourceUid==c.uid,'permanent source UID must match its UID')
  byUid[c.uid]=c.cardId;ordered[#ordered+1]={uid=c.uid,cardId=c.cardId};maxUid=math.max(maxUid,c.uid)
 end
 return byUid,ordered,maxUid
end
local function metadata(s,b)
 local d=s.cardIdentity
 assert(type(d)=='table'and not getmetatable(d),'identity not initialized')
 assert(watermark(d.combatHighWater)and watermark(d.sourceHighWater),'invalid identity high-water marks')
 assert(type(d.sources)=='table'and not getmetatable(d.sources),'missing reserved source identities')
 assert(type(d.masterCards)=='table'and not getmetatable(d.masterCards),'missing permanent identity index')
 local maxSource=math.max(d.sourceHighWater,b.maxSource)
 for identity,v in next,d.sources do assert(uid(identity)and v==true,'invalid reserved source identity');maxSource=math.max(maxSource,identity)end
 for identity,id in next,d.masterCards do assert(uid(identity)and type(id)=='string'and s.catalog.cards[id]and d.sources[identity],'invalid permanent identity index');maxSource=math.max(maxSource,identity)end
 for _,c in ipairs(b.ordered)do if c.sourceUid then assert(d.sources[c.sourceUid],'battle source UID is not reserved')end end
 assert(uid(s.nextUid)and s.nextUid>math.max(d.combatHighWater,b.maxUid),'conflicting or rewound combat allocator')
 assert(uid(s.nextSourceUid)and s.nextSourceUid>maxSource,'conflicting or rewound source allocator')
 return d
end
function M.init(s,masterDeck)
 local b=battle(s);local masterMap,_,masterMax=masters(s,masterDeck)
 assert(uid(s.nextUid)and s.nextUid>b.maxUid,'conflicting combat allocator at identity init')
 local old=s.cardIdentity
 if old then
  local d=metadata(s,b)
  for uid,id in next,masterMap do assert(d.masterCards[uid]==id,'permanent identity index changed during battle')end
  for uid,id in next,d.masterCards do assert(masterMap[uid]==id,'permanent identity index changed during battle')end
  return true
 end
 local maxSource=math.max(masterMax,b.maxSource)
 local nextSource=s.nextSourceUid or maxSource+1.0
 assert(uid(nextSource)and nextSource>maxSource,'conflicting source allocator at identity init')
 local sources={};for uid in next,masterMap do sources[uid]=true end
 for _,c in ipairs(b.ordered)do if c.sourceUid then sources[c.sourceUid]=true end end
 s.nextSourceUid=nextSource
 s.cardIdentity={masterCards=masterMap,sources=sources,combatHighWater=b.maxUid,sourceHighWater=maxSource}
 return true
end
local function available(s)
 local b=battle(s);local d=metadata(s,b)
 return b,d
end
function M.allocateCombatUid(s)
 local _,d=available(s)
 local identity=s.nextUid;s.nextUid=identity+1.0;d.combatHighWater=identity;return identity
end
function M.allocateSourceUid(s)
 local _,d=available(s)
 local identity=s.nextSourceUid;s.nextSourceUid=identity+1.0;d.sourceHighWater=identity;d.sources[identity]=true;return identity
end
local function copiedCard(s,source)
 template(s,source,false)
 local out={cardId=source.cardId,upgraded=source.upgraded==true}
 for k,v in next,source do if copied[k]then out[k]=v end end
 return out
end
function M.preflightCreated(s,source,mode,count)
 assert(mode=='new'or mode=='same','unknown identity copy mode');assert(integer(count),'invalid identity creation count')
 local b,d=available(s);copiedCard(s,source)
 if mode=='same'then assert(uid(source.sourceUid)and d.sources[source.sourceUid]and source.uid and b.byUid[source.uid]==source,
  'same copy requires its reserved original battle object')end
 if count>0 then
  local last=s.nextUid+0.0+count-1.0;local after=s.nextUid+0.0+count
  assert(uid(last)and after-s.nextUid==count,'combat identity batch cannot advance')
  if mode=='new'then last=s.nextSourceUid+0.0+count-1.0;after=s.nextSourceUid+0.0+count
   assert(uid(last)and after-s.nextSourceUid==count,'source identity batch cannot advance')end
 end
 return true
end
function M.created(s,source,mode)
 assert(mode=='new'or mode=='same','unknown identity copy mode')
 local b,d=available(s);local out=copiedCard(s,source)
 if mode=='same'then assert(uid(source.sourceUid)and d.sources[source.sourceUid],'same copy requires a reserved sourceUid')
  assert(source.uid and b.byUid[source.uid]==source,'same copy requires its original battle object')end
 out.uid=s.nextUid;out.sourceUid=mode=='same'and source.sourceUid or s.nextSourceUid
 s.nextUid=out.uid+1.0;d.combatHighWater=out.uid
 if mode=='new'then s.nextSourceUid=out.sourceUid+1.0;d.sourceHighWater=out.sourceUid;d.sources[out.sourceUid]=true end
 return out
end
function M.fromMaster(s,master)
 local _,d=available(s);template(s,master,true)
 assert(d.masterCards[master.uid]==master.cardId,'card is not a registered master instance')
 assert(master.sourceUid==nil or master.sourceUid==master.uid,'master source identity mismatch')
 local out=copiedCard(s,master)
 out.uid=s.nextUid;out.sourceUid=master.uid
 s.nextUid=out.uid+1.0;d.combatHighWater=out.uid
 return out
end
function M.allBattleInstancesBySourceUid(s,sourceUid)
 assert(uid(sourceUid),'invalid source identity lookup');local b=battle(s);local out={}
 for _,c in ipairs(b.ordered)do if c.sourceUid==sourceUid then out[#out+1]=c end end
 return out
end
return M
