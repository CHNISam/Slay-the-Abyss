-- Final Ironclad definitions and data-only plans; host owns choices/CardQueue.
-- Facts pinned to aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0.
local Actors=require('abyss_actor')
local Random=require('abyss_sts_random')
local M={}
local PIN='319009d5df0a82d9fb0f23cc22322286c6a87ec0'
local MAX=2147483647
local function copy(x) if type(x)~='table' then return x end;local y={};for k,v in pairs(x) do y[k]=copy(v) end;return y end
local function integer(x,lo) return type(x)=='number' and x==x and x%1==0 and x>=(lo or 0) and x<=MAX end
local function dense(t)
 assert(type(t)=='table' and getmetatable(t)==nil,'invalid final list');local n=0
 for k in pairs(t) do assert(integer(k,1),'invalid final list index');n=n+1 end
 for i=1,n do assert(rawget(t,i)~=nil,'sparse final list') end;return n
end
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 for k,v in pairs(a) do if not same(v,b[k]) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end;return true
end
local function effect(op,n,extra) local e={op=op,value=n};for k,v in pairs(extra or {}) do e[k]=v end;return e end
local function action(e) return {kind='effect',effect=e} end
local function plan() return {top={},bottom={}} end
local cards={
 {id='armaments',name='武装',sts_name='Armaments',type='skill',rarity='common',cost=1,
  effects={effect('block',5),effect('armaments',1,{all=false})},upgrade={effects={effect('block',5),effect('armaments',1,{all=true})}},
  text='获得5点格挡。升级1张手牌，本场战斗有效。',upgradeText='获得5点格挡。升级所有手牌，本场战斗有效。'},
 {id='havoc',name='破灭',sts_name='Havoc',type='skill',rarity='common',cost=1,effects={effect('havoc',0)},upgrade={cost=0},
  text='免费打出抽牌堆顶的牌，并使它在使用后消耗。',upgradeText='免费打出抽牌堆顶的牌，并使它在使用后消耗。'},
 {id='sword_boomerang',name='飞剑回旋镖',sts_name='Sword Boomerang',type='attack',rarity='common',cost=1,
  effects={effect('swordBoomerang',3,{hits=3})},upgrade={effects={effect('swordBoomerang',3,{hits=4})}},
  text='对随机敌人造成3点伤害3次。',upgradeText='对随机敌人造成3点伤害4次。'},
 {id='dual_wield',name='双持',sts_name='Dual Wield',type='skill',rarity='uncommon',cost=1,
  effects={effect('dualWield',1)},upgrade={effects={effect('dualWield',2)}},
  text='复制手牌中的1张攻击牌或能力牌，将复制牌放入手牌。',upgradeText='复制手牌中的1张攻击牌或能力牌，将2张复制牌放入手牌。'},
 {id='infernal_blade',name='地狱之刃',sts_name='Infernal Blade',type='skill',rarity='uncommon',cost=1,exhaust=true,
  effects={effect('infernalBlade',1)},upgrade={cost=0},
  text='将1张随机攻击牌放入手牌，该牌本回合耗能为0。消耗。',upgradeText='将1张随机攻击牌放入手牌，该牌本回合耗能为0。消耗。'},
 {id='searing_blow',name='灼热攻击',sts_name='Searing Blow',type='attack',rarity='uncommon',cost=2,multiUpgrade=true,
  effects={effect('damage',12)},upgrade={effects={effect('damage',16)}},
  text='造成12点伤害。可以多次升级。',upgradeText='伤害随升级次数增加。可以多次升级。'},
 {id='double_tap',name='双发',sts_name='Double Tap',type='skill',rarity='rare',cost=1,
  effects={effect('gainWarriorFinalPower',1,{status='double_tap'})},upgrade={effects={effect('gainWarriorFinalPower',2,{status='double_tap'})}},
  text='本回合下一张攻击牌额外打出1次。',upgradeText='本回合下两张攻击牌各额外打出1次。'},
 {id='feed',name='狂宴',sts_name='Feed',type='attack',rarity='rare',cost=1,exhaust=true,sourceTags={'HEALING'},
  effects={effect('feedDamage',10,{maxHp=3})},upgrade={effects={effect('feedDamage',12,{maxHp=4})}},
  text='造成10点伤害。若击杀非爪牙敌人，永久增加3点最大生命并恢复等量生命。消耗。',
  upgradeText='造成12点伤害。若击杀非爪牙敌人，永久增加4点最大生命并恢复等量生命。消耗。'},
 {id='juggernaut',name='势不可挡',sts_name='Juggernaut',type='power',rarity='rare',cost=2,
  effects={effect('gainWarriorFinalPower',5,{status='juggernaut'})},upgrade={effects={effect('gainWarriorFinalPower',7,{status='juggernaut'})}},
  text='每次获得正数格挡时，对随机敌人造成5点伤害。',upgradeText='每次获得正数格挡时，对随机敌人造成7点伤害。'},
}
M.ops={armaments=true,havoc=true,swordBoomerang=true,dualWield=true,infernalBlade=true,feedDamage=true,gainWarriorFinalPower=true}
M.internalOps={swordBoomerangHit=true,juggernautRandomDamage=true}
M.sharedDependencies={
 armaments={'hand_upgrade_choice','combat_only_upgrades'},havoc={'deferred_original_card_queue','autoplay_costs','shuffle'},
 sword_boomerang={'late_target_and_damage'},dual_wield={'hand_copy_choice','stat_equivalent_copy','overflow_discard'},
 infernal_blade={'complete_audited_attack_pool','source_make_copy','turn_cost_sentinels'},
 searing_blow={'timesUpgraded_in_Run_Combat_and_save'},double_tap={'deferred_purge_card_queue','distinct_runtime_UID'},
 feed={'damage_then_immediate_reward_then_reactions','permanent_maxHP','Minion_and_halfDead'},
 juggernaut={'positive_addBlock_before_cap','late_random_THORNS'},
}
function M.withCards(data)
 assert(type(data)=='table' and data.cards and data.cards.cards and data.statuses and data.statuses.statuses,'missing warrior final data')
 assert(not data.experimentalWarriorFinal,'warrior final data already prepared')
 local out,ids,states=copy(data),{},{}
 for _,d in ipairs(out.cards.cards) do assert(not ids[d.id],'duplicate source card');ids[d.id]=true end
 for _,d in ipairs(cards) do assert(not ids[d.id],'final card collision: '..d.id);local c=copy(d);c.color='red';c.experimental=true;out.cards.cards[#out.cards.cards+1]=c end
 for _,d in ipairs(out.statuses.statuses) do states[d.id]=true end
 for _,d in ipairs({
  {id='double_tap',name='双发',description='本回合接下来若干张攻击牌各额外打出一次；回合结束时移除。'},
  {id='juggernaut',name='势不可挡',description='每次获得正数格挡时，对随机敌人造成等同于层数的伤害。'},
 }) do
  assert(not states[d.id],'final Power collision: '..d.id);d.kind='buff';d.stack='intensity';d.decay='none';out.statuses.statuses[#out.statuses.statuses+1]=d
 end
 out.experimentalWarriorFinal=true;return out
end
local function definition(s,c)
 local d=copy(assert(s.catalog.cards[c.cardId],'unknown final card'))
 if c.upgraded and d.upgrade then for k,v in pairs(d.upgrade) do d[k]=copy(v) end end;return d
end
function M.upgradeCount(c)
 local n=c.timesUpgraded;if n==nil then n=c.upgraded==true and 1 or 0 end
 assert(integer(n),'invalid Searing Blow upgrade count')
 if c.timesUpgraded~=nil then assert((n>0)==(c.upgraded==true),'inconsistent Searing Blow upgrade metadata') end
 local damage=12+(n+0.0)*(n+7)/2;assert(integer(damage),'Searing Blow damage overflow');return n
end
function M.adaptDefinition(s,c,d)
 assert(d~=s.catalog.cards[c.cardId],'final adapter requires detached definition')
 if c.cardId=='searing_blow' then
  local n=M.upgradeCount(c);d=copy(d);d.effects[1].value=12+(n+0.0)*(n+7)/2
 end
 return d
end
function M.canUpgrade(s,c)
 local d=definition(s,c)
 if c.cardId=='searing_blow' then M.upgradeCount(c);return true end
 if d.type=='curse' or d.type=='status' or c.upgraded then return false end
 assert(type(d.upgrade)=='table','unimplemented upgrade cannot be offered');return true
end
-- Mutates only the supplied instance. Host must keep Combat copies separate
-- from permanent Run cards and persist timesUpgraded across all save paths.
function M.upgradeInstance(s,c)
 assert(M.canUpgrade(s,c),'card cannot upgrade')
 if c.cardId=='searing_blow' then
  local n=M.upgradeCount(c)+1;M.upgradeCount({timesUpgraded=n,upgraded=true});c.timesUpgraded=n;c.upgraded=true;return true
 end
 local d=definition(s,c)
 if c.cardId=='blood_for_blood' then require('abyss_warrior_status_cards').onUpgrade(s,c)
 elseif d.upgrade.cost~=nil then
  local base=c.combatCost or d.cost;local turn=c.turnCost;if turn==nil then turn=base end
  assert(integer(base) and integer(turn) and integer(d.upgrade.cost),'unsupported upgrade cost metadata')
  c.combatCost=d.upgrade.cost;c.turnCost=turn>0 and math.max(0,d.upgrade.cost+turn-base) or 0
 end
 c.upgraded=true;return true
end
local function targets(s)
 local list={}
 for _,enemy in ipairs(s.enemies) do
  if enemy.hp>0 and not enemy.escaped and not enemy.halfDead and not enemy.isDying and not enemy.isEscaping then list[#list+1]=enemy end
 end
 return list
end
local function randomTarget(s)
 local list=targets(s);if #list==0 then return nil end
 assert(s.cardRandomRng,'missing cardRandomRng');local rng=Random.cloneState(s.cardRandomRng)
 return list[Random.randomInt(rng,#list-1)+1],rng
end
local function attackPool(s,context)
 local p=context and context.attackPool
 assert(type(p)=='table' and p.complete==true and p.commit==PIN and p.scope=='runtime_src_pools'
  and type(p.manifestSha256)=='string' and #p.manifestSha256==64 and p.manifestSha256:match('^[0-9a-f]+$')
  and type(p.cardIds)=='table' and #p.cardIds>0,'complete audited Infernal Blade attack pool required')
 dense(p.cardIds)
 -- Completeness/order of the external manifest is a host audit obligation.
 -- Never build a fallback from implemented cards, re-roll or drop missing IDs.
 local seen={}
 for _,id in ipairs(p.cardIds) do
  local d=assert(s.catalog.cards[id],'source attack pool includes an unavailable definition')
  assert(not seen[id] and d.type=='attack' and (d.rarity=='common' or d.rarity=='uncommon' or d.rarity=='rare'),'invalid source attack pool member')
  assert(id~='feed' and id~='reaper','HEALING attacks excluded from source generation')
  for _,tag in ipairs(d.sourceTags or {}) do assert(tag~='HEALING','HEALING attack in source pool') end
  seen[id]=true
 end
 return p.cardIds
end
function M.prepareEffect(s,e,target,context)
 assert(M.ops[e.op],'unknown final effect');local out=copy(e)
 if e.op=='havoc' then local picked,rng=randomTarget(s);out.targetId=picked and picked.id;return out,rng
 elseif e.op=='infernalBlade' then
  local pool=attackPool(s,context);assert(s.cardRandomRng,'Infernal Blade requires cardRandomRng')
  local rng=Random.cloneState(s.cardRandomRng);out.cardId=pool[Random.randomInt(rng,#pool-1)+1]
  local cost=assert(s.catalog.cards[out.cardId].cost);assert(integer(cost,-2),'invalid generated attack cost')
  out.turnCost=cost>=0 and 0 or cost;return out,rng
 elseif e.op=='feedDamage' then
  assert(Actors.isActive(target),'Feed requires active target');out.targetId=target.id;out.normalAmount=Actors.attackAmount(s,s.player,target,e.value)
 end
 return out
end
function M.choiceSpec(s,mode,n)
 assert(mode=='armaments' or mode=='dual_wield','unknown final choice mode')
 local result={mode=mode,count=1,copyCount=n,turn=s.turn,candidateUids={},handUids={},handCards={},excludedUids={}}
 for _,c in ipairs(s.hand) do
  result.handUids[#result.handUids+1]=c.uid;result.handCards[#result.handCards+1]=copy(c)
  local d=definition(s,c);local eligible=mode=='armaments' and M.canUpgrade(s,c) or mode=='dual_wield' and (d.type=='attack' or d.type=='power')
  local list=eligible and result.candidateUids or result.excludedUids;list[#list+1]=c.uid
 end
 return result
end
local function findHand(s,uid) for _,c in ipairs(s.hand) do if c.uid==uid then return c end end;error('stale final choice UID') end
local function copyAction(c,n,replace)
 return action(effect('copyFinalCard',n,{sourceInstance=copy(c),copyMode='stat_equivalent',replaceOriginal=replace==true}))
end
function M.planChoice(s,spec,uid)
 assert(type(spec)=='table' and spec.turn==s.turn and #spec.handUids==#s.hand,'stale final choice')
 for i,c in ipairs(s.hand) do assert(c.uid==spec.handUids[i] and same(c,spec.handCards[i]),'changed final choice hand') end
 local found=false;for _,candidate in ipairs(spec.candidateUids) do if candidate==uid then found=true end end;assert(found,'invalid final choice')
 local c=findHand(s,uid);local p=plan();local order={}
 local candidates={};for _,id in ipairs(spec.candidateUids) do candidates[id]=true end
 for _,card in ipairs(s.hand) do if candidates[card.uid] and card.uid~=uid then order[#order+1]=card.uid end end
 if spec.mode=='armaments' then
  p.top[1]=action(effect('upgradeFinalCard',1,{uid=uid}));order[#order+1]=uid
 elseif spec.mode=='dual_wield' then p.top[1]=copyAction(c,spec.copyCount+1,true)
 else error('unknown final choice mode') end
 for _,id in ipairs(spec.excludedUids) do order[#order+1]=id end
 p.handOrder=order;return p
end
-- TOP arrays are execution order, pushed in reverse by the host.
function M.planEffect(s,e,context)
 local p=plan()
 if e.op=='armaments' then
  if e.all then
   for _,c in ipairs(s.hand) do if M.canUpgrade(s,c) then p.top[#p.top+1]=action(effect('upgradeFinalCard',1,{uid=c.uid})) end end
  else
   local spec=M.choiceSpec(s,'armaments',1)
   if #spec.candidateUids==1 then p.top[1]=action(effect('upgradeFinalCard',1,{uid=spec.candidateUids[1]}))
   elseif #spec.candidateUids>1 then p.top[1]=action(effect('finalHandChoice',1,{spec=spec})) end
  end
 elseif e.op=='dualWield' then
  local spec=M.choiceSpec(s,'dual_wield',e.value)
  if #spec.candidateUids==1 then p.top[1]=copyAction(findHand(s,spec.candidateUids[1]),e.value,false)
  elseif #spec.candidateUids>1 then p.top[1]=action(effect('finalHandChoice',1,{spec=spec})) end
 elseif e.op=='havoc' then p.top[1]=action(effect('stageHavocCard',0,{targetId=e.targetId or '',exhaustOnUseOnce=true,autoPlay=true,ignoreEnergyTotal=false,immediate=false}))
 elseif e.op=='infernalBlade' then
  assert(e.cardId and integer(e.turnCost,-2),'Infernal Blade source pool was not prepared')
  p.top[1]=action(effect('createFinalAttack',1,{cardId=e.cardId,turnCost=e.turnCost,copyMode='make_copy'}))
 elseif e.op=='swordBoomerang' then
  assert(e.hits==3 or e.hits==4,'invalid Boomerang hit count')
  for _=1,e.hits do p.top[#p.top+1]=action(effect('swordBoomerangHit',e.value)) end
 elseif e.op=='swordBoomerangHit' or e.op=='juggernautRandomDamage' then
  local target,rng=randomTarget(s);if not target then return p end
  if e.op=='swordBoomerangHit' then
   p.top[1]=action(effect('damage',e.value,{targetId=target.id,normalAmount=Actors.attackAmount(s,s.player,target,e.value)}))
  else p.top[1]=action(effect('finalThornsDamage',e.value,{targetId=target.id,sourceId=s.player.id})) end
  p.cardRandomRng=rng
 elseif e.op=='feedDamage' then
  assert(e.targetId and integer(e.normalAmount) and (e.maxHp==3 or e.maxHp==4),'Feed was not prepared')
  p.top[1]=action(effect('resolveFeed',e.value,{targetId=e.targetId,normalAmount=e.normalAmount,maxHp=e.maxHp}))
 elseif e.op=='gainWarriorFinalPower' then error('gainWarriorFinalPower requires applyPower')
 else error('unknown final effect') end
 return p
end
function M.applyPower(s,id,n)
 assert((id=='double_tap' or id=='juggernaut') and integer(n,1),'invalid final Power')
 return Actors.applyPower(s,s.player,id,n,s.player)
end
function M.prepareUse(s,c,d,context)
 local p=plan();local n=s.player.statuses.double_tap or 0;assert(integer(n),'invalid Double Tap count')
 if n>0 and d.type=='attack' and not c.purgeOnUse and not (context and context.purgeOnUse) then
  assert(integer(c.sourceUid,1),'Double Tap requires explicit sourceUid')
  p.powerChanges={{status='double_tap',value=n-1}}
  p.cardQueue={{sourceInstance=copy(c),copyMode='same_source',sourceUid=c.sourceUid,
   targetId=context and context.targetId or '',energyOnUse=context and context.energyOnUse or s.energy,
   purgeOnUse=true,autoPlay=true,ignoreEnergyTotal=true,immediate=true}}
  if n==1 then p.bottom[1]=action(effect('removeFinalPower',0,{status='double_tap'})) end
 end
 return p
end
function M.onGainedBlock(s,blockAmount)
 assert(type(blockAmount)=='number' and blockAmount==blockAmount and blockAmount>-math.huge and blockAmount<math.huge,'invalid block hook amount')
 local n=s.player.statuses.juggernaut or 0;assert(integer(n),'invalid Juggernaut amount')
 local p=plan();if blockAmount>0 and n>0 then p.bottom[1]=action(effect('juggernautRandomDamage',n)) end;return p
end
function M.planHook(s,id,phase)
 assert(id=='double_tap' and phase=='turn_end','unknown final phase hook')
 local p=plan();if s.player.statuses.double_tap~=nil then p.bottom[1]=action(effect('removeFinalPower',0,{status=id})) end;return p
end
function M.feedEligible(target)
 assert(type(target)=='table' and type(target.statuses)=='table','Feed target missing metadata')
 return (target.isDying==true or target.hp<=0) and not target.halfDead and rawget(target.statuses,'minion')==nil and target.minion~=true
end
return M
