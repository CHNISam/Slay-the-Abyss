-- Waiting cardQueue data only. Combat owns execution, targeting and disposal.
local M={}
local MAX=2147483647
local piles={"hand","draw","discard","exhaust","limbo"}
local flags={"autoplayCard","ignoreEnergyTotal","freeToPlayOnce","purgeOnUse","exhaustOnUseOnce","randomTarget"}
local statFields={combatCost=true,turnCost=true,damageBonus=true,storedDiscardCost=true,
    retainedBlockBonus=true,retainedDamageBonus=true,retainedCostReduction=true,shivAccuracyBonus=true,
    misc=true,inBottleLightning=true,inBottleFlame=true,inBottleTornado=true,isSeen=true,isLocked=true,freeToPlayOnce=true}
local transient={retain=true,retainedTurn=true,ethereal=true,exhaustOnUseOnce=true,purgeOnUse=true,
    dontTriggerOnUseCard=true,isInAutoplay=true,ignoreEnergyOnUse=true,energyOnUse=true}
local instanceBooleans={autoplayCard=true,ignoreEnergyTotal=true,freeToPlayOnce=true,purgeOnUse=true,
    exhaustOnUseOnce=true,randomTarget=true,retain=true,ethereal=true,dontTriggerOnUseCard=true,
    isInAutoplay=true,ignoreEnergyOnUse=true,inBottleLightning=true,inBottleFlame=true,inBottleTornado=true,isSeen=true,isLocked=true}
local function integer(n,lo) return type(n)=="number" and n==n and n%1==0 and n>=(lo or 0) and n<=MAX end
local function identity(n) return integer(n,1) or type(n)=="string" and #n>0 end
local function dense(t)
    assert(type(t)=="table" and not getmetatable(t),"invalid autoplay list")
    local n=0;for k in next,t do assert(integer(k,1),"invalid autoplay list index");n=n+1 end
    for i=1,n do assert(rawget(t,i)~=nil,"sparse autoplay list") end
    return n
end
local function pure(v,path)
    local kind=type(v)
    if kind=="table" then
        assert(not getmetatable(v) and not path[v],"non-data autoplay state")
        path[v]=true
        for k,x in next,v do assert(type(k)=="string" or integer(k),"invalid autoplay data key");pure(x,path) end
        path[v]=nil
    else
        assert(kind=="string" or kind=="boolean" or kind=="number","non-data autoplay field")
        if kind=="number" then assert(v==v and v>-math.huge and v<math.huge,"invalid autoplay number") end
    end
end
local function copy(v)
    if type(v)~="table" then return v end
    local out={};for k,x in pairs(v) do out[k]=copy(x) end;return out
end
local function sourceUid(card) return card.sourceUid or card.sourceUUID or card.uid end
local function graph(s)
    assert(type(s)=="table" and s.catalog and type(s.catalog.cards)=="table","invalid autoplay state")
    local result={}
    local function add(card)
        assert(type(card)=="table" and not getmetatable(card) and integer(card.uid,1)
            and type(card.cardId)=="string" and s.catalog.cards[card.cardId]
            and (card.upgraded==nil or type(card.upgraded)=="boolean"),"invalid autoplay instance")
        assert(not result[card.uid],"autoplay combat UID conflict")
        assert(identity(sourceUid(card)),"invalid autoplay source UID")
        for key,value in pairs(card) do
            if instanceBooleans[key] then assert(type(value)=="boolean","invalid autoplay instance flag")
            elseif statFields[key] or key=="retainedTurn" or key=="energyOnUse" then
                assert(integer(value,key=="misc" and -MAX-1 or (key=="combatCost" or key=="turnCost") and -2 or 0),
                    "invalid autoplay instance stat")
            elseif key=="sourceUid" or key=="sourceUUID" then assert(identity(value),"invalid autoplay source identity") end
        end
        pure(card,{})
        result[card.uid]=card
    end
    for _,name in ipairs(piles) do
        if name~="limbo" or s[name]~=nil then dense(s[name]);for _,c in ipairs(s[name]) do add(c) end end
    end
    if s.cardInUse then add(s.cardInUse) end
    return result
end
local function entries(s,byUid)
    local q=s.pendingAutoPlays or {};dense(q)
    local seen,generation={},nil
    for _,item in ipairs(q) do
        assert(type(item)=="table" and not getmetatable(item),"invalid autoplay entry")
        pure(item,{})
        assert(integer(item.uid,1) and byUid[item.uid] and not seen[item.uid],"missing or duplicate autoplay instance")
        assert(identity(item.sourceUid) and item.sourceUid==sourceUid(byUid[item.uid]),"stale autoplay source UID")
        assert(integer(item.generation) and integer(item.energyOnUse),"invalid autoplay snapshot")
        assert(generation==nil or generation==item.generation,"mixed autoplay generations")
        assert(item.targetId==nil or type(item.targetId)=="string" and #item.targetId>0,"invalid autoplay target ID")
        for _,field in ipairs(flags) do assert(type(item[field])=="boolean","invalid autoplay flag: "..field) end
        generation=item.generation;seen[item.uid]=true
    end
    return q,generation,seen
end
local function inspect(s) local byUid=graph(s);local q,g,seen=entries(s,byUid);return byUid,q,g,seen end
local function blocked(s)
    if s.actionQueue~=nil or s.preTurnActions and next(s.preTurnActions)~=nil then return "actions_pending" end
    if s.pendingDiscard or s.pendingScry or s.pendingHandChoice or s.pendingPileChoice then return "choice_pending" end
    if s.cardInUse or s.pendingPlay then return "card_in_use" end
end
function M.allocateUid(s)
    local byUid=inspect(s)
    assert(integer(s.nextUid,1) and s.nextUid<MAX and not byUid[s.nextUid],"invalid or conflicting autoplay nextUid")
    local uid=s.nextUid;s.nextUid=uid+1.0;return uid
end
function M.enqueue(s,instance,options)
    local byUid,q,g,seen=inspect(s)
    assert(type(options)=="table" and not getmetatable(options),"missing autoplay options");pure(options,{})
    assert(type(instance)=="table" and byUid[instance.uid]==instance,"autoplay instance is not owned")
    assert(integer(options.generation) and integer(options.energyOnUse),"invalid autoplay generation or energy")
    assert(options.targetId==nil or type(options.targetId)=="string" and #options.targetId>0,"invalid autoplay target ID")
    assert(options.immediate==nil or type(options.immediate)=="boolean","invalid autoplay insertion mode")
    if g~=nil and g~=options.generation then return false,"stale_auto_play_generation" end
    if seen[instance.uid] then return false,"duplicate_auto_play" end
    local item={uid=instance.uid,sourceUid=sourceUid(instance),generation=options.generation,
        energyOnUse=options.energyOnUse,targetId=options.targetId}
    for _,field in ipairs(flags) do
        local value=options[field]
        if value==nil then value=field=="autoplayCard" or instance[field]==true end
        assert(type(value)=="boolean","invalid autoplay flag: "..field);item[field]=value
    end
    if options.immediate then table.insert(q,1,item) else q[#q+1]=item end
    s.pendingAutoPlays=q
    return true,item
end
function M.peek(s,generation)
    assert(integer(generation),"invalid autoplay generation")
    local byUid,q,g=inspect(s)
    if #q==0 then return nil,"empty_auto_play_queue" end
    if g~=generation then return nil,"stale_auto_play_generation" end
    local reason=blocked(s);if reason then return nil,reason end
    return copy(q[1]),byUid[q[1].uid]
end
function M.pop(s,generation)
    local item,card=M.peek(s,generation)
    if not item then return nil,card end
    table.remove(s.pendingAutoPlays,1)
    if #s.pendingAutoPlays==0 then s.pendingAutoPlays=nil end
    return item,card
end
function M.clone(s,source,generation)
    local byUid,_,g=inspect(s)
    assert(integer(generation),"invalid autoplay generation")
    assert(type(source)=="table" and byUid[source.uid]==source,"clone source is not owned")
    if g~=nil and g~=generation then return false,"stale_auto_play_generation" end
    if source.purgeOnUse then return false,"purged_card_not_repeatable" end
    local out={cardId=source.cardId,upgraded=source.upgraded==true,sourceUid=sourceUid(source),purgeOnUse=true}
    for k,v in pairs(source) do
        if statFields[k] then out[k]=copy(v)
        else assert(k=="uid" or k=="cardId" or k=="upgraded" or k=="sourceUid" or k=="sourceUUID" or transient[k],
            "unsupported autoplay stat-copy field: "..tostring(k)) end
    end
    -- All validation precedes UID allocation and ownership mutation.
    local uid=s.nextUid
    assert(integer(uid,1) and uid<MAX and not byUid[uid],"invalid or conflicting autoplay nextUid")
    out.uid=uid
    s.nextUid=uid+1.0;s.limbo=s.limbo or {};s.limbo[#s.limbo+1]=out
    return out
end
function M.drop(s,generation,reason)
    assert(integer(generation),"invalid autoplay generation")
    assert(reason=="combat_ended" or reason=="combat_reset" or reason=="end_turn_early","invalid autoplay drop reason")
    local _,q,g=inspect(s)
    if g~=nil and g~=generation then return false,"stale_auto_play_generation" end
    local dropped={}
    for i,item in ipairs(q) do
        dropped[i]=copy(item)
        dropped[i].needsUseCardCleanup=reason=="end_turn_early" and item.autoplayCard
    end
    s.pendingAutoPlays=nil
    -- Never exhaust, purge, return to hand or trigger a card from this layer.
    return dropped
end
function M.active(s) return type(s)=="table" and s.pendingAutoPlays~=nil and #s.pendingAutoPlays>0 end
return M
