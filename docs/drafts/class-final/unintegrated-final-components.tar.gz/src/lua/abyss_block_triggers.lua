-- Source onGainedBlock plans only. Host owns addBlock, queue execution and
-- Power membership. Input is BEFORE floor, enemy modifiers and the 999 cap.
local Schedule=require('abyss_power_schedule')
local Random=require('abyss_sts_random')
local M={}
local MAX=2147483647
local powers={juggernaut=true,wave_of_the_hand=true}
local function integer(n,lo) return type(n)=='number' and n==n and n%1==0 and n>=(lo or 0) and n<=MAX end
local function dense(t)
 assert(type(t)=='table' and getmetatable(t)==nil,'invalid block-trigger enemy list')
 local n=0;for k in pairs(t) do assert(integer(k,1),'invalid block-trigger enemy index');n=n+1 end
 for i=1,n do assert(rawget(t,i)~=nil,'sparse block-trigger enemy list') end;return n
end
local function result() return {top={},bottom={}} end
local function action(op,n,extra)
 local e={op=op,value=n};for k,v in pairs(extra or {}) do e[k]=v end
 return {kind='effect',effect=e}
end
local function state(s)
 assert(type(s)=='table' and type(s.player)=='table' and type(s.player.statuses)=='table'
  and type(s.player.id)=='string' and type(s.player.hp)=='number','invalid block-trigger state')
 dense(s.enemies)
 local seen={}
 for _,e in ipairs(s.enemies) do
  assert(type(e)=='table' and type(e.id)=='string' and #e.id>0 and not seen[e.id]
   and type(e.hp)=='number' and e.hp==e.hp,'invalid block-trigger enemy')
  seen[e.id]=true
 end
end
local function ended(s) return s.player.hp<=0 or s.phase=='victory' or s.phase=='defeat' end
local function live(e)
 return e.hp>0 and not e.escaped and not e.halfDead and not e.isDying and not e.isEscaping
end
local function effect(e,op,s)
 assert(type(e)=='table' and e.op==op and integer(e.value,1) and e.sourceId==s.player.id,'invalid block-trigger effect')
end
function M.definitions()
 return {
  {id='juggernaut',name='势不可挡',kind='buff',stack='intensity',decay='none',priority=5,
   description='每次获得正数格挡时，对随机敌人造成等同于层数的伤害。'},
  {id='wave_of_the_hand',name='挥手',kind='buff',stack='intensity',decay='none',priority=5,
   description='每次获得正数格挡时，对所有敌人施加等同于层数的虚弱；本轮结束时移除。'},
 }
end
function M.ids() return {juggernaut=true,wave_of_the_hand=true} end
function M.plan(s,owner,blockAmount)
 state(s)
 assert(type(blockAmount)=='number' and blockAmount==blockAmount and blockAmount>-math.huge and blockAmount<math.huge,'invalid pre-floor Block amount')
 local p=result()
 if owner~=s.player or blockAmount<=0 or ended(s) then return p end
 for _,entry in ipairs(Schedule.list(owner,powers)) do
  assert(entry.priority==5 and integer(entry.amount),'unsupported block-trigger Power metadata')
  if entry.amount>0 then
   if entry.id=='juggernaut' then
    p.bottom[#p.bottom+1]=action('blockTriggerRandomDamage',entry.amount,{sourceId=owner.id})
   else
    -- Source constructs one ApplyPower per ORIGINAL monster, including dead
    -- ones. Each target's execution guard decides whether it still applies.
    for _,enemy in ipairs(s.enemies) do
     p.bottom[#p.bottom+1]=action('blockTriggerWeak',entry.amount,{targetId=enemy.id,sourceId=owner.id})
    end
   end
  end
 end
 return p
end
function M.planRandomDamage(s,e)
 state(s);effect(e,'blockTriggerRandomDamage',s)
 local p=result();if ended(s) then return p end
 local targets={};for _,enemy in ipairs(s.enemies) do if live(enemy) then targets[#targets+1]=enemy end end
 if #targets==0 then return p end
 assert(s.cardRandomRng,'Juggernaut requires cardRandomRng')
 local rng=Random.cloneState(s.cardRandomRng)
 local target=targets[Random.randomInt(rng,#targets-1)+1]
 p.cardRandomRng=rng
 p.top[1]=action('blockTriggerDamage',e.value,{targetId=target.id,sourceId=e.sourceId,damageType='THORNS'})
 return p
end
function M.planWeak(s,e)
 state(s);effect(e,'blockTriggerWeak',s)
 assert(type(e.targetId)=='string','Wave requires its captured target identity')
 local p=result();if ended(s) then return p end
 for _,enemy in ipairs(s.enemies) do
  if enemy.id==e.targetId then
   if live(enemy) then p.top[1]=action('applyStatus',e.value,{status='weak',targetId=enemy.id,sourceId=e.sourceId,sourceIsMonster=false}) end
   break
  end
 end
 return p
end
function M.planEndRound(s,owner)
 state(s);local p=result()
 if owner~=s.player or ended(s) then return p end
 if rawget(owner.statuses,'wave_of_the_hand')~=nil then
  p.bottom[1]=action('blockTriggerRemoveWave',0,{status='wave_of_the_hand',sourceId=owner.id})
 end
 return p
end
return M
