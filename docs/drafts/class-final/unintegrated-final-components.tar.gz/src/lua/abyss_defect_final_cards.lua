-- Fixed319009 facts and pure host plans; no silent pool/auto-play substitutes.
local A=require('abyss_actor')
local R=require('abyss_sts_random')
local Schedule=require('abyss_power_schedule')
local Events=require('abyss_events')
local M={}
M.ops={gainDefectPower=true,recursionOrb=true,increaseGeneticMisc=true,recycleCard=true,
 scrapeDraw=true,createDefectPower=true,allZeroCostToHand=true,fissionOrbs=true,rebootCards=true}
local MAX=2147483647
local function copy(x)if type(x)~='table'then return x end;local y={};for k,v in pairs(x)do y[k]=copy(v)end;return y end
local function number(n,min)assert(type(n)=='number'and n==math.floor(n)and n>=(min or 0)and n<=MAX,'invalid final Defect number');return n end
local function add(a,b)return number(a+0.0+b)end
local function e(op,value,x)x=x or {};x.op=op;x.value=value;return x end
local function power(id,n)return e('gainDefectPower',n,{status=id})end
local definitions={
 rebound={name='弹回',description='下一张牌若不是能力且未被消耗，则回到抽牌堆顶；能力也消耗次数。本回合有效。'},
 hello_world={name='你好，世界',description='每回合开始，将一张随机普通机器人牌加入手牌。'},
 self_repair={name='自我修复',description='战斗胜利时恢复对应层数的生命。'},
 static_discharge={name='静电释放',description='受到来自其他单位的普通攻击并将失去生命时，生成对应层数的闪电球。'},
 equilibrium={name='均衡',description='本回合结束保留所有非虚无手牌，每轮结束减少一层。'},
 amplify={name='增幅',description='本回合接下来的对应张能力牌额外打出一次。'},
 buffer={name='缓冲',description='抵消接下来的对应次数正数生命损失；完全被格挡的伤害不消耗次数。'},
 creative_ai={name='创造性AI',description='每回合开始，将一张随机机器人能力牌加入手牌；不生成带治疗标签的牌。'},
 echo_form={name='回响形态',description='每回合最先打出的对应张牌额外打出一次。'},
 machine_learning={name='机器学习',description='每个玩家回合正常抽牌数量增加对应层数。'},
}
local cards={
 {id='rebound',sourceId='Rebound',name='弹回',type='attack',rarity='common',cost=1,effects={e('damage',9),power('rebound',1)},upgrade={effects={e('damage',12),power('rebound',1)}},text='造成9点伤害。本回合下一张牌放回抽牌堆顶。',upgradeText='造成12点伤害。本回合下一张牌放回抽牌堆顶。'},
 {id='recursion',sourceId='Redo',name='递归',type='skill',rarity='common',cost=1,effects={e('recursionOrb',1)},upgrade={cost=0},text='唤起最前方充能球，然后将它重新生成。',upgradeText='唤起最前方充能球，然后将它重新生成。'},
 {id='force_field',sourceId='Force Field',name='力场',type='skill',rarity='uncommon',cost=4,effects={e('block',12)},upgrade={effects={e('block',16)}},text='获得12点格挡。本场战斗每打出一张能力牌，费用减少1。',upgradeText='获得16点格挡。本场战斗每打出一张能力牌，费用减少1。'},
 {id='genetic_algorithm',sourceId='Genetic Algorithm',name='遗传算法',type='skill',rarity='uncommon',cost=1,misc=1,exhaust=true,effects={e('increaseGeneticMisc',2),e('block',1)},upgrade={effects={e('increaseGeneticMisc',3),e('block',1)}},text='获得1点格挡。永久增加此牌的基础格挡2点。消耗。',upgradeText='获得1点格挡。永久增加此牌的基础格挡3点。消耗。'},
 {id='hello_world',sourceId='Hello World',name='你好，世界',type='power',rarity='uncommon',cost=1,effects={power('hello_world',1)},upgrade={innate=true},requiresDefectPool='common',text='每回合开始时，将1张随机普通机器人牌加入手牌。',upgradeText='先天。每回合开始时，将1张随机普通机器人牌加入手牌。'},
 {id='recycle',sourceId='Recycle',name='回收',type='skill',rarity='uncommon',cost=1,effects={e('recycleCard',1)},upgrade={cost=0},text='选择并消耗1张手牌。获得等同于它当前费用的能量。',upgradeText='选择并消耗1张手牌。获得等同于它当前费用的能量。'},
 {id='scrape',sourceId='Scrape',name='刮削',type='attack',rarity='uncommon',cost=1,effects={e('damage',7),e('scrapeDraw',4)},upgrade={effects={e('damage',10),e('scrapeDraw',5)}},text='造成7点伤害。抽4张牌，弃掉其中当前费用不为0且非免费打出的牌。',upgradeText='造成10点伤害。抽5张牌，弃掉其中当前费用不为0且非免费打出的牌。'},
 {id='self_repair',sourceId='Self Repair',name='自我修复',type='power',rarity='uncommon',cost=1,sourceTags={'HEALING'},effects={power('self_repair',7)},upgrade={effects={power('self_repair',10)}},text='战斗结束胜利时恢复7点生命。',upgradeText='战斗结束胜利时恢复10点生命。'},
 {id='static_discharge',sourceId='Static Discharge',name='静电释放',type='power',rarity='uncommon',cost=1,effects={power('static_discharge',1)},upgrade={effects={power('static_discharge',2)}},text='每次受到其他单位普通攻击并失去生命时，生成1个闪电球。',upgradeText='每次受到其他单位普通攻击并失去生命时，生成2个闪电球。'},
 {id='equilibrium',sourceId='Undo',name='均衡',type='skill',rarity='uncommon',cost=2,effects={e('block',13),power('equilibrium',1)},upgrade={effects={e('block',16),power('equilibrium',1)}},text='获得13点格挡。本回合保留所有非虚无手牌。',upgradeText='获得16点格挡。本回合保留所有非虚无手牌。'},
 {id='white_noise',sourceId='White Noise',name='白噪声',type='skill',rarity='uncommon',cost=1,exhaust=true,requiresDefectPool='power',effects={e('createDefectPower',1)},upgrade={cost=0},text='将1张随机机器人能力牌加入手牌，本回合费用变为0。消耗。',upgradeText='将1张随机机器人能力牌加入手牌，本回合费用变为0。消耗。'},
 {id='all_for_one',sourceId='All For One',name='万物一心',type='attack',rarity='rare',cost=2,effects={e('damage',10),e('allZeroCostToHand',1)},upgrade={effects={e('damage',14),e('allZeroCostToHand',1)}},text='造成10点伤害。将弃牌堆所有基础费用为0或免费打出的牌加入手牌。',upgradeText='造成14点伤害。将弃牌堆所有基础费用为0或免费打出的牌加入手牌。'},
 {id='amplify',sourceId='Amplify',name='增幅',type='skill',rarity='rare',cost=1,effects={power('amplify',1)},upgrade={effects={power('amplify',2)}},text='本回合下一张能力牌额外打出1次。',upgradeText='本回合接下来2张能力牌额外打出1次。'},
 {id='buffer',sourceId='Buffer',name='缓冲',type='power',rarity='rare',cost=2,effects={power('buffer',1)},upgrade={effects={power('buffer',2)}},text='抵消下1次正数生命损失。',upgradeText='抵消下2次正数生命损失。'},
 {id='creative_ai',sourceId='Creative AI',name='创造性AI',type='power',rarity='rare',cost=3,requiresDefectPool='power',effects={power('creative_ai',1)},upgrade={cost=2},text='每回合开始时，将1张随机机器人能力牌加入手牌。',upgradeText='每回合开始时，将1张随机机器人能力牌加入手牌。'},
 {id='echo_form',sourceId='Echo Form',name='回响形态',type='power',rarity='rare',cost=3,ethereal=true,effects={power('echo_form',1)},upgrade={ethereal=false},text='虚无。每回合最先打出的1张牌额外打出1次。',upgradeText='每回合最先打出的1张牌额外打出1次。'},
 {id='fission',sourceId='Fission',name='裂变',type='skill',rarity='rare',cost=0,exhaust=true,effects={e('fissionOrbs',0)},upgrade={effects={e('fissionOrbs',1)}},text='移除所有充能球，每移除1个获得1点能量并抽1张牌。消耗。',upgradeText='唤起所有充能球，每个球获得1点能量并抽1张牌。消耗。'},
 {id='machine_learning',sourceId='Machine Learning',name='机器学习',type='power',rarity='rare',cost=1,effects={power('machine_learning',1)},upgrade={innate=true},text='每回合正常抽牌额外抽1张。',upgradeText='先天。每回合正常抽牌额外抽1张。'},
 {id='reboot',sourceId='Reboot',name='重启',type='skill',rarity='rare',cost=0,exhaust=true,effects={e('rebootCards',4)},upgrade={effects={e('rebootCards',6)}},text='将手牌与弃牌堆洗入抽牌堆。抽4张牌。消耗。',upgradeText='将手牌与弃牌堆洗入抽牌堆。抽6张牌。消耗。'},
}
-- Source CardLibrary HashMap iteration reconstructed from all370 registrations.
-- Live common preserves order; src rarity lists reverse via addToBottom.
M.poolProfile='defect-all-unlocked-no-mod'
local pools={
 common={'go_for_the_eyes','ball_lightning','streamline','recursion','compile_driver','barrage','stack','rebound','claw','coolheaded','turbo','sweeping_beam','charge_battery','hologram','beam_cell','leap','cold_snap','steam_barrier'},
 power={'defragment','capacitor','heat_sinks','static_discharge','loop','hello_world','storm','biased_cognition','machine_learning','electrodynamics','buffer','echo_form','creative_ai'},
}
function M.sourcePool(kind)return copy(assert(pools[kind],'unknown source pool'))end
function M.validatePool(state,kind)
 assert(state.defectSourcePoolProfile==M.poolProfile,'complete Defect source pool profile required')
 local list=assert(pools[kind],'unknown Defect source pool')
 for _,id in ipairs(list)do
  local card=assert(state.catalog.cards[id],'incomplete Defect source pool: '..id)
  assert((kind~='power' or card.type=='power')and(kind~='common' or card.rarity=='common'),'wrong source pool definition')
  assert(require('abyss_card_capability').isImplemented(card),'unimplemented source pool candidate: '..id)
 end
 return copy(list)
end
function M.withCards(data)
 assert(data and data.cards and data.cards.cards and data.statuses and data.statuses.statuses,'missing final card data')
 local out=copy(data);local present={};for _,c in ipairs(out.cards.cards)do present[c.id]=true end
 for _,c in ipairs(cards)do assert(not present[c.id],'final card collision: '..c.id);out.cards.cards[#out.cards.cards+1]=copy(c)end
 local seen={};for _,s in ipairs(out.statuses.statuses)do seen[s.id]=true end
 for id,def in pairs(definitions)do
  assert(not seen[id],'final Power collision: '..id)
  out.statuses.statuses[#out.statuses.statuses+1]={id=id,name=def.name,description=def.description,kind='buff',stack='intensity',decay='none'}
 end
 return out
end
function M.makeBattleInstance(value,uid,allocatedSourceUid)
 local source=type(value)=='table'and value or {cardId=value};number(uid,1)
 local sourceUid=allocatedSourceUid or source.sourceUid or source.uid;number(sourceUid,1)
 local out={uid=uid,sourceUid=sourceUid,cardId=assert(source.cardId),upgraded=source.upgraded==true}
 if out.cardId=='genetic_algorithm'then out.misc=number(source.misc or 1,1)end
 if out.cardId=='force_field'then out.combatCost=4;out.turnCost=4 end
 return out
end
function M.configureNewCard(state,instance)
 local out=copy(instance)
 if out.cardId=='force_field'then
  local powers=0;for _,card in ipairs(state.cardsPlayedThisCombat or {})do if card.type=='power'then powers=powers+1 end end
  out.combatCost=math.max(0,4-powers);out.turnCost=out.combatCost
 end
 return out
end
function M.adaptDefinition(state,instance,definition)
 if instance.cardId~='genetic_algorithm'then return definition end
 local out=copy(definition);out.effects[2].value=number(instance.misc or 1,1);return out
end
local function freshPlan()return {top={},bottom={},instanceChanges={},masterChanges={},stateChanges={},statusChanges={},copyRequests={}}end
local function drawChoice(state,kind,rng)
 local list=M.validatePool(state,kind);return list[R.randomInt(rng,#list-1)+1]
end
function M.prepareEffect(state,effect,target,context)
 local out=copy(effect)
 if effect.op=='createDefectPower'then
  assert(effect.value==1,'invalid White Noise count')
  local rng=R.cloneState(assert(state.cardRandomRng,'White Noise requires cardRandomRng'))
  out.cardId=drawChoice(state,'power',rng);return out,rng
 end
 return out
end
local function def(state,card)return require('abyss_combat').cardDefinition(state,card)end
local function allInstances(state)
 local list,seen={},{}
 local function push(c)if c then assert(not seen[c.uid],'duplicate battle UID');seen[c.uid]=true;list[#list+1]=c end end
 push(state.cardInUse)
 for _,name in ipairs({'hand','draw','discard','exhaust','limbo'})do for _,c in ipairs(state[name]or{})do push(c)end end
 return list
end
function M.planEffect(state,effect,context)
 context=context or {};local p=freshPlan();local op=effect.op
 if op=='recursionOrb'then
  assert(effect.value==1 and state.orbs,'invalid Recursion')
  local first=state.orbs.balls[1]
  if first then p.top={e('evokeOrb',1),e('rechannelExistingOrb',1,{ball=copy(first),autoEvoke=false})}end
 elseif op=='increaseGeneticMisc'then
  assert(effect.value==2 or effect.value==3,'invalid Genetic increment')
  local current=assert(context.instance or state.cardInUse,'missing Genetic card');number(current.sourceUid,1)
  assert(current.cardId=='genetic_algorithm','wrong Genetic card')
  assert(type(state.masterDeck)=='table','Genetic Algorithm requires explicit masterDeck boundary')
  for _,c in ipairs(allInstances(state))do if c.sourceUid==current.sourceUid then
   assert(c.cardId=='genetic_algorithm','source identity type mismatch')
   p.instanceChanges[#p.instanceChanges+1]={uid=c.uid,changes={misc=add(number(c.misc or 1,1),effect.value)}}
  end end
  for _,c in ipairs(state.masterDeck or {})do if c.uid==current.sourceUid then
   assert(c.cardId=='genetic_algorithm','master identity type mismatch')
   p.masterChanges[#p.masterChanges+1]={uid=c.uid,changes={misc=add(number(c.misc or 1,1),effect.value)}}
  end end
 elseif op=='recycleCard'then
  assert(effect.value==1,'invalid Recycle count')
  if #state.hand==0 then return p end
  local selected
  if context.selectedUid then for _,c in ipairs(state.hand)do if c.uid==context.selectedUid then selected=c end end
   assert(selected,'invalid Recycle selection')
  elseif #state.hand==1 then selected=state.hand[1]
  else p.choice={kind='hand',mode='recycle',count=1};return p end
  local cost=def(state,selected).cost
  local amount=cost==-1 and number(state.energy)or math.max(0,cost)
  if amount>0 then p.top[1]=e('energy',amount)end
  p.exhaustUids={selected.uid}
 elseif op=='scrapeDraw'then
  number(effect.value);p.top={e('draw',effect.value,{recordDrawn=true}),e('finalScrapeFollowUp',1)}
 elseif op=='finalScrapeFollowUp'then
  local captured=assert(context.drawnUids,'missing Scrape drawn-card provenance')
  local hand={};for _,c in ipairs(state.hand)do hand[c.uid]=c end
  for _,uid in ipairs(captured)do local c=hand[uid]
   if c and def(state,c).cost~=0 and not c.freeToPlayOnce then p.top[#p.top+1]=e('manualDiscardUid',1,{uid=uid})end
  end
 elseif op=='createDefectPower'then
  assert(effect.value==1 and effect.cardId,'White Noise not prepared')
  p.top[1]=e('makeTempCard',1,{cardId=effect.cardId,pile='hand',upgraded=false,turnCost=0,sourceUidMode='new'})
 elseif op=='allZeroCostToHand'then
  assert(effect.value==1,'invalid All For One')
  for _,c in ipairs(state.discard)do
   local source=assert(state.catalog.cards[c.cardId]);local cost=source.cost
   if c.upgraded and source.upgrade and source.upgrade.cost~=nil then cost=source.upgrade.cost end
   if c.combatCost~=nil then cost=c.combatCost end
   if cost==0 or c.freeToPlayOnce then p.bottom[#p.bottom+1]=e('discardUidToHand',1,{uid=c.uid})end
  end
 elseif op=='fissionOrbs'then
  assert((effect.value==0 or effect.value==1)and state.orbs,'invalid Fission')
  local count=#state.orbs.balls
  if effect.value==1 then for _=1,state.orbs.slots do p.top[#p.top+1]=e('evokeOrb',1)end
  else p.top[1]=e('removeAllOrbs',1)end
  p.top[#p.top+1]=e('energy',count);p.top[#p.top+1]=e('draw',count)
 elseif op=='rebootCards'then
  assert(effect.value==4 or effect.value==6,'invalid Reboot draw')
  local rng=R.cloneState(assert(state.shuffleRng,'Reboot requires source shuffleRng'))
  local cardRng=R.cloneState(assert(state.cardRandomRng,'Reboot requires cardRandomRng'))
  local hand,discard,draw={},{},{}
  for _,c in ipairs(state.hand)do hand[#hand+1]=c.uid end
  for _,c in ipairs(state.discard)do discard[#discard+1]=c.uid end
  for _,c in ipairs(state.draw)do draw[#draw+1]=c.uid end
  R.shuffle(rng,discard)
  for _,uid in ipairs(discard)do draw[#draw+1]=uid end
  while #hand>0 do local i=R.randomInt(cardRng,#hand-1)+1;draw[#draw+1]=table.remove(hand,i)end
  R.shuffle(rng,draw)
  p.pileOrders={hand={},discard={},draw=draw};p.shuffleRng=rng;p.cardRandomRng=cardRng
  p.top[1]=e('draw',effect.value)
 else return nil end
 return p
end
function M.applyPower(state,id,amount)
 assert(definitions[id],'unknown final Defect Power');number(amount,1)
 local before=state.player.statuses[id]
 local ok=A.applyPower(state,state.player,id,amount,state.player)
 if ok then
  Schedule.recordApplied(state,state.player,id,before)
  if id=='rebound'and before==nil then state.reboundJustEvoked=true end
 end
 return ok
end
function M.removePower(state,id)
 assert(definitions[id],'unknown final Defect Power');Schedule.remove(state,state.player,id);state.player.statuses[id]=nil
 if id=='rebound'then state.reboundJustEvoked=nil end
 Events.emit(state,'power_removed',{target=state.player.id,status=id})
end
function M.reducePower(state,id,amount)
 assert(definitions[id],'unknown final Defect Power');number(amount,1)
 local old=state.player.statuses[id];if old==nil then return false end;number(old)
 if old<=amount then M.removePower(state,id)else state.player.statuses[id]=old-amount;Events.emit(state,'status',{source=state.player.id,target=state.player.id,status=id,amount=-amount})end
 return true
end
function M.incomingPlan(state,info,postBlock)
 number(postBlock);local p=freshPlan();p.amount=postBlock
 if info.target~=state.player then return p end
 assert(info.type=='NORMAL'or info.type=='THORNS'or info.type=='HP_LOSS','explicit damage type required')
 local buffer=state.player.statuses.buffer
 if buffer~=nil then
  number(buffer)
  p.amount=0;if postBlock>0 then p.top[1]=e('reduceDefectPower',1,{status='buffer'})end
 end
 local static=state.player.statuses.static_discharge or 0;number(static)
 if p.amount>0 and info.type=='NORMAL'and info.owner and info.owner~=state.player and static>0 then
  p.top[#p.top+1]=e('engineChannelRounds',1,{orb='lightning',remaining=static})
 end
 return p
end
function M.prepareUse(state,card,instance,context)
 context=context or {};local p=freshPlan()
 if instance.dontTriggerOnUseCard or card.dontTriggerOnUseCard then return p end
 if card.type=='power'then
  for _,name in ipairs({'hand','draw','discard'})do for _,c in ipairs(state[name])do if c.cardId=='force_field'then
   local base=c.combatCost or 4;local turn=c.turnCost or base;number(base);number(turn)
   local new=math.max(0,base-1)
   p.instanceChanges[#p.instanceChanges+1]={uid=c.uid,changes={combatCost=new,turnCost=math.max(0,new-(base-turn))}}
  end end end
 end
 if not instance.purgeOnUse then
  local doubled=number(state.echoDoubledThisTurn or 0)
  local played=number(#(state.cardsPlayedThisTurn or {}))
  for _,entry in ipairs(Schedule.list(state,{echo_form=true,amplify=true}))do
   local amount=number(entry.amount);local triggers=false
   if entry.id=='echo_form'and amount>0 and played-doubled<=amount then doubled=add(doubled,1);triggers=true;p.stateChanges.echoDoubledThisTurn=doubled
   elseif entry.id=='amplify'and amount>0 and card.type=='power'then
    triggers=true;p.statusChanges.amplify=amount-1
    if amount==1 then p.bottom[#p.bottom+1]=e('removeDefectPower',1,{status='amplify'})end
   end
   if triggers then
    number(instance.sourceUid,1)
    number(context.energyOnUse)
    p.copyRequests[#p.copyRequests+1]={originalUid=instance.uid,sourceUid=instance.sourceUid,sourceUidMode='same',
     targetId=context.targetId,energyOnUse=context.energyOnUse,purgeOnUse=true,freeToPlayOnce=true,sourcePower=entry.id}
   end
  end
 end
 return p
end
function M.afterUsePlan(state,card)
 local p=freshPlan();if card.dontTriggerOnUseCard then return p end
 local rebound=state.player.statuses.rebound
 if rebound~=nil then
  number(rebound)
  if state.reboundJustEvoked then p.stateChanges.reboundJustEvoked=false
  else p.reboundCard=card.type~='power';p.bottom[1]=e('reduceDefectPower',1,{status='rebound'})end
 end
 return p
end
function M.planHook(state,id,phase)
 assert(definitions[id],'unknown final Defect hook');local p=freshPlan();local n=number(state.player.statuses[id]or 0)
 if phase=='turn_start'then
  if id=='echo_form'then p.stateChanges.echoDoubledThisTurn=0
  elseif id=='hello_world'or id=='creative_ai'then
   if n==0 then return p end
   local rng=R.cloneState(assert(state.cardRandomRng,'random Power requires cardRandomRng'))
   local kind=id=='hello_world'and'common'or'power'
   M.validatePool(state,kind)
   for _=1,n do p.bottom[#p.bottom+1]=e('makeTempCard',1,{cardId=drawChoice(state,kind,rng),pile='hand',upgraded=false,sourceUidMode='new'})end
   p.cardRandomRng=rng
  end
 elseif phase=='turn_end'then
  if id=='rebound'or id=='amplify'then p.bottom[1]=e('removeDefectPower',1,{status=id})
  elseif id=='equilibrium'then p.retainUids={};for _,c in ipairs(state.hand)do if not def(state,c).ethereal then p.retainUids[#p.retainUids+1]=c.uid end end end
 elseif phase=='round_end'and id=='equilibrium'then p.bottom[1]=e('reduceDefectPower',1,{status=id})
 elseif phase=='victory'and id=='self_repair'and state.player.hp>0 then p.bottom[1]=e('heal',n)
 end
 return p
end
function M.drawCount(state,base)return add(number(base),number(state.player.statuses.machine_learning or 0))end
function M.needsQueue(state)
 for id in pairs(definitions)do if state.player.statuses[id]~=nil then return true end end
 for _,pile in ipairs({state.hand,state.draw,state.discard})do for _,c in ipairs(pile)do if c.cardId=='force_field'then return true end end end
 return false
end
return M
