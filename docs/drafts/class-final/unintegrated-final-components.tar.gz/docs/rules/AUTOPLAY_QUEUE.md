# 自动出牌的等待队列

`abyss_autoplay_queue` 只提供等待自动牌的纯数据队列、原对象查找、连击式副本和战斗 UID 分配。它没有自动出牌执行器，不调用 `Combat.play`，不把牌塞入手牌来借用普通出牌入口，也不替代选择、历史、支付、遗物或 UseCard 清理。

固定来源为社区反编译镜像 `aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0`，目标为初代 PC A0，不是官方二进制认证。实现及说明独立编写，不加入下载的 Java 源文。

## 精确源链与时点

`GameActionManager.getNextAction` 的优先级为普通 `actions`、`preTurnActions`、`cardQueue`。一次自动牌产生的普通动作必须全部完成，才取得下一张排队牌。选择暂停时也不能越过尚未完成的当前动作。这里不是简单把复制牌的伤害塞到当前牌效果尾部。

`NewQueueCardAction.update` 在实际执行时取得当前能量作为 `CardQueueItem.energyOnUse`。同一个卡牌对象已经排队则不重复加入；它按对象身份判重，不按原始 UUID 判重。旧 `QueueCardAction` 已标为 Deprecated，普通卡只追加到队尾；它的默认构造用于结束回合哨兵，但本模块不实现这项 UI／回合协议。

`GameActionManager.addCardQueueItem(item, true)` 在 Java 索引1插入：索引0仍是当前执行项，稍后才被移除。本模块的 `pendingAutoPlays` **仅含等待项**，当前项先 `pop` 并交给核心，因此对应的 immediate 是插入 Lua 索引1。连续立即入队呈后入先出，普通追加保持先进先出。根核心不能在同一列表里另保留当前项，再照搬这个等待队列协议。

GAM 先给卡设置 `isInAutoplay`，若队列带 `randomTarget` 则此时才使用 `cardRandomRng` 选择目标，再执行 `canUse`。自动播放绕过普通能量不足，仍检查 Power／Relic 的 canPlay、Entangled、不能使用的诅咒／状态等门槛。`ignoreEnergyTotal` 与 `autoplayCard` 是不同字段，不能合并成“无条件可用”。

canUse 成功时，源先执行 onPlayCard 和历史记录，再处理 ENEMY 目标已死／为空是否真正调用 `AbstractPlayer.useCard`。不能把目标失效统一解释成“没有计入历史”。canUse 失败的自动牌则被标记 `dontTriggerOnUseCard=true` 并安排正常 `UseCardAction` 清理；不能直接删掉队列记录并遗失卡牌。

`AbstractPlayer.useCard` 将自动 X 牌设为 `freeToPlayOnce=true`；自动牌的 `ignoreEnergyOnUse=true`，使用排队时快照的 `energyOnUse`，不会在执行时把 X 值随意替换为新能量。普通正费自动牌由 `isInAutoplay` 跳过支付，不等价于预先永久改零费用。实际 X 动作及各种额外效果仍由核心负责。

## 浩劫 Havoc

基础1费／升级0费，技能，本身不消耗。`Havoc.use` 在构造 `PlayTopCardAction` 前，立即用 `cardRandomRng` 选一个活目标；即使抽牌堆和弃牌堆均空，这次选择时点也已经发生，不能挪到“发现有牌后”。

`PlayTopCardAction` 在抽／弃均空时直接完成；抽牌堆空但弃牌堆非空时，TOP 安排 `EmptyDeckShuffleAction` 后重试自身。存在顶牌时，**原实例**离开抽牌堆，设 `exhaustOnUseOnce=true`，进入视觉 limbo；随后安排 Wait、`UnlimboAction`、`NewQueueCardAction(card,target,false,true)`。这些动作完成后卡才由 cardQueue 播放。它不是抽牌，不触发抽牌钩子，也不因 NoDraw 阻止。

源 `UnlimboAction` 在入 cardQueue 前已移除视觉 limbo。应用的纯数据图需要持有等待原对象，因此本模块约定 `state.limbo` 作为 headless 所有权容器；这不等于声称源视觉容器在相同时点仍含该牌。根核心负责 draw→limbo 的真实移动、洗牌和目标 RNG，模块仅校验入队对象已归属于当前战斗图。测试不冒充这些尚未接入的动作。

## 连击 Double Tap

基础1费／升级仍1费，技能，本回合下1／2张攻击额外打出一次。`DoubleTapPower.onUseCard` 在 `UseCardAction` **构造器**中执行：源牌非 `purgeOnUse`、类型 ATTACK 且剩余次数大于零时，`makeSameInstanceOf` 产生副本，保留源 UUID，设置副本 `purgeOnUse=true`，以源牌 `energyOnUse`、`ignoreEnergyTotal=true`、`autoplayCard=true` 和 immediate 入队。次数减一，归零后安排移除能力；回合末也移除。副本的 purge guard 阻止再次复制自身。

`makeSameInstanceOf` 是 `makeStatEquivalentCopy` 后覆盖 UUID，不是盲目深拷贝所有运行字段。源复制升级、基础伤害／格挡／magic、基础及本回合费用、freeToPlayOnce 和若干展示／持久字段；不复制 retain、exhaustOnUseOnce、dontTriggerOnUseCard、isInAutoplay 等暂态。本模块的 `clone` 专用于这种防递归重复：保留已支持的费用及基础数值适配字段，拒绝未知字段，清除上述暂态并设 purge。将来新增实例变异必须逐项核源再扩字段映射。

`UseCardAction.update` 先做 onAfterUseCard，重置 `freeToPlayOnce/isInAutoplay`，再优先检查 purge；purge 分支只显示消失并提前返回，早于 Power 或普通弃／消耗处理。它不会被“浩劫的 exhaust 标志”改成真正消耗，也不触发正常耗尽钩子。重复牌仍有真实用牌历史和合法触发，不是仅额外造成伤害。

## 数据和 API

`state.pendingAutoPlays` 是稠密等待数组，每项保存 `uid`、`sourceUid`、`generation`、可空 `targetId`、`energyOnUse` 及六个布尔快照：`autoplayCard`、`ignoreEnergyTotal`、`freeToPlayOnce`、`purgeOnUse`、`exhaustOnUseOnce`、`randomTarget`。状态中没有函数、执行器、目标 Actor 引用或卡牌对象引用；真正实例由四牌堆、`limbo`、`cardInUse` 持有。

`sourceUid` 表示原始来源身份，优先实例 `sourceUid`、其次 `sourceUUID`、否则原 `uid`，可以是非空原 UUID 字符串或正整数。复制牌沿用该来源身份，**战斗实例 `uid` 仍必须唯一**。同来源的不同副本可以同时排队，同战斗 UID 不可以。targetId 是源目标的 ID 快照；目标重选只在真实 resolver 的 randomTarget 分支发生。

| 方法 | 行为 |
| --- | --- |
| `enqueue(state, instance, options)` | options 必须有精确 generation 和非负整数 energyOnUse；可给 targetId、immediate 及六旗标。验证原对象属于当前图；重复同 UID 或混 generation 返回 `false, reason`。其他预检错误抛出，写入前拒绝。返回 `true, storedItem`。不移动牌、不支付、不运行卡牌。 |
| `peek(state, generation)` | 返回独立复制的队列项和原实例；空队列、过期 generation 或动作／选择未结束返回 `nil, reason`。 |
| `pop(state, generation)` | 同样预检后移除首个等待项，返回复制队列项和原实例；末项移除后清空字段。核心随后接管该原对象，必须在外围事务中继续处理。 |
| `allocateUid(state)` | 仅使用 nextUid，校验四堆、limbo、cardInUse 及排队引用不冲突后递增；不跳过冲突来掩盖损坏的分配器。调用者需在同一事务内赋予新实例所有权。 |
| `clone(state, source, generation)` | 验证源归属及受支持字段后分配新 UID，保存 stat-copy、来源身份和 purge 标志，将副本放入 limbo。源已 purge 或 generation 不符返回 `false, reason`。不自动入队或扣除连击次数。 |
| `drop(state, generation, reason)` | 仅接受 `combat_ended/combat_reset/end_turn_early`，返回取消记录，清等待数组，不移动实例。early-turn 的自动项标记 `needsUseCardCleanup=true`，供核心安排真实清理。不是 canUse 失败的替代入口。 |
| `active(state)` | 是否有等待项；不等价于可立即出牌。 |

peek/pop 会等 `actionQueue` 完全清空、preTurnActions 无剩余、四类 pending choice 无剩余且 cardInUse/pendingPlay 清空。它不推断胜负、存活目标或卡牌可用性，不消费 RNG。根核心在领取前检查真正战斗状态，切战斗时显式丢弃旧 generation，并清理对象所有权；不能只信调用者传回的旧 generation。drop 不触发虚假的消耗／弃牌，不清空 limbo，这些归核心。

根核心应维持整个战斗 `nextUid` 的单调性，包括其他生成器及已经 purge 的历史实例。本模块检测当前图冲突，不能由消失对象倒推任意被外部回退的分配器历史。pop／clone／enqueue 和随后失败的动作、费用、历史、RNG、目标及选择必须由核心的完整对象图事务覆盖。

## 定向证据与未完成集成

`node scripts/test-lua.mjs tests/lua/autoplay_queue.lua` 得到 `AUTOPLAY_QUEUE_COMPONENT_PASS 25`，2401ms、exit 0。使用真实 Combat 状态、实际牌对象及 Queue.run/resume；覆盖普通／立即插入顺序、动作优先、暂停、原引用、source UUID 与战斗 UID、去重、所有权冲突、exact generation、字段快照、受限 stat-copy、purge 防递归、非法数据原子拒绝、序列化和取消清理义务。测试末明确输出 `AUTOPLAY_CORE_NOT_CONNECTED`，没有宣称真正自动打出卡牌。

临时 `/tmp/abyss-autoplay-core-repro.lua` 使用源形状的浩劫探针定义 `{op="playTopCard",exhaust=true}` 调用真实 `Combat.play`，当前基线得到 `unsupported_effect:playTopCard`（238ms、exit 1）。这是尚未注册该效果及自动执行器的真实红灯，不是交付的原版浩劫定义，也没有用规则 mock 或把顶牌移到手牌来制造绿灯。opcode 最终命名及四类 pending 的完整持久化均待根核心接入后验证。

尚未通过真正 Havoc／DoubleTap 基础升级、自动牌触发选择并继续、X 支付、不能使用的自动牌清理、死亡／胜利与连续复制的完整 Core／Run 闭环，更没有平台实机证据。组件的25组不能计为这些功能已经可玩。

## 固定来源与 SHA-256

所有链接固定到 `319009d5df0a82d9fb0f23cc22322286c6a87ec0`。

| 文件 | SHA-256 |
| --- | --- |
| [GameActionManager.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/GameActionManager.java) | `a47d1ee9c6b2e194b7d3ef311328f2a15e38f5630330689e438e46685b94d6c3` |
| [NewQueueCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/utility/NewQueueCardAction.java) | `8a49f78ae34c588f8d9c0f8243d24950b4945b915e20da5ad7ec026c3e6f3747` |
| [QueueCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/utility/QueueCardAction.java) | `84f8ac5ccd9033a393e058e460fbeff8013912eb0e1aa3842b517fadfdcd425f` |
| [CardQueueItem.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/CardQueueItem.java) | `43e8dcc2ddaae4e7eb1e972e2bf984e3e905664e076db80acbd3496660672b01` |
| [UseCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/utility/UseCardAction.java) | `90213939af6d7ec83dea01bb2feef4ba762a93400dc1535732e2eebcdb6cab0f` |
| [PlayTopCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/PlayTopCardAction.java) | `dc0bae486cfa50d1470b54917d08ae240b014d96566e5cf32f3d5b0f4aabfd34` |
| [DoubleTapPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/DoubleTapPower.java) | `229c04c01990e446cbc87fab011a373f65734079f542d09c787d35742a3095ee` |
| [DoubleTap.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/DoubleTap.java) | `c9b0b20c90c46771bc8be356a92c8a9aab05c16a6cd2cd083ce08cee18154df4` |
| [Havoc.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/Havoc.java) | `3833783e8fb1ed6d4fb5d182eb0b75855cae6e5e3fa0efec851cfb44bc62bfc5` |
| [AbstractCard.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java) | `bcd472ececfd8ce4150ccd4eb6dd07a2e2dc43e139196fe00de34705cf1a2a61` |
| [AbstractPlayer.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/characters/AbstractPlayer.java) | `2720ba8dd7a216781a3b2fcb709f5ec67dc9b2559af25f7f6b89df1ef0947d95` |
