# 机器人最后19张牌：来源、宿主计划与边界

本片为 `abyss_defect_final_cards.lua`、`defect_final_build.lua` 和本文。独立追加19张牌，不改共享Combat/Actor/Run或其他agent的Hologram/Seek。此前35+engine19+本片19=73；只有另外两张真实接入后才构成75张，必须以实际Profile、Capability、战斗及显示结果分别验收，不能用定义数量代替完成。

## 固定来源

固定社区反编译 [aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0](https://github.com/aeubanks/sts/tree/319009d5df0a82d9fb0f23cc22322286c6a87ec0)，声明V2.3.4 (12-18-2022)，没有正版PC二进制认证。逐张读constructor/use/upgrade及相关action/power，事实独立整理，未复制Java实现。压缩包为 `https://codeload.github.com/aeubanks/sts/zip/319009d5df0a82d9fb0f23cc22322286c6a87ec0`，SHA256 `3f42bd7dde08126a9a8a02fc8eed8856c7b8b0dda551f50c62ced838e41ed458`。

| 本地ID | SourceID | 稀有度 | 费用 | 基础→升级与顺序 |
|---|---|---|---|---|
| rebound | Rebound | common | 1 | 伤害9→12，随后Rebound1；新Power的justEvoked跳过本牌 |
| recursion | Redo | common | 1→0 | 唤起并移除首球，再将同一球以autoEvoke=false重新生成 |
| force_field | Force Field | uncommon | 4 | 格挡12→16；每次能力牌使用令hand/draw/discard内本牌费用-1 |
| genetic_algorithm | Genetic Algorithm | uncommon | 1 | misc初始1；先永久misc+2→3，再以出牌前捕获的旧misc格挡；消耗 |
| hello_world | Hello World | uncommon | 1 | 每回合开始生成一张随机普通蓝牌；升级先天 |
| recycle | Recycle | uncommon | 1→0 | 选一张手牌，TOP排其当前费用能量，然后消耗；X以当前能量计 |
| scrape | Scrape | uncommon | 1 | 伤害7→10，再抽4→5，只弃新抽到的非0费且非freeToPlayOnce牌 |
| self_repair | Self Repair | uncommon | 1 | 胜利恢复7→10HP；HEALING标签 |
| static_discharge | Static Discharge | uncommon | 1 | 外部NORMAL攻击造成正数未格挡伤害时TOP排1→2闪电 |
| equilibrium | Undo | uncommon | 2 | 格挡13→16，Equilibrium1；轮末保留非虚无手牌 |
| white_noise | White Noise | uncommon | 1→0 | use时从完整随机能力池选一牌，加入手牌，本回合费用0；消耗 |
| all_for_one | All For One | rare | 2 | 伤害10→14，再按discard中基础cost==0或freeToPlayOnce筛选回手 |
| amplify | Amplify | rare | 1 | 本回合下1→2张能力牌额外使用一次 |
| buffer | Buffer | rare | 2 | 抵消下1→2次正数未格挡生命损失 |
| creative_ai | Creative AI | rare | 3→2 | 每回合开始生成一张随机能力；排除HEALING |
| echo_form | Echo Form | rare | 3 | 每回合最先1张牌额外使用一次；基础虚无，升级不虚无 |
| fission | Fission | rare | 0 | 捕获filled球数，移除→升级唤起所有球，再能量+N、抽N；消耗 |
| machine_learning | Machine Learning | rare | 1 | DrawPower1令每回合普通抽牌+1；升级先天 |
| reboot | Reboot | rare | 0 | ShuffleAll→ShuffleAction(draw,false)→抽4→6；消耗 |

共2 common、9 uncommon、8 rare。中文name/text/upgradeText对应实际定义；动态牌面、未知op拒绝保护由root展示适配接入，不宣称已有平台UI通过。

## 完整随机池与顺序

本片没有使用当前已做子集作为fallback。支持明确的 `state.defectSourcePoolProfile='defect-all-unlocked-no-mod'`，代表完整解锁、机器人、不启用改池mod的来源配置；缺少该显式边界直接拒绝，不伪称用户实际PC解锁进度。

来源链为CardLibrary.initialize按事实注册370个唯一ID→HashMap.entrySet→addBlueCards（排BASIC及未解锁）→AbstractDungeon.initializeCardPools。CardGroup.addToTop是append；src池的addToBottom是index0插入，因此src各稀有度列表反转，不能随便按卡名字母或本地helper顺序排列。

以仓库固定 `data/reference/sts1-card-pools/registration.json` 的全部370注册记录重建Java String.hashCode及HashMap spread/bucket顺序；容量512，所有resize段的桶长度不足treeify阈值，最终最大桶4。用本机OpenJDK21.0.12.1真实HashMap逐键对账完全相同；这是JDK8兼容列表桶算法的来源重建交叉检查，仍不是原版二进制或PC实机认证。

- metadata文件SHA256：`f2a387be3b963ba9fac36a0305ef5add76862666f6055a1d8e058d8f33a53308`。
- 370键完整HashMap遍历结果（UTF-8每键一行末尾换行）SHA256：`704cf04aede6daf0d2a84105fbc47c3742b53b059aa49f1bb6cec122860f03b9`。
- HelloWorld使用live commonCardPool正序18张：`go_for_the_eyes, ball_lightning, streamline, recursion, compile_driver, barrage, stack, rebound, claw, coolheaded, turbo, sweeping_beam, charge_battery, hologram, beam_cell, leap, cold_snap, steam_barrier`。
- WhiteNoise/CreativeAI使用srcCommon→srcUncommon→srcRare顺序，过滤POWER且排HEALING，共13张：`defragment, capacitor, heat_sinks, static_discharge, loop, hello_world, storm, biased_cognition, machine_learning, electrodynamics, buffer, echo_form, creative_ai`。SelfRepair不能生成。

复核方法：读取370 registration按registrationIndex建立Java HashMap；取全部entrySet次序，再按BLUE/COMMON筛选得到Hello池。对每个COMMON/UNCOMMON/RARE先反转相应BLUE列表，再按POWER且不带HEALING筛选并拼接，即能力池。独立Python的spread为Java32位String hash再xor无符号右移16位，最终按 `spread & 511` 桶号与原注册顺序稳定排列；与真实Java结果对比，不能只信自身实现。

`sourcePool(kind)`返回事实序列副本；`validatePool`逐候选核定义、正确类型/稀有度和Capability.isImplemented，缺任何一张或缺共享op就抛错，**不缩小列表重抽**。Hello缺Hologram必须拒绝，不能临时塞一个空假定义过检查。当前测试保留缺一牌拒绝案例；正向随机生成需root把完整真实候选和op接齐。

## sourceUid、永久misc和复制

统一字段为 `sourceUid`，不另引入sourceUuid。combat `uid`与sourceUid分别分配。永久牌的初始sourceUid来自Run.deck.uid；临时constructor/statEquivalent默认分配新sourceUid；makeSameInstanceOf复制保留sourceUid。Host维护独立nextSourceUid=max permanentUid+1，不能把combat.nextUid当来源身份。

`makeBattleInstance(value,uid,allocatedSourceUid)`返回战斗实例，永久value.uid可作来源，显式allocatedSourceUid优先用于新构造，value.sourceUid可用于same-instance。Host若需要same不得传新分配的sourceUid。Genetic的misc保留，其他牌不会把本战临时伤害／费用字段误持久化。`configureNewCard`为新ForceField按已经打出的能力牌历史初始化费用；之后只依真实onCardPlayed更新hand/draw/discard，不从全局历史推导exhaust中停留期间本不该收到的减费。

`increaseGeneticMisc`要求显式 `state.masterDeck` 边界（Run真实永久牌组引用；临时生成场景也须显式空列表），按实例sourceUid==master.uid匹配持久牌，同时更新所有using/hand/draw/discard/exhaust/**limbo**中同sourceUid的牌。计划返回masterChanges与instanceChanges而不直接写入。

misc增长动作在GainBlock之前，但block是use时捕获的旧misc。Echo复制GA时，复制牌必须先登记limbo且共享sourceUid：原牌第一次增长也应更新尚未使用的复制牌，复制牌随后以已增长的misc获得格挡，再第二次增长。测试期望初始misc1得到1+3格挡、永久misc5、仅原GA进入exhaust，purge复制不触发第二次exhaust。异常必须恢复Run.deck原表、所有同源实例及牌堆引用，不只恢复战斗副本。

## 宿主接口与动作计划

`M.ops`包含9个外部新动作。`withCards`深拷贝追加19牌及10种中文状态，拒绝重复。`adaptDefinition`根据Genetic当前misc提供真实格挡基值。`prepareEffect`普通op原样copy，WhiteNoise在克隆cardRandomRng上**use时**选牌并以第二返回值交给Host提交。

`planEffect`返回纯数据，主要字段：

```lua
{ top={}, bottom={}, instanceChanges={}, masterChanges={},
  stateChanges={}, statusChanges={}, copyRequests={},
  pileOrders=optional, cardRandomRng=optional, shuffleRng=optional,
  choice=optional, exhaustUids=optional }
```

数组按执行顺序，Host逆序pushTop、顺序pushBottom；全部计划验证后再提交状态。实例/master变更按uid匹配。pileOrders只包含UID次序，Host重排原有表、保留实例与表引用；RNG after提交回原对象。普通effect动作仍包装kind=effect。状态与自动牌队列必须纳入完整事务。

- Recursion：TOP evokeOrb再rechannelExistingOrb（原球kind/stored快照，autoEvoke=false）。Host保留原对象语义及Dark储存值，不能新造Dark把储存清6；末敌死亡取消后续channel，所以历史不增加。
- Recycle：空手无动作，一张自动，多张返回choice={kind='hand',mode='recycle',count=1}；context.selectedUid验证真实手牌。先把返能TOP放好，再处理exhaustUids，令Sentinel等exhaust的TOP钩子仍排在返能之前。FNP/DE等BOTTOM相对顺序不可颠倒。X消耗牌返还的是当时当前能量；0或负不可打出牌返0。
- Scrape：draw带recordDrawn=true，Host按这一次真正进入手牌的UID捕获，再为finalScrapeFollowUp提供context.drawnUids。仅新抽到且当前费用非0、freeToPlayOnce非真的牌，按顺序manualDiscardUid，并执行真实manual-discard回调和非endTurn弃牌计数；不能扫整手牌，也不能忽略Tactician/Reflex。
- AllForOne：以升级及战斗费用修正后的**base cost**筛选（不看临时turnCost），或freeToPlayOnce；将每张discardUidToHand放BOTTOM，排在当前UseCard之后。手牌满则源DiscardToHandAction不移动该牌。
- Fission：执行时捕获filled数量。基础移除不唤起；升级排所有slot数次EvokeOrb（含空槽无效尾部），随后能量、draw。预排DAMAGE evoke继续最终移球，但杀末敌后取消能量与draw。
- Reboot：完整源顺序为先discard.shuffle(shuffleRng)，逐牌进入draw，再随机移每张剩余hand到draw顶（每张cardRandomRng，包括单张random0），最后draw.shuffle()，再抽牌。即使discard空，前一个shuffle仍消耗一次shuffleRng；最后shuffle再一次。本片clone两流纯算pileOrders，原本在using的Reboot不参与洗牌，最后消耗。

## Power、免费复制和清理

`applyPower`复用Actor.applyPower并登记共享PowerSchedule；Host不能再二次recordApplied。`removePower/reducePower`同时维护Schedule成员。普通牌也须通过钩子；`needsQueue`用于避免fast immediate路径绕过Rebound/Echo/ForceField。

`prepareUse(state,card,instance,context)`在当前牌已经进入历史、原生use已构造后调用。按Schedule稳定顺序处理Echo/Amplify：Echo判断 `cardsPlayedThisTurn.size()-cardsDoubledThisTurn <= amount`，在stateChanges中立即增加本回合已复制数；Amplify的amount在源onUse立即减1，statusChanges即时提交，仅为0时BOTTOM移除。copyRequests给自动队列agent，含originalUid、同sourceUid、same模式、targetId、energyOnUse、purgeOnUse=true、freeToPlayOnce=true。

这些是真正免费自动使用的牌，需正常伤害／状态／onUse、历史、SourceUID及新uid处理；在原动作队列全部排空后按源CardQueue执行，不能重放一串effect冒充。purge复制不再触发Echo或Amplify，但仍影响Power历史和ForceField，并仍触发Rebound的onAfterUse；purge清理优先于exhaust/rebound，不落弃牌堆或再次消耗。源inFrontOfQueue为index1插入，多Power复制顺序需由统一自动牌队列保存。

`afterUsePlan`在源UseCard清理前运行。新Rebound.justEvoked跳本牌；之后非Power标reboundCard=true，但**Power也会消耗一次Rebound**，只是Power本来就不进入牌堆。Rebound与Amplify于玩家turn_end清除。

`planHook(state,id,phase)`供共享PowerSchedule按原优先级/获得顺序调用：hello/AI在turn_start构造时选完所有随机生成牌，再排MakeTempCard；Root须逐个hook提交返回RNG，不能各自从同一旧流克隆。amount0不选池、不花RNG。echo在turn_start重置计数；equilibrium在turn_end只标记非ethereal手牌retain，在round_end减层；selfRepair仅victory且活玩家heal。`drawCount`为普通开局抽牌加MachineLearning层数，不立即多抽牌；胜利修复由Host仅执行一次，先于Run从Combat复制最终HP。

## Buffer与静电：生命扣减前后的类型边界

来源AbstractPlayer.damage顺序是：伤害非负/Intangible→decrementBlock（HP_LOSS绕盾）→onAttackedToChangeDamage（Buffer）→onAttacked（Static）→onLoseHp/wasHPLost→实际扣HP→死亡处理。不能只在已经发生HP-loss的notify后才决定Buffer或Static。

`incomingPlan(state,{owner,target,type},postBlock)`要求明确NORMAL/THORNS/HP_LOSS。Buffer存在时把post-block值变0；若原post-block>0才TOP排reduceDefectPower(buffer,1)，所以全挡不耗。Source Buffer没有类型或owner限制，**HP_LOSS、THORNS、null owner、自伤也会被挡**；0层Power尚未移除时也按源Power成员处理。

随后Static仅当剩余伤害>0、type=NORMAL、owner存在且不是玩家本人，才TOP排对应层数闪电。Buffer清零后的伤害不触发Static；Thorns/Burn/球伤害/loseHp/self NORMAL均不触发。Source在扣HP前构造Static actions，但玩家致死后action manager停止，因此Host应先记录计划、完成HP扣减，再执行／丢弃队列，**致死攻击不能在死前实际channel球并改变结局**。测试真实endTurn与Actor入口覆盖此边界，不能把boolean fixed全部当普通NORMAL。

## 当前验证和明确缺口

定向命令 `node scripts/test-lua.mjs tests/lua/defect_final_build.lua`。计划58组：7组独立事实/组件、38组19牌基础升级真实play、13组边界。当前7组件通过；首个真实Rebound明确红 `unsupported_effect:gainDefectPower`，共享final入口仍待root接入，不宣称58组已通过，没有mock核心。

覆盖包括Genetic master/limbo纯计划与真实misc持久／回滚、Echo+GA同源增长；一个明确二牌组小史莱姆**单元Run fixture**验证胜利→奖励→下一战重新构造后的misc，不假称自然初始牌组路线；Buff类型/盾/自伤/静电/致死；完整pool缺一拒绝；免费复制的历史和purge；Reboot两次shuffle和逐手牌随机；Scrape provenance、均衡虚无、Fission末敌清尾。

尚未证实共享final core、完整random候选真实op、自动卡队列与永久Run字段已接入，也未做新75牌自然路线、地图、概率、UI／Windows实机或全量检查。Source显式配置之外的锁牌／mod混池、Master Reality生成升级、Chemical X、自定义共享身份复制来源、signed32以外Java溢出、复杂relic／power组合须按统一宿主能力边界拒绝或继续实现，不静默声称支持。

## 源文件指纹

下列49份文件都来自同一固定commit，路径相对根目录：

| 路径 | SHA256 |
|---|---|
| `cards/blue/Rebound.java` | `0aa757f9d6f21422a190b66619b198af223a41075148b410cda83b819927e694` |
| `cards/blue/Recursion.java` | `c75ea25cb6abe14f4478e08cb85c3dfa9268b6737d1fc87aa8332f97b24f6005` |
| `cards/blue/ForceField.java` | `293e9880b2079d99cb61301618fbb4e88e0a5de238a3c2cec9fc47399a919d25` |
| `cards/blue/GeneticAlgorithm.java` | `0fea906f731c23b6acbc11bd00a5c49139a1fe68e96a7bef60db0c8cf0c61fda` |
| `cards/blue/HelloWorld.java` | `4d3c99750f6ff1cf1e7dd111d5f4d6c437b052a9a2727170e9c5f6d2c231cf24` |
| `cards/blue/Recycle.java` | `a347e320a1700f1f7c3e50cb97823c66aecd56170720c750dfd9901ea11e916a` |
| `cards/blue/Scrape.java` | `62bc33473ddf2b155b890196cba125bc4ad7eb55b9f576fd88e177feb6eb6f9a` |
| `cards/blue/SelfRepair.java` | `5d08cf333188b7e42e0457cdb3ce1bd3cf7ad0802297d7553317bd9ea1705d49` |
| `cards/blue/StaticDischarge.java` | `f886d0e5c1b652d376e99c11d1d251467cd58af440793acb6c3a0832dfca81d1` |
| `cards/blue/Equilibrium.java` | `b67a9af10ef2a308d7d7830d96fd84fbcd9ae6eb6e547ece35bb3884a81c9dad` |
| `cards/blue/WhiteNoise.java` | `32f77f0b7ad71fb553587018d468b7c74a93697e859b07da2b4e6c89c2f838a4` |
| `cards/blue/AllForOne.java` | `b0028c432d3c23f0981dbb5f3840eabbd5886321d938c91ebb10f3568772207c` |
| `cards/blue/Amplify.java` | `0c44836656f7170268bc1332b8439340689c5b300d88abe42d16dadd89ec5e40` |
| `cards/blue/Buffer.java` | `5262530eb87736dddd5d8fc369c83a9db49c4ecdb24cd8e99a2b16a33349874e` |
| `cards/blue/CreativeAI.java` | `973e66b6d5ef651090a4184bcdc24b0a4182ec6061cde04eed64f7042409741d` |
| `cards/blue/EchoForm.java` | `4219c41ec0ad5975560b5d4cdcf4c6302122ea6be834bfcb6bb2e3614040a27d` |
| `cards/blue/Fission.java` | `2b4ff902a69cabf22949a2f7de0e8722a6cb793d98d8f11dc0881dfa1557cc08` |
| `cards/blue/MachineLearning.java` | `fef76b9e40f5f3663d59e08758556d17fd74068891bdf5895a6bb88e31e70517` |
| `cards/blue/Reboot.java` | `318f9000285d7c0d357cb7fffa387853f95bbe05b484a61ed2924825a33f8791` |
| `powers/ReboundPower.java` | `c9ddfff3aad8b1de7a415c90cf4f80a2d13fc2d2bb7057d08945536532319784` |
| `powers/HelloPower.java` | `ef333525af9ba20e5991e628c1505fa4bc9910509fc2d8c8e624b7be39be81b3` |
| `powers/RepairPower.java` | `37f49be789f20b476dcdcf1cf248608bc1364ef54f61f28faf79f9354d06f74c` |
| `powers/StaticDischargePower.java` | `93b86d1b514f5da259978d98e45061dc0483ba48fbfd9e09882df6faa15d94ef` |
| `powers/EquilibriumPower.java` | `d39ae17a6dd4cc562fc4533f0ae1b2dac6f12afe7b25d5fc0a698db51473de67` |
| `powers/AmplifyPower.java` | `b5988785b7e36ce6ea9257e28ccae8192c2725c3365fb11dd02876baf5b7aa5c` |
| `powers/BufferPower.java` | `c37a54fe614dd9588e298e9d2de0d283bb45c31b58f8aeae7447676093502b60` |
| `powers/CreativeAIPower.java` | `de09e60e7413debf133d85e98ef544ab3d504bb09142a40c814bd77453ede549` |
| `powers/EchoPower.java` | `972411a3f3982919dc820403566a7b6ffadce8c9d299ee86d321af56a6272f47` |
| `powers/DrawPower.java` | `e1c14729ea1011df371f75824747a1bfc2c3d11c9acb02994dd2e82a2a862412` |
| `actions/defect/RedoAction.java` | `547937a3b24e12cb51bc13dd5570f1bf002011384cd07dabf03e89de128fa329` |
| `actions/defect/IncreaseMiscAction.java` | `a2bd919aef6c197a1e6119367c1ef8aec5c2c20a29c2bc04a765e09c49bc4fe7` |
| `actions/defect/RecycleAction.java` | `2b68133aa3352eb4804bd53e519a394b9b392a69fadd699511d3ef27b3fd0d74` |
| `actions/defect/ScrapeFollowUpAction.java` | `2a4880de4f4744fa28562c0d139fba86b3d434d4f5e931e398771ae3d8f2444e` |
| `actions/defect/AllCostToHandAction.java` | `e7524f95b7c9b852c7d019d00f5a874d46c9295e7dda2c309145b4172fe753f7` |
| `actions/defect/FissionAction.java` | `1a98cdf4691335949c87fd50aaaa90cd16ca6e7e9aed3c3023ecbea337810847` |
| `actions/defect/ShuffleAllAction.java` | `1235dbf6544c4340a63baad9cbc6b285dd0da21e6149e9c72ed9a6cda26ed4a0` |
| `actions/common/ShuffleAction.java` | `778652e6f1d1db01ceb83b906d0c15548a14aa4464244f5e82198524fb5405c3` |
| `actions/utility/DiscardToHandAction.java` | `b0747e280d603d8748cdaf30c91402017991a89d4039d254e940f63529a01adf` |
| `powers/AbstractPower.java` | `37a6e97bc1a7a3d0cbfe93fd07e9f809690f7c02f24fd45ec34892466b6e0f9f` |
| `dungeons/AbstractDungeon.java` | `8fa0712818487a360c72950d053fe77e1a35efa967080723d15c69037092fd26` |
| `cards/AbstractCard.java` | `bcd472ececfd8ce4150ccd4eb6dd07a2e2dc43e139196fe00de34705cf1a2a61` |
| `helpers/CardLibrary.java` | `ac123d5376862fb1d1d382284e14a9dc0e955395f415265ae29f9aa8a2b6237a` |
| `cards/CardGroup.java` | `03de4e22ab22bedf1d90df72bdc83f033ff6aa776ad9d8f7259e1ee9293f7fa8` |
| `characters/AbstractPlayer.java` | `2720ba8dd7a216781a3b2fcb709f5ec67dc9b2559af25f7f6b89df1ef0947d95` |
| `cards/Soul.java` | `8e4105a9df83d93ad4f66d35c54b63720e90f71b80c7594a6faa454d19b545c0` |
| `actions/utility/UseCardAction.java` | `90213939af6d7ec83dea01bb2feef4ba762a93400dc1535732e2eebcdb6cab0f` |
| `actions/defect/EvokeAllOrbsAction.java` | `990960194b207b67518d21d4108afb539abee94122872acef561a9aa9bf7f773` |
| `actions/defect/RemoveAllOrbsAction.java` | `ced41554b9d7352ea96d7e67ea2464235712cfdfe0521f88de08286b7e5e6ddd` |
| `actions/common/PutOnDeckAction.java` | `16f2ab8615f93267325ea98a9d1ea6e38b79e79c4aa72c4284efbb1ec4c567af` |
