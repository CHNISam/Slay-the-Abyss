# 观者最后20张：定义、纯数据规则与核心依赖

固定来源为社区反编译镜像 `aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0`，目标为初代 PC A0。版本来自反编译快照，不是官方二进制认证；不加入下载的 Java 源文。

本切片交付卡牌定义及纯数据计划，尚未接入共享核心。真实出牌、全池生成、永久升级、额外回合和选择界面不能由组件绿灯代替。检索5文件、自动队列3文件及旧触发模块保持冻结。

## 母表相减与数值

按固定300张职业母表，PURPLE常规注册75张减去既有Profile37张、Watcher Flow18张，实际余下20张；没有把衍生／无色选项混入常规75。源类和 SourceID 均为 `Judgement`，本地ID为 `judgment`；预见源 SourceID 是 `Wireheading`，Power SourceID 为 `WireheadingPower`。

| 本地ID | 基础 | 升级差异与动作顺序 |
| --- | --- | --- |
| foreign_influence | 0费技能，生成3攻击选1，消耗 | 取得牌本回合费用置0；不会把候选直接升级 |
| conclude | 1费攻击，全敌12伤害，再提前结束回合 | 16伤害 |
| meditate | 1费技能，弃牌取1并保留，再平静，再提前结束回合 | 取2 |
| swivel | 2费技能，8格挡，再获得下1攻击免费 | 11格挡 |
| wave_of_the_hand | 1费技能，本轮格挡正数回调给全敌1虚弱 | 2虚弱 |
| foresight | 1费能力，之后回合开始占卜3 | 占卜4 |
| alpha | 1费技能，随机插入未升级Beta，消耗 | 先天；不会自动升级Beta |
| blasphemy | 1费技能，神格，再施加下回合开始死亡能力，消耗 | 保留 |
| conjure_blade | X费技能，将攻击X次的Expunger随机放入抽牌堆，消耗 | 攻击X+1次 |
| deus_ex_machina | -2不能打出，真正抽到后先消耗自己，再生成2张普通Miracle | 生成3张 |
| deva_form | 3费能力，虚无，恢复能量时取得递增能量 | 去除虚无 |
| judgment | 1费技能，目标生命≤30则直接将其生命置0 | 阈值40 |
| lesson_learned | 2费攻击，10伤害；实际击杀后永久随机升级；消耗 | 13伤害 |
| master_reality | 1费能力，生成入口升级非状态／非诅咒牌 | 0费 |
| omniscience | 4费技能，抽牌堆选1免费打出2次，原实例消耗，副本purge；自身消耗 | 3费 |
| ragnarok | 3费攻击，5次随机目标5伤害，每次独立重新计算 | 6次6伤害 |
| spirit_shield | 2费技能，每张其他手牌提供3基础格挡 | 每张4基础格挡 |
| wish | 3费技能，三选一：3力量／25金币／6多层护甲，消耗 | 4／30／8 |
| establishment | 1费能力，回合末保留手牌战斗费用降1 | 先天；降费量不变 |
| vault | 3费技能，先设置跳过敌方回合，再提前结束玩家回合，消耗 | 2费 |

六个附属定义不进入常规职业池：Beta（2费／升级1费，生成普通Omega，消耗）、Omega（3费能力，回合末全敌50／60 THORNS）、Expunger（1费攻击，每次9／15伤害，次数保存在实例 `expungerHits`）、BecomeAlmighty／FameAndFortune／LiveForever 三个 Wish 选项。三个选项保留源类型与-2费用，设置 `optionOnly=true`，选择直接执行选项效果；不能生成到手牌或永久牌组来模拟选择。

## 源时序和容易混淆的分支

**冥想**沿用 MeditateAction 而非简单的 Hologram+retain。来源为空直接完成，后续平静和结束回合仍按队列继续。来源数量≤请求数量时自动取全，先给所有候选 `retain=true`，即使手牌满而未移动的弃牌也得到该暂态；手选分支只在成功入手时赋retain。满手牌不会借机触发虚假弃牌／抽牌钩子。已有 Hologram／Seek 选择模块的模式表没有 Meditate，本切片仅给出 typed choice 计划，root须扩展并保持generation／token／原子恢复。

**全知**从抽牌堆手选1张，只有1张时源仍打开选择。选中的原实例设置战斗 `exhaust=true`、移出抽牌堆，并BOT安排第一次 NewQueueCardAction；第二次由 `makeStatEquivalentCopy` 创建新来源身份的副本，设purge后BOT入队。与 DoubleTap 的 makeSameInstanceOf 保留来源UUID不同，全知副本必须由host使用独立 `nextSourceUid` 分配新来源身份，不能把新combat UID当sourceUid。两项均randomTarget=true，目标在各自真正取得cardQueue执行权时随机选择；能量也在各自 NewQueueCardAction.update 时快照。不能在选择时共享一个目标或抢在原牌普通动作前执行第二遍。

原牌的动态 `exhaust` 必须进入 cardDefinition／UseCard耗尽捕获；Power仍走原生empower早退，purge副本仍优先于所有耗尽。纯数据 `limbo` 所有权和原视觉limbo不是相同时点的容器；详见自动队列文档。

**化剑为犁与终结**：ConjureBladeAction 使用排队前传入的 energyOnUse；-1哨兵才回退当前能量。升级在构造该动作前把X加1，Chemical X再加2。即使最终次数0也生成一张Expunger。非freeToPlayOnce时耗尽执行时所有当前能量。先对未升级Expunger设置X，后续 MasterReality 的升级只提高伤害，不补攻击次数；Expunger.setX在本已升级对象上调用时会加一次，但不能把这条规则错误套在先setX再upgrade的常规Conjure路径。

**预见**在回合开始、正常抽牌前工作；抽牌堆空时TOP安排EmptyDeckShuffle，再BOT Scry。选择结束才继续其后队列与抽牌，不能把未选的占卜跳过。**机械降神**只在真正triggerWhenDrawn执行，addToTop(make)后addToTop(exhaust)使最终执行顺序为先消耗原实例，再生成Miracle；检索回手或生成入手不调用该抽到事件。

**渎神**的 EndTurnDeath 是BUFF，不能当普通debuff被纯净移除。下回合开始BOT安排 LoseHPAction99999，再移除能力；它是正常HP_LOSS伤害入口，不能直接赋玩家hp=0，Intangible等真实damage阶段仍有意义。**审判**恰好相反：InstantKillAction先把敌方生命直接设0，再调用0点HP_LOSS刷新死亡；不是对敌人造成其当前生命数量的伤害。

**天人形态**有两个量：Power.amount是每回合的增长率；额外状态 `state.devaEnergyGain` 初始1。每次 stackPower，amount按传入值增加，而energyGainAmount立即加1；恢复能量时先获得旧gain，再将gain增加amount。不能只保存一个“层数”并每回合加1。

**挥手**必须接 `AbstractCreature.addBlock` 的准确回调。源先由玩家遗物变换float格挡，若该值>0，立刻调用玩家powers.onGainedBlock；之后怪物powers才修改该float，最后floor并加到格挡、cap999。因此999满格挡、0.25被floor成0、怪物随后把格挡变0，都仍可触发挥手。不要按实际格挡增量判断。回调BOT给每个怪物安排WeakPower(amount,false)，而非TOP；在endOfRound移除。

**旋转**的 FreeAttackPower 参与freeToPlay／能量门槛及支付。UseCard构造时非purge攻击消耗1层，归零TOP移除；purge重复不消耗。该能力没有回合末自动移除，不能把它简化为“本回合下一次”。

**确立基础**priority25，在回合末BOT安排动作，动作执行时才扫描仍在手中的retain／selfRetain。每张调用modifyCostForCombat(-amount)：若当前回合费用>0，用该费用减层数并同时写基础战斗费用；否则若基础费用非负，基础费用减层数而turnCost置0；-1／-2哨兵保留。这个顺序与回合末resetAttributes、保留成长和暂存手牌相互影响，不能在Power回调排队前提前扫，也不是永久牌组升级。当前旧Retained模块仍有establishment guard，root接入前必须核准并移除该拒绝，不能靠组件绕过。

**修习**在同一个伤害动作内判定实际敌人isDying或hp≤0；halfDead和Minion排除。有可升级永久牌时，按masterDeck原顺序建立候选，使用 `miscRng.random(0,n-1)`，原对象升级并做bottled升级同步。即使只剩1候选也不能跳过源随机调用。此后才执行末敌clearPostCombatActions，所以终结最后敌人的修习仍应永久升级。战斗卡不能被一起升级；反伤致死、奖励及永久Run.deck事务由root处理。

**诸神黄昏**每个 AttackDamageRandomEnemyAction 在执行时用cardRandomRng选活目标，并对该目标重新calculateCardDamage，再TOP安排一次普通DamageAction。不是提前一次随机并复用，也不是预先固定强度／目标易伤。**精神护盾**在use时重新applyPowers，按除自身外的当前手牌数生成基础格挡，然后普通Dexterity／Frail只算一次。

**创造现实**分入口调用upgrade：MakeTempCardInHandAction构造模板时、ShowCardAndAddToHandEffect构造时、ShowCardAndAddToDiscardEffect构造时、MakeTempCardInDrawPileAction.update复制后。各阶段分别保留；将来SearingBlow可多次升级，不得把整个过程简单去重为一个boolean。已有牌从其他牌堆取回、DoubleTap／Omni复制，不属于这些生成动作，不能一概升级。当前Core多处MasterReality guard仍未接，文档不宣称全生成路径已覆盖。

**异界之援**需要完整 CardLibrary 的已解锁、非HEALING攻击池，不是当前Profile子集。每次候选先cardRandomRng.random(99)：<55普通、<85罕见、其余稀有；再调用getAnyColorCard(ATTACK,rarity)，它按HashMap遍历建立候选、用cardRandomRng shuffle，随后getRandomCard(true,rarity)先按源cardID的Java compareTo排序、再用另一条 **cardRng** 选索引；重复SourceID则整个抽取重试。不能把两条随机流合并，也不能因shuffle后的列表又排序便省掉其RNG消耗。取得选择牌后stat-copy，升级版setCostForTurn(0)，再按手牌容量ShowCardAndAddToHand／Discard，后者各有MasterReality时点。本模块只声明完整pool契约；没有伪造来源概率或用可执行子集补齐三候选。

**腾跃**设置skipMonsterTurn后仍走完整玩家回合末和下个玩家回合开始；敌方不排动作，也不运行敌方回合末powers。这不是仅额外抽牌或重新填能量；敌方意图、计数、玩家debuff减层、Orb和Ethereal等须由root真实回合处理验证。提前结束还会按GAM.callEndTurnEarlySequence取消等待自动牌并安排清理，不能丢失对象。

## API 和接入契约

所有公开计划只返回纯数据，不修改state、运行规则、消费RNG或塞入函数。`withCards(data)`返回独立数据，追加20常规卡、6衍生／选项及9状态；已有Miracle复用，缺失时补完整定义；重复卡／状态拒绝。

- `adaptDefinition(state, instance, copiedDefinition)`：显示／基础效果适配SpiritShield和Expunger，并投影Omni实例exhaust。不得取代实际use时重新计算。
- `prepareEffect(state, effect, context)`：context提供真实target、instance及energyOnUse/freeToPlayOnce/chemicalX快照；Lesson固定普通伤害，Conjure固定X，SpiritShield固定baseBlock，Ragnarok保持逐次再计算。
- `planEffect(state, preparedEffect, context)`：返回 `{top,bottom,immediate,updates,consumeAllEnergy}`。top列表是期望执行顺序，host须反向pushTop；bottom正向append；immediate必须在当前真实回调内执行，不能排队延后。
- `planHook(state, statusId, hook, context)`：hook为turn_start、energy_recharge、turn_end_pre_cards、turn_end、round_end。Deva的updates在真实回调时按源时序应用，不与之后队列动作混在一起。
- `planPowerApplied`在实际施加前读旧Deva状态；`planUseCard/freeAttack`参与旋转合法性、支付及UseCard构造阶段。
- `planGainedBlock(state, floatBeforeMonsterModifiers)`与`planHpLost`分别接准确格挡回调、多层护甲真实HP伤害回调；多层护甲格挡是turn_end_pre_cards，掉层是外部NORMAL实际正伤害后的BOT ReducePower。
- `planDrawn`仅用于真正抽到；`planRetainDiscount`由降费动作执行时逐手牌调用，并使用未套Corruption实例覆盖的有效基础定义。
- `planMeditateChoice`返回UID对应移动／retain事实，`planOmniscienceChoice`返回原牌移动及两项排队计划；它们不拥有pending token/generation校验，必须位于root受校验的选择事务中。
- `planLessonResult`接受真实伤害后的目标状态及已筛选永久牌键，返回miscRng选择计划。`planGenerated`按前述四阶段返回upgrade调用，不抽象为全局生成替身。
- `wishChoices(bool)`返回固定三项typed纯数据，`planWishChoice(optionId,bool)`只允许该三项；root保存真实option pending/token/generation，确认后排队执行。option不是普通play，不额外付费、不增加牌组、不伪装可取消。

外部新操作均使用唯一族名：`gainWatcherFinalPower`及`watcherFinal*`；实际Power descriptor为 `applyWatcherFinalPower/removeWatcherFinalPower/reduceWatcherFinalPower`，避免与其他职业Final模块冲突。sourceId与statusId没有改名。

根核心仍需实现这些typed descriptors，统一canPlay／endTurn／potion gate、跨选择暂停、自动出牌历史与免费支付、Run.deck／masterDeck／sourceUid、miscRng、逐击RNG、HP_LOSS与InstantKill、准确block callback及持久化。`nextSourceUid`是独立来源分配器，不能复用nextUid；Expunger的新 `expungerHits` 还需纳入已核stat-copy映射。所有play／choose＋queue resume以及永久升级应由完整对象图事务覆盖，包括RNG、UID、sourceUID和原实例引用。

## 当前证据

`tests/lua/watcher_final_build.lua` 的30组**组件**通过，含真实Combat状态与实际源卡定义、20差集数目、六衍生、基础／升级数值、纯数据时序和失败无修改。测试明确输出 `WATCHER_FINAL_CORE_NOT_CONNECTED`。该私树尚无Flow模块副本，验证命令仅把现有 `/workspace/sts-flow/src/lua/?.lua` 加到Fengari解释器的临时package.path，测试文件本身没有绝对路径。根接入同树Flow后可直接运行 `node scripts/test-lua.mjs tests/lua/watcher_final_build.lua`。

临时 `/tmp/abyss-watcher-final-core-repro.lua` 对真实新增Conclude定义调用真实 `Combat.play`，当前报 `unsupported_effect:watcherFinalEndTurnEarly`，516ms、exit1。它如实证明Core未接，不把组件替身计为真实自动播放／额外回合通过。未跑全量、未提交或推送，未修改root共享文件。

## 固定来源与SHA-256

逐卡来源SHA均再次与已锁定registration.json核对。下表为原始固定Java事实输入，不是Lua成品hash。

| 文件 | SHA-256 |
| --- | --- |
| [actions/common/ApplyPowerAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/ApplyPowerAction.java) | `f64ce8511f961a1990f1909e2c55654fa6dbf1dc2f4f1f3d3a7156c2ec2a9d47` |
| [actions/common/AttackDamageRandomEnemyAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/AttackDamageRandomEnemyAction.java) | `2d5dce7ccb54cf086c5001d689bf08c5550c456e29048e0987af16f3bdc33c36` |
| [actions/common/DamageAllEnemiesAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/DamageAllEnemiesAction.java) | `3562ea16a19d0951b36198a4191fd48358c7cb408595ef2c503fc4b7763ec123` |
| [actions/common/ExhaustSpecificCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/ExhaustSpecificCardAction.java) | `86224fd382a494afef43efac62f33f92a08e5a4562be1a03409cb071eb1080b3` |
| [actions/common/GainBlockAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/GainBlockAction.java) | `e48f437c06b42dda312446a4b536aca54570d637e53087ac16f736d84bb5df4f` |
| [actions/common/InstantKillAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/InstantKillAction.java) | `7556f409834419a99a1f52261c816559a215c230f98b4632adaa25815de5bef5` |
| [actions/common/LoseHPAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/LoseHPAction.java) | `50c9ea9f1aef4a02ff9177d59517f61b03941e9770a23bc50bed8e3d60d69670` |
| [actions/common/MakeTempCardInDrawPileAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/MakeTempCardInDrawPileAction.java) | `c00b2da9c82d6e5fed1f638312a2af46dcd586bcd76e963f859e4417629ac2fe` |
| [actions/common/MakeTempCardInHandAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/MakeTempCardInHandAction.java) | `b089bb6fd688ffdd48ae9def57751f972429cad63f85ec80ee3f90593d5bbe25` |
| [actions/unique/EstablishmentPowerAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/EstablishmentPowerAction.java) | `8a87c9dfa4180ccc589182ef3af3069bfc2b316477d0ed6e887c6c39ee3c2750` |
| [actions/watcher/ChooseOneAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/ChooseOneAction.java) | `62464e9e386a03a3675c3fd49945147216022aba00dbeb39ebac23faebd80f71` |
| [actions/watcher/ConjureBladeAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/ConjureBladeAction.java) | `4bb4e7fb87cb3f2de0893adf8c29397d340285d40aa420bb31849903a9b7423d` |
| [actions/watcher/ForeignInfluenceAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/ForeignInfluenceAction.java) | `97c1b8101de36151b9e485e8716caa9c147a10ad25028458658b1bcf85a69604` |
| [actions/watcher/JudgementAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/JudgementAction.java) | `51f6d4317804065db26e8ad07c13eb6c586233fd82aca8c7a6ad2956758b86ca` |
| [actions/watcher/LessonLearnedAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/LessonLearnedAction.java) | `87940aa119c04b84a6c213c027816b436afb77d1ae0c0bec12dcaa53af1a5a0d` |
| [actions/watcher/MeditateAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/MeditateAction.java) | `aa5e21106251bcb3f731056c531eb7ea916deae918da2d78162f1dc17de1304e` |
| [actions/watcher/OmniscienceAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/OmniscienceAction.java) | `caf69d4a2d301da290e6787aaeb0d58f6ee99c77b83205a115a0b9a712cfaeaf` |
| [actions/watcher/PressEndTurnButtonAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/PressEndTurnButtonAction.java) | `c14a50913eb2dde8e2c6c497c3a1475cab307e2248f8b7ffa2b6c38fb8a04c28` |
| [actions/watcher/SkipEnemiesTurnAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/watcher/SkipEnemiesTurnAction.java) | `2dcf8bc1e218494ed91e03ae68e7c5c3c6a97be5c4afb5e36935e0c70fc7190c` |
| [cards/optionCards/BecomeAlmighty.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/optionCards/BecomeAlmighty.java) | `3f137dba81667f327cbc1e9d4776e6a56a9c0acc7e2797a2d909e0deffa17513` |
| [cards/optionCards/FameAndFortune.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/optionCards/FameAndFortune.java) | `28526bd042e4f071ccef88246688ff1fec1515d3f3ce0001866d5a2f2bd01fef` |
| [cards/optionCards/LiveForever.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/optionCards/LiveForever.java) | `3db1bfec542abf88854c5e437dcbb283780b1e2e42e67377c2fe86e1a9d05656` |
| [cards/purple/Alpha.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Alpha.java) | `3519bd67095b8f6ed767ca8ae0433b8fce6970969c357b1c8409759de2f7f930` |
| [cards/purple/Blasphemy.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Blasphemy.java) | `7b98c0e1258d44be982bccdbb7ebd6556b603def288cbff319064ea30c0f5017` |
| [cards/purple/Conclude.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Conclude.java) | `9a3b955b2514c06ab398635e3bdd2183874ab0243b1ece91fd7e542b6f128ab7` |
| [cards/purple/ConjureBlade.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/ConjureBlade.java) | `787959a0be8afd55013d1e118a5765d81106c7546f10eca43612c2af3190c857` |
| [cards/purple/DeusExMachina.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/DeusExMachina.java) | `90802bd08f5b3dfe22d5d44734cbffcc95c84c89e32797db52de482993cb2710` |
| [cards/purple/DevaForm.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/DevaForm.java) | `7d92e8b21cfbfa5b24120bdb08da02d52953fa7073f25b78c0918c72bb6844d5` |
| [cards/purple/Establishment.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Establishment.java) | `f9dc29107b67b80ce2e2b1421375bccda03bfa754bab9d0945fe775366dab27b` |
| [cards/purple/ForeignInfluence.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/ForeignInfluence.java) | `d439324d99b36446168d5c2f65ed47e73a745b271393aa3b64e717351c149ae0` |
| [cards/purple/Foresight.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Foresight.java) | `4fced9785ad876263ab389a888958a5125e69f6b42ef9718e6a1bf3f5feef469` |
| [cards/purple/Judgement.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Judgement.java) | `ec13ce9b983e9a5ad2ea3a973735cd7ef4fafffbb2eade62681fcb00f3a5028e` |
| [cards/purple/LessonLearned.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/LessonLearned.java) | `bea838e9cf204c6c6704775a1b134fe0eb418f0099bed5a8fdfde40eb10b5cfb` |
| [cards/purple/MasterReality.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/MasterReality.java) | `b471aadfcfbcc2f54e1c69d5ec729a094aeeaa5882984f0d998bed5587325b9d` |
| [cards/purple/Meditate.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Meditate.java) | `024805c0af210129265c32b3d7a999d46000dfa7cdaee5e7d31d842aee363c5c` |
| [cards/purple/Omniscience.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Omniscience.java) | `0615e90eb41f4bf20cc36130805913bfeaf0988cf9850c3b7cd4a8caa3af7a23` |
| [cards/purple/Ragnarok.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Ragnarok.java) | `f5ceb1646b30b16bb6c4c4131ea5a9fdcade8287010df82e277e81ee60fa305f` |
| [cards/purple/SpiritShield.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/SpiritShield.java) | `841903c925e019470dce050ad61fca884e10f1961dc5ebc01849a16507b8dbad` |
| [cards/purple/Swivel.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Swivel.java) | `70846c7b50f75ee5211797741c221c63788078cbc958de7d2fe99d2cf63d7b73` |
| [cards/purple/Vault.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Vault.java) | `2307085f6c8c4f13afcbcbcdcd5cf6e29737718b7ebc42052b092073e419080e` |
| [cards/purple/WaveOfTheHand.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/WaveOfTheHand.java) | `db3b7d6e3a9ca514db8e3bd1ee9c506adf0cb38781df940d832b3afb6f2b0a58` |
| [cards/purple/Wish.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/Wish.java) | `24abdf1fb1b044674d6d1c8c2bfd31638928c2da65b7557c4dd8b7cb84b33746` |
| [cards/tempCards/Beta.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/tempCards/Beta.java) | `9bef8bf3614263441c3b49815dc70b0def1710f3eaf80ec1067850fc223cbe2b` |
| [cards/tempCards/Expunger.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/tempCards/Expunger.java) | `767dad251d9b812e03a395a71f88902d67901bb4ce502bb1fb4a34bc920956d6` |
| [cards/tempCards/Miracle.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/tempCards/Miracle.java) | `25cc7817d616acd13bb693303bac24e8251135f1feb89705bad53ac8497179e6` |
| [cards/tempCards/Omega.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/tempCards/Omega.java) | `5361b6718d45a86a431b59d5f95a149e40a39a0bce24857f9d3455390befc57f` |
| [core/AbstractCreature.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/core/AbstractCreature.java) | `3db6e08c6bd033192aa368e29ad53f4614194898ccf0f525480fe20cb8799f2b` |
| [helpers/CardLibrary.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/helpers/CardLibrary.java) | `ac123d5376862fb1d1d382284e14a9dc0e955395f415265ae29f9aa8a2b6237a` |
| [powers/PlatedArmorPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/PlatedArmorPower.java) | `686dbc797a8b2649d36a5332f45037202b17f5213481b11f5a9efd9613013df3` |
| [powers/watcher/DevaPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/DevaPower.java) | `bd83307945fddcc08aaede554f8f3d5f80db63dcf3cae9997682efcc6e1bd1fc` |
| [powers/watcher/EndTurnDeathPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/EndTurnDeathPower.java) | `e303c1ac436e342f73126a7030c4c16a3455254d322f3111b7429e03b2524743` |
| [powers/watcher/EstablishmentPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/EstablishmentPower.java) | `35765432dda3b2a217b13fa28f1a68162086decbdf4af51edf9f5ac7d211feb5` |
| [powers/watcher/ForesightPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/ForesightPower.java) | `8701aed3d7472196303fb11443b548295b1234b61d42304dea764fcfee51bb76` |
| [powers/watcher/FreeAttackPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/FreeAttackPower.java) | `e6ca10370624f5972c703c0cf4111c101dab599d06e956019bce60e90a599eb4` |
| [powers/watcher/MasterRealityPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/MasterRealityPower.java) | `2996c6d613647652c7af82604f4688b6d615a27265943ef84ba1f70ae1946c87` |
| [powers/watcher/OmegaPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/OmegaPower.java) | `7850e985ddf41008ca2411db19d9e16c449bfeedef41726e0afde024cc0e73f7` |
| [powers/watcher/WaveOfTheHandPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/WaveOfTheHandPower.java) | `48de0ee54bbccd2da40ca3e2ba6c38c61ba12bc0543cca78d637e644334644a9` |
| [vfx/cardManip/ShowCardAndAddToDiscardEffect.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/vfx/cardManip/ShowCardAndAddToDiscardEffect.java) | `9386ebe73aabf208e05f23068e168921f8db069151947d7ed4582308e2198d80` |
| [vfx/cardManip/ShowCardAndAddToHandEffect.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/vfx/cardManip/ShowCardAndAddToHandEffect.java) | `e0ac9f16f627a985920857080a2a9e2ef903e7f0db0741b57709de99b52202ef` |
| [cards/AbstractCard.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java) | `bcd472ececfd8ce4150ccd4eb6dd07a2e2dc43e139196fe00de34705cf1a2a61` |
| [cards/CardGroup.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/CardGroup.java) | `03de4e22ab22bedf1d90df72bdc83f033ff6aa776ad9d8f7259e1ee9293f7fa8` |
