# 伤害防御阶段公共适配

仅新增纯数据适配与组件测试，不改Actor、Combat、HP-loss或SharpHide运行时。此交付不能证明无实体/缓冲/静电释放已在全部真实伤害路径接好。

## 来源与唯一实现

固定社区镜像 [aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0](https://github.com/aeubanks/sts/tree/319009d5df0a82d9fb0f23cc22322286c6a87ec0)，声明V2.3.4 / 2022-12-18；非官方源码或认证PC二进制。只提取规则事实，独立编写适配，无方法体复制。

新`abyss_damage_defenses`不重复实现三种Power：

- `beforeBlock`委派现有`abyss_silent_final_cards.capIncomingDamage`。
- `afterBlock`委派现有`abyss_defect_final_cards.incomingPlan`，Buffer/Static仍由该helper唯一拥有；减层仍沿DefectFinal.reducePower维护SourceSchedule，不手写另一套减层。
- 新模块只负责验证显式伤害类型、组合阶段、提供纯预览与队列存活守卫；不注册第二份Power，不保存函数进state。

本轮实际依赖字节摘要：SilentFinal `71ab76dd7cf2b0af6ae7c6c87db63cf718e0b2afc39441c4914394454d585e0f`；DefectFinal `207351ca2d4777e4fdaf0c6856ff8b701774579147c7d3c327cdbd2ad6208611`。两者接口已与Defect执行agent交接；主线程后续修改依赖时应按新字节重新定向验证。

## 源接收顺序

```mermaid
flowchart LR
  A[DamageInfo输出及最终接收修饰] --> B[IntangiblePlayer: 大于1钳到1]
  B --> C{HP_LOSS?}
  C -->|否| D[消耗Block]
  C -->|是| E[跳过Block]
  D --> F[onAttackedToChangeDamage: Buffer]
  E --> F
  F --> G[onAttack及onAttacked: Static只排队]
  G --> H[onLoseHpLast及onLoseHp等其余修饰]
  H --> I[扣HP与死亡/结果检查]
  I --> J[仍活跃时继续TOP反应队列]
```

此图只标本切片需要的阶段，不能删除Actor里已有onAttack、onAttacked、onLoseHpLast、onLoseHp、wasHPLost、onInflictDamage与死亡钩子。

IntangiblePlayerPower的priority=75。`atDamageFinalReceive`不按DamageType排除；`AbstractPlayer.damage`又在decrementBlock之前将大于1的输出钳到1。NORMAL、THORNS、HP_LOSS均适用，0不变1。NORMAL/THORNS随后仍消耗Block，HP_LOSS跳过Block。Power存在但层数为0时仍有效，直到排队移除；不能只判断amount>0。治疗不属于本接口。

BufferPower在`onAttackedToChangeDamage`返回0，检查Power存在（包含0层），原damageAmount>0才TOP排ReducePowerAction1；完全被Block抵消或原0伤不消耗。HP_LOSS、THORNS、自伤、null owner均可挡；不是仅普通外来攻击。不能提前直接删层代替源TOP动作。

StaticDischargePower在`onAttacked`仅当NORMAL、owner非null且不是受击者、该阶段amount>0，TOP排对应数量的ChannelAction(Lightning)。它发生在Buffer之后、扣HP之前，但**只排动作，不在扣血前执行生成**。Defect现有描述符将同类动作压为`engineChannelRounds(orb=lightning,remaining=N)`，host逐次执行，不可用乘法伤害代替。

“正伤害”特指onAttacked阶段值，不是最终HP差。源随后才调用Relic.onLoseHpLast/Power.onLoseHp；例如以后某遗物将1变0，Static可能已经排队，不能事后按最终HP差撤销。此切片没有认证尚未接完的所有遗物复合链。

## 精确API

`info(owner,target,type)`构造并验证临时DamageInfo记录；type只允许`NORMAL`、`THORNS`、`HP_LOSS`，owner可nil或已死亡Actor。返回真实Actor引用，不存入typed队列；队列effect仍是纯数据。不得根据字符串status或fixed布尔值猜damage type。

`beforeBlock(state,info,amount)`返回Intangible之后的数值，无Block/HP/Power变化。

`afterBlock(state,info,postBlock)`返回DefectFinal的纯计划，含amount、top、bottom及其原有空变更字段。量是接收阶段amount，不是已扣HP；不能把它传给纯onHpLost钩子冒充已失血。host按执行顺序逆序pushTop，BOTTOM顺序append。

`planHit(state,info,rawAmount)`是组合**预览**，返回raw、beforeBlock、blocked、blockAfter、postBlock、amount、top、bottom；全部无副作用。它只包含上述Power与Block，不跳过其他接收钩子。如果host已经扣过Block，必须分调用beforeBlock/afterBlock，不能再用planHit重复扣Block。

`mayExecuteQueued(state)`要求玩家HP>0、phase为player/enemy、还有未逃跑的活敌。命中可能在HP扣之前产生Static计划，但扣血后玩家死亡或战斗结束时不能继续channel。不要把该函数用于战前普通生成或所有通用动作，范围仅本类伤害反应。

`needsQueue(state,info?)`在Buffer存在（即使0）或Static存在可触发时提示进入真实队列。单Intangible不需队列。多段伤害必须把每段作为独立DamageAction推进，使Buffer的TOP减层在下一段之前执行；不能legacy for-times伤害循环结束后才处理一次减层。计划不直接消耗Power也不自己运行队列。

## 主线程接入位置

| 真实通道 | 必须显式的类型及位置 |
|---|---|
| Actor.damage普通攻击 | attackAmount/normal快照之后beforeBlock；真实消耗Block后afterBlock；原onAttack/onAttacked顺序合并计划，扣HP后才继续queue |
| Actor.retaliate/Thorns/FlameBarrier | THORNS，同样先Intangible后Block/Buffer；不触发Static，无普通攻击加成与递归Thorns |
| Actor.directDamage毒等 | 按原源动作明确HP_LOSS；若此前调用者已经消耗Block，不在本处再扣；source owner按已认证来源保留，不制造假活Actor |
| Effects.loseHp、Mark LoseHP、Combust等 | HP_LOSS，跳Block；仍先Intangible，再Buffer及其它真正失血修饰；实际HP正损后才notify，共享MasterfulStab/Rupture等只通知一次 |
| Guardian.afterCard捕获SharpHide | THORNS；已有captured伤害可在SharpHide owner死亡后存在，不得要求攻击者仍活；Intangible beforeBlock，再Block/Buffer。事件sourceId与实际owner引用分开保留 |
| Buffer/Static内部动作 | queue handler消费reduceDefectPower/engineChannelRounds；先完成当前hit扣HP/死亡判定，再调用mayExecuteQueued；dead/terminal不运行 |

直接改HP的路径不能只在`abyss_hp_loss.notify`里补Intangible/Buffer，因为那时HP与Block已经写入且事件可能已发。notify负责真正损血后的统计；防御要放在之前的接收阶段。给Actor每种调用者显式kind，避免fixed伤害错误被当NORMAL。

## 本轮组件验证

`tests/lua/damage_defenses.lua`20组全部通过，`DAMAGE_DEFENSES_COMPONENT_PASS 20`，221ms、exit0。覆盖三种伤害类型、Intangible0层与0伤、Buffer0层、完整Block不扣Buffer、Static外来/自伤/null/THORNS/HP_LOSS排除、三种Power组合、致命伤只计划但不能执行、队列谓词、非法输入、真实helper委派及无副作用。

当时flow尚未复制DefectFinal，新测试通过临时runner仅追加该agent真实模块的package.path：`node scripts/test-lua.mjs /tmp/damage-defenses-run.lua`。runner调用的是本仓库测试和真实生产helper，没有替换函数或mock队列handler；没有为过测修改现有src。主树复制两Final依赖后标准命令是`node scripts/test-lua.mjs tests/lua/damage_defenses.lua`。

这些测试只验证组件计划，不是Actor/Core/SharpHide/HP-loss运行时已接入证据。运行时还需各通道真实命中、逐段Buffer消费、致命Static不生成、原引用事务以及既有伤害回归；本切片不冒领这些结果。无共享代码修改、无全量套件、无提交推送。

## 固定源字节摘要

| 固定文件 | SHA-256 |
|---|---|
| [actions/common/LoseHPAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/LoseHPAction.java) | `50c9ea9f1aef4a02ff9177d59517f61b03941e9770a23bc50bed8e3d60d69670` |
| [actions/common/ReducePowerAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/ReducePowerAction.java) | `c38b05e84a781f97d4f87fa8bf374ef145a7c72137e16f8a388f7a612f9425a8` |
| [actions/defect/ChannelAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/defect/ChannelAction.java) | `65f0d9de68e7b57158e2ee460375760854df1146447eee6083eb028bbd5e647d` |
| [cards/DamageInfo.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/DamageInfo.java) | `cc16469d78473a1d37bf18a152014d9d1625859a5a7bd0923387f4ee8d942a5a` |
| [characters/AbstractPlayer.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/characters/AbstractPlayer.java) | `2720ba8dd7a216781a3b2fcb709f5ec67dc9b2559af25f7f6b89df1ef0947d95` |
| [core/AbstractCreature.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/core/AbstractCreature.java) | `3db6e08c6bd033192aa368e29ad53f4614194898ccf0f525480fe20cb8799f2b` |
| [powers/BufferPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/BufferPower.java) | `c37a54fe614dd9588e298e9d2de0d283bb45c31b58f8aeae7447676093502b60` |
| [powers/IntangiblePlayerPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/IntangiblePlayerPower.java) | `62ca9eecfd78e5b5a018ef069147d36bd58463b9754c8359d5dfb710bb6c52c8` |
| [powers/SharpHidePower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/SharpHidePower.java) | `a7cf449a907ca34569059aca1310619deb597d32cdd84201815d024614ff576a` |
| [powers/StaticDischargePower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/StaticDischargePower.java) | `93b86d1b514f5da259978d98e45061dc0483ba48fbfd9e09882df6faa15d94ef` |
| [powers/ThornsPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/ThornsPower.java) | `78ce7c63874a3539f03c50a9cdfdf8bcfba7b47e73bce18c10672e5bad3ae87a` |
