# 正数格挡回调：Juggernaut与Wave of the Hand

独立 `abyss_block_triggers` 只聚合源onGainedBlock规则并返回纯数据计划；不接Actor、不修改Core或Final卡牌模块，也不在回调中直接伤害敌人。固定来源为社区镜像 `aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0`；只提炼规则，不复制实现或资源，不冒充已认证官方二进制。

## 正确输入时点

AbstractCreature.addBlock(int)第412–438行先把入参变为float tmp，依玩家遗物顺序执行onPlayerGainedBlock，再对tmp>0依玩家Power列表调用onGainedBlock。之后才调用怪物Power的onPlayerGainedBlock，再floor并加currentBlock，最后封顶999。

因此模块输入是**玩家遗物修正后、怪物修正/floor/cap/实际delta之前的float**。它不是卡牌原始baseBlock，也不是最终增加量。卡牌自身Dex/Frail在计算卡牌block时已处理，不能在本回调再算一遍。

- 输入0.25即满足源hook条件，即使最后floor为0。
- 当前999盾仍收到正数输入，也触发；不能用最终delta=0跳过。
- 输入0或负数不触发；非有限数/错误类型明确拒绝。
- 源仅在isPlayer路径调用此组Power hook；敌人加盾不能触发玩家Juggernaut。

## 两种Power的源计划

| Power | onGainedBlock的BOTTOM结果 | 执行时行为 |
| --- | --- | --- |
| Juggernaut | 一个DamageRandomEnemyAction，DamageInfo.owner为玩家、type为THORNS、amount为能力强度 | action执行时使用cardRandomRng选当前活敌，再TOP排DamageAction |
| WaveOfTheHandPower | 按hook时怪物列表顺序，对每个原怪物分别排ApplyWeakAction，source玩家、isSourceMonster=false | ApplyPowerAction执行时检查原目标是否死亡/逃跑；Artifact逐目标处理 |

Juggernaut的随机目标不能在加盾时提前选。MonsterGroup.getRandomMonster(null,true,rng)排除halfDead/isDying/isEscaping；项目同时用hp与escaped标志表示已死/逃离。单活敌仍random(0)，没有活目标不调用RNG。THORNS不经过普通Strength/Weak/Vulnerable修正，不触发普通攻击Thorns/CurlUp/Envenom。

Wave回调源码没有预先过滤活目标，它给当前原怪物列表逐个构造ApplyPowerAction。因此模块捕获每个原targetId，包括当时已经死亡的目标；执行时再过滤。不能用一个延迟执行的applyStatusAll扫描届时的新列表，否则可能给源hook发生之后生成的新敌人施加虚弱。

Wave源码在atEndOfRound排RemoveSpecificPowerAction，不是在玩家endTurn立即消失。该轮敌方阶段的正数格挡仍可触发；下一轮开始前移除。Juggernaut不因此移除。

## 优先级与终局

Juggernaut和Wave的constructor都未改priority，继承AbstractPower的5。ApplyPowerAction首次加入时按priority稳定排序，AbstractPower.compareTo只比较priority；同priority按首次获得顺序，叠加保留原位置。BOTTOM结果按该顺序追加，不能按ID排序。

顺序会有实际影响：只剩1HP敌人且有Artifact1时，Juggernaut先获得会先排随机伤害，杀敌后原Wave尾取消，不消耗Artifact；Wave先获得则先消耗Artifact，之后Juggernaut杀敌。测试覆盖这两种结果。

模块在宿主已标记victory/defeat或玩家死亡后不创建新计划。执行期无活目标的Juggernaut返回空计划且无RNG。宿主仍负责真正的clearPostCombatActions语义：Wave的ApplyPower尾会取消，Juggernaut对应DAMAGE可保留到随机目标检查后自然空转。这个模块不把清队列简化成所有新动作的永久过滤器，也不宣称覆盖未来复活/不能失败房间的全部生命周期。

## 接口

所有返回值均为纯数据 `{top={},bottom={}}`，动作包装为 `{kind='effect',effect={...}}`。TOP数组表示执行顺序，host反序pushTop；BOTTOM照顺序pushBottom。

- `plan(state,actor,preFloorPreCapFloat)`：只读聚合。actor须为player且输入正数，按abyss_power_schedule.list(actor,filter)生成BOTTOM动作。没有递归伤害、没有随机数调用、没有状态写入。
- `planRandomDamage(state,effect)`：接受blockTriggerRandomDamage，执行时读取当前活敌，克隆RNG并返回cardRandomRng及TOP blockTriggerDamage。host用现有Flow.commitRng在事务中提交，不替换原RNG或primitive对象。
- `planWeak(state,effect)`：接受blockTriggerWeak，查捕获的targetId并复验，返回一条标准applyStatus weak。owner为player，sourceIsMonster=false；无效目标返回空计划。
- `planEndRound(state,actor)`：为仍有Wave membership的玩家排blockTriggerRemoveWave。host实际移除时同步Power schedule，不能只清状态数值留下陈旧记录。
- `definitions()/ids()`：提供这两个Power的独立中文定义及过滤ID。规范status IDs是juggernaut和wave_of_the_hand，后者与WatcherFinal一致；没有别名。

注册Power获得/移除由root在真实成功时调用共享recordApplied/remove；模块不自行猜测顺序。单个旧fixture Power可复用registry已有无歧义fallback，两个未记历史的活跃Power明确拒绝，不能临时按字母补历史。priority元数据不为源值5也拒绝。

内部op分别为blockTriggerRandomDamage、blockTriggerDamage、blockTriggerWeak、blockTriggerRemoveWave。root应把标准addBlock入口统一分发到本聚合，替换Final Juggernaut与Watcher Wave原先各自的onBlock分发，避免重复触发。其他真实加盾路径（FNP、Metallicize、药水、Rage、Entrench等）也需要覆盖；保留旧盾与resetBlock不是新加盾。

## 验证范围

`node scripts/test-lua.mjs tests/lua/block_triggers.lua`：`BLOCK_TRIGGERS_PASS18`，exit0，约1秒。覆盖：

- fraction、999 cap、零/负/无效输入与非玩家owner；纯计划前后全图不变。
- 两种获取顺序、叠加不重排、缺历史拒绝。
- 延迟活目标过滤、单敌random(0)、无敌/终局零RNG、克隆与提交保持原RNG对象和primitive引用。
- 真实Combat/Actor的固定伤害扣盾及不反Thorns、Wave捕获原targetId不影响后生成敌人、Artifact与末杀的顺序差异。
- BOTTOM不抢在已有action前，Wave轮末移除仅删除自身记录。
- 真实Queue已执行伤害、消耗随机数并施加Weak后故意抛错；外层Snapshot恢复所有原表/卡牌属性/事件/队列/RNG及primitive引用，随后重试只结算一次。

测试使用组件host解释新typed op，再调用真实Combat/Actor方法，没有替换它们的规则。Power注册夹具使用真实Actor.applyPower及共享registry；这不是Actor.block已完成接线的真卡整链证明。root完成共享hook后仍需结合Final/Watcher等真实出牌回归。未跑fullsuite、提交推送或平台/实机验收。

## 固定来源SHA-256

| 固定来源 | SHA-256 |
| --- | --- |
| [actions/common/ApplyPowerAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/ApplyPowerAction.java) | `f64ce8511f961a1990f1909e2c55654fa6dbf1dc2f4f1f3d3a7156c2ec2a9d47` |
| [actions/common/DamageRandomEnemyAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/DamageRandomEnemyAction.java) | `f5bec8e7131c871fc52441b8b1f38a6b7224cf77a66349e1527647bd589e5d38` |
| [cards/purple/WaveOfTheHand.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/purple/WaveOfTheHand.java) | `db3b7d6e3a9ca514db8e3bd1ee9c506adf0cb38781df940d832b3afb6f2b0a58` |
| [core/AbstractCreature.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/core/AbstractCreature.java) | `3db6e08c6bd033192aa368e29ad53f4614194898ccf0f525480fe20cb8799f2b` |
| [monsters/MonsterGroup.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/monsters/MonsterGroup.java) | `535770201b8aa8de01b52b185979af537f11ad0862e7d3e71ebb20cc64234221` |
| [powers/AbstractPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/AbstractPower.java) | `37a6e97bc1a7a3d0cbfe93fd07e9f809690f7c02f24fd45ec34892466b6e0f9f` |
| [powers/JuggernautPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/JuggernautPower.java) | `95710b68f4ef9e20b1e5b3fcfb2ead2afe54b0fad5173d205e1b690ed81d19f2` |
| [powers/WeakPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/WeakPower.java) | `17072c70ffbf219440dea75069910630d745654c4bf58cf528e937a7d747d973` |
| [powers/watcher/WaveOfTheHandPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/watcher/WaveOfTheHandPower.java) | `48de0ee54bbccd2da40ca3e2ba6c38c61ba12bc0543cca78d637e644334644a9` |
