# 猎人最后14张牌的独立规则与接入契约

本切片只新增卡定义、纯数据计划及指定实例钩子，仍由真实Combat管理动作队列、选择暂停、自动出牌、HP变化与原引用事务。当前不是14张均已可玩的交付。前一批20张战术牌已经在共享flow基线完成60/60（3361ms），本文件不把该证据算作本批通过。

## 固定来源与范围

公开社区反编译镜像 [aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0](https://github.com/aeubanks/sts/tree/319009d5df0a82d9fb0f23cc22322286c6a87ec0)，声明V2.3.4 / 2022-12-18；非官方源码或认证PC二进制。独立复述规则、独立实现，无原方法体复制。每个固定文件的SHA-256在末尾。

中文name/text为项目编写的可读说明，未声称认证原版中文译文。生成/复制只描述有证据的字段与行为，不能默认为任意模组、任意外职业牌或遗物复合机制均兼容。

| source class | 稀有度 | 费用基础→升级 | 数值/标记 |
|---|---|---|---|
| Distraction | uncommon | 1→0 | 随机技能本回合费用0；消耗 |
| EndlessAgony | uncommon | 0 | 伤害4→6；实际抽到时复制一张；消耗 |
| MasterfulStab | uncommon | 0 | 伤害12→16；每个正HP伤害事件费用+1 |
| Setup | uncommon | 1→0 | 手牌1张放抽牌堆顶；基础费用>0则freeToPlayOnce |
| WellLaidPlans | uncommon | 1 | 回合末至多保留1→2张 |
| BulletTime | rare | 3→2 | NoDraw后当前手牌setCostForTurn(-9)；不消耗 |
| Burst | rare | 1 | 接下来1→2张技能额外实际打出一次；本回合 |
| CorpseExplosion | rare | 2 | 先毒6→9，再尸爆1；不消耗 |
| Doppelganger | rare | X | 下回合额外能量与抽牌X→X+1；消耗 |
| Nightmare | rare | 3→2 | 选手牌1张，下回合3张复制；消耗 |
| PhantasmalKiller | rare | 1→0 | Phantasmal1，下回合NORMAL双倍 |
| ToolsOfTheTrade | rare | 1→0 | Power1，额外抽1再弃1 |
| Alchemize | rare | 1→0 | 药水随机获取；消耗；HEALING tag |
| WraithForm | rare | 3 | Intangible2→3，然后WraithFormPower(-1) |

## 纯计划与共享接入

`withCardDefinitions`独立拷贝并严格拒绝重复14张card id；9种power含中文说明和源priority。`M.ops`列出7种公开新op。`prepareEffect`和`planEffect`不能替代真实战斗执行。plans的top/bottom均为执行顺序，host逆序pushTop、顺序pushBottom；上下文函数不保存进state。

- `setup`→TOP finalHandChoice(mode=setup,count1)。空手跳过、单剩余牌自动、更多牌必须真正选择/token/暂停。`planChoice`产生setupToDrawTop，保持原instance；检查**当前基础cost**（combatCost或upgrade后定义）>0才赋freeToPlayOnce，已有true不能因该次不满足而清除。不是turnCost=0，不能把X牌变成固定免费X；不是只减一次临时费用。入抽牌堆顶不是随机插入。
- `bulletTime`→TOP applyNoDraw然后zeroHandTurnCosts。NoDraw重复/Artifact规则沿真实ApplyPower路径；即使被Artifact挡，后面的降费动作仍执行。setCostForTurn(-9)仅当前costForTurn>=0的牌变0，X(-1)/不能打(-2)不改；后续抽到/生成的牌不会自动免费。实例turnCost由现行回合重置机制恢复，不另存第二份费用。
- `doppelganger`按energyOnUse（nil/-1才读当前energy）加升级+1，>0则BOTTOM nextEnergy(N)、gainSilentFinalPower(draw_next_turn,N)，非free消耗当前全部能量。基础0X不创建power；升级0X各1。Chemical X未支持时显式拒绝，不能静默忽略。
- `gainSilentFinalPower`→TOP applyFinalPower。Wraith的负数原amount必须按DEBUFF扱，不能因为负数判成无效或改成正BUFF。带constructorAmount时必须保留新Power构造值与已有Power叠加raw值差异。
- `nightmare`→真正选择一个目标，仍保留原牌。`planChoice`冻结stat-equivalent/reset-turn模板，随后returnChoiceHandTop再applyNightmare3：选牌从屏幕返回时源addToHand是hand尾(顶)，不能漏掉对后续随机弃牌顺序的影响。自动单牌原顺序自然不变。同NightmarePower已存在时**只叠数量，保留第一次的模板**；不能替换成后选牌。下回合preDraw生成n张再移除power/template。

### 实际复制与自动出牌

`copyTemplate(state,instance,resetTurn,sameSource)`只返回没有runtime uid的纯数据模板。当前映射upgraded、combatCost/turnCost、freeToPlayOnce、damageBonus、GlassKnife/Eviscerate/Shiv/retained基础修饰与misc。Source makeStatEquivalentCopy复制升级次数/当前baseDamage/baseBlock/baseMagic/baseCost/costForTurn/freeToPlayOnce等，但不复制临时retain/purge标记。Nightmare随后resetAttributes还原turnCost至baseCost，**并未清freeToPlayOnce**。未列出的外部基础修饰不声称已支持。MasterReality生成复合明确拒绝。

host创建每个副本时必须分配新的安全combat UID，不可复用original.uid。普通stat copy由host独立nextSourceUid分配新sourceUid（永久初始牌sourceUid来自Run.deck.uid），不能用新combat uid充当sourceUid；Burst的makeSameInstanceOf特例保留已存在且严格校验的original sourceUid，但分配**新的runtime combat UID**；缺sourceUid明确拒绝，不回退到combat uid。不得用同一个表或同一个runtimeUID表示两个对象。生成不是抽牌，不触发EndlessAgony onDraw；满手副本去discard，不能丢失。

`onDraw`仅EndlessAgony返回TOP makeStatCardCopy1：复制真实被抽牌当时的stat-equivalent值，不只catalog基础。实际抽1变成该实例+一张新实例；生成副本不递归复制。该hook在实际入手/抽牌源时调用，不能在牌库初始化或普通生成时调用。

`planOnUse(state,card,instance,context)`为纯捕获：只对旧Burst>0、Skill、非purge有效，返回consumeBurst=true、可选TOP移除，以及独立cardQueue命令记录。host在捕获时扣旧层数；原Burst本牌的新power尚未应用，不应错误触发自身。自动副本purgeOnUse/autoplay=true、原energyOnUse/target；进入真正自动出牌队列，执行正常onUse/历史计数/选择/费用与X语义；不得把原effects重播一次冒充出牌。purge副本不再触Burst，仍触其它onUse power。源自动cardQueue在原动作处理完后执行；不能插在原本effects中间。sourceUid相同仅表达原UUID语义，不能破坏combat UID唯一性。

### 受伤、死亡与回合Power

`onHpLost(state,owner,amount)`仅owner==player且实际amount>0生效；每个伤害事件+1，而不是每失去1HP+1。扫描hand/discard/draw，排除exhaust、limbo、cardInUse（源AbstractPlayer.updateCardsOnDamage如此）。按updateCost(+1)更新combatCost与turnCost并保留二者原diff；freeToPlayOnce不因此消失。零伤害、格挡完全抵消、治疗不触发；HP_LOSS与THORNS只要实际失HP亦触发。host需要在所有实际HP正损路径调用一次，不能同时调用两处导致加2。

`planHook`返回普通effect数组，接SourceSchedule：

| Power | 源priority | 源hook与动作 |
|---|---:|---|
| well_laid_plans | 5 | 玩家endTurn排RetainCardsAction，可0到N；RunicPyramid/Equilibrium时跳过；Ethereal被选也不设retain，仍走虚无 |
| burst | 5 | 玩家endTurn移除 |
| nightmare | 5 | preDraw生成保存模板n张，再移除 |
| phantasmal | 5 | preDraw Apply DoubleDamage(constructor1, rawStack=n)，再reducePhantasmal1 |
| double_damage | 6 | NORMAL atDamageGive x2，**不是按层数2的n次方**；round_end减1/移除 |
| tools_of_the_trade | 25 | postDraw额外Draw(n)，再DiscardAction(n,false)，不是只弃1或修改drawPerTurn |
| intangible | 75 | round_end减1/移除；伤害上限见下 |
| wraith_form | 5 | 玩家endTurn排Dexterity(负的power amount)，持续不自减 |

Retain选择必须在丢弃/虚无结算的正确时点真正暂停，选至多N（可选0），令牌/手牌预检及原引用回滚与旧选择API相同；确认后继续回合队列。Tools的弃牌是真手动弃牌，允许Tactician TOP、Reflex BOTTOM，并能在回合开始队列暂停；不能绕过pending/使用独立回合引擎。

`planCorpseDeath(state,owner)`只在真正死亡、还有其它活敌、尸爆层数>0时返回**BOTTOM** null-owner THORNS AoE，值为owner.maxHp*层数。源是DamageAllEnemiesAction的真实THORNS伤害：受Block与Intangible等对应伤害接收规则影响，不受玩家Strength/Weak/DoubleDamage，不能触发Envenom/普通攻击Thorns反击。可以连续尸爆；最后敌人死亡不排空爆炸；escaped不是death。源java int溢出未猜测，超安全int范围明确拒绝，由host事务回滚。

### Wraith / Intangible / Artifact边界

WraithForm.use先Apply Intangible，再Apply WraithFormPower(-1)。后者构造为DEBUFF，玩家有Artifact时可以阻止整个持续掉敏捷Power，但不会抵消先到的Intangible。未阻止时，此Power每玩家endTurn都排Dexterity负应用；之后新获得Artifact也能分别阻止某次负Dex，不能因此删除WraithPower。

IntangiblePlayerPower.atDamageFinalReceive未按DamageType排除，Player.damage还会在decrementBlock前将>1的info.output钳到1；LoseHPAction确实调用target.damage(DamageInfo.HP_LOSS)。因此NORMAL、THORNS、HP_LOSS均可降至1，且NORMAL/THORNS随后仍先由Block抵消，HP_LOSS跳过Block。零伤害不会变1；治疗不受影响。检查Power**存在**，不是只判断amount>0。纯`capIncomingDamage`提供这个数值适配，host必须用于所有HP损伤通道，不能只接普通Attack。`damageMultiplier`仅DoubleDamage存在时对NORMAL返回2，另两种返回1。

Intangible先钳伤害不替代其它源Power/Relic的最终接收/失血修饰顺序（如TungstenRod、Torii等），未实现的遗物复合必须保持已声明能力限制，不能据本切片宣称全部接收链已齐备。

## 完整随机池明确拒绝

当前没有经过验证的完整、有序source技能池和完整药水生成路径。`canPlay`对Distraction/Alchemize提前返回unsupported_complete_skill_pool / unsupported_complete_potion_pool，`prepareEffect`另有强守卫。即使调用者写一个complete=true标志也不能解锁，不从现有已实现子集生成。

Source Distraction在use即时按srcCommon→srcUncommon→srcRare遍历筛选Skill并排除HEALING tag，使用cardRandomRng一次；生成普通makeCopy、setCostForTurn(-99)，不是依稀有度先抽roll，也不是到生成action时才选。Alchemize也在use即时用potionRng先roll0..99（65/25/10稀有度），再按PotionHelper.potions完整有序池反复随机到合适rarity并排除FruitJuice；limited=true的spamCheck使最初候选被丢弃，不能简化成一次均匀抽现有药水。满药水栏、Sozu及获取选择也需真实source获取链。补齐上述证据与逻辑之前，两张只作为已定义但不可玩的明确候选。

## 真实验证状态

命令：`node scripts/test-lua.mjs tests/lua/silent_final_build.lua`。初轮扩为38例：11个独立定义/纯plan/实例钩子事实通过，27个真实共享core场景红（unsupported新op、尚未接onDraw/HP-loss/Power生命周期、完整池预检尚未接）。没有用mock、改数值或跳过红例宣称可玩。测试曾误调用不存在的Actor.loseHp，现已改为真实Combat.applyEffects(loseHp)/Combat.damage，当前红为机制缺口而非该夹具错误。

待真实共享接入后复核全部基础/升级、复制identity与满手、选择恢复、损伤种类、Artifact及回合顺序。所有构造耐久/牌堆夹具是单元证据，不是自然Run掉落、完整Map或平台实机验收。未跑全量检查、未提交推送。

## 固定源文件字节摘要

| 固定文件 | SHA-256 |
|---|---|
| [actions/common/LoseHPAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/LoseHPAction.java) | `50c9ea9f1aef4a02ff9177d59517f61b03941e9770a23bc50bed8e3d60d69670` |
| [actions/common/MakeTempCardAtBottomOfDeckAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/MakeTempCardAtBottomOfDeckAction.java) | `7ed5a4bf4f45b419a47db52b3bbccbc34cd9bb9a148b7ceaaea201aa28dcc7b0` |
| [actions/common/MakeTempCardInHandAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/MakeTempCardInHandAction.java) | `b089bb6fd688ffdd48ae9def57751f972429cad63f85ec80ee3f90593d5bbe25` |
| [actions/unique/ApplyBulletTimeAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/ApplyBulletTimeAction.java) | `5f28aafc46e1a5fd6927611927740f8af3a5b99f87888319ef401cacd0d83077` |
| [actions/unique/DoppelgangerAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/DoppelgangerAction.java) | `b325271d82f9a2dc12391aa0b94d979889217847d03e19faf4ae8578dfe35cd1` |
| [actions/unique/NightmareAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/NightmareAction.java) | `1983c24d4093fa5cd16dd333638d017222dce486907a6e99e0e050c171edf228` |
| [actions/unique/RetainCardsAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/RetainCardsAction.java) | `f541082a47636a3c11ea9afc9bad3af6a3cdd7097245b79fb009f43e31610283` |
| [actions/unique/SetupAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/SetupAction.java) | `6996b058f6722a9f5dae5774e5601dba5a062ec27fa14dd276e5b0e8d3ec46c8` |
| [actions/utility/UseCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/utility/UseCardAction.java) | `90213939af6d7ec83dea01bb2feef4ba762a93400dc1535732e2eebcdb6cab0f` |
| [cards/AbstractCard.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java) | `bcd472ececfd8ce4150ccd4eb6dd07a2e2dc43e139196fe00de34705cf1a2a61` |
| [cards/DamageInfo.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/DamageInfo.java) | `cc16469d78473a1d37bf18a152014d9d1625859a5a7bd0923387f4ee8d942a5a` |
| [cards/green/Alchemize.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/Alchemize.java) | `dbcf774ae6d66a0efb2bf916954e19f37b9f547c06681284ca91fd60f097f8fe` |
| [cards/green/BulletTime.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/BulletTime.java) | `dc3a08f4de816620b200cea279b47a0d18e254f3fb15cd2032c378c843e3e8d1` |
| [cards/green/Burst.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/Burst.java) | `f0dceb49d36f2236c57611b31a8f02d94aa9252c7b6a83fc73b49beb627f6a2f` |
| [cards/green/CorpseExplosion.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/CorpseExplosion.java) | `b1cd37d0c35a1c5f542a57385ba64c46f792f5aacf02fff3554628f0beefade2` |
| [cards/green/Distraction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/Distraction.java) | `b2a74e503dc402e5c5bf46bfa906e6f5938b9060e85ca9dd1833265b63864ecb` |
| [cards/green/Doppelganger.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/Doppelganger.java) | `b2fc7bec2df2395d141cbc80b76fe47e52dcec8cd7de766fb304d132c1754322` |
| [cards/green/EndlessAgony.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/EndlessAgony.java) | `bb0dd5c276f180c1d8127d46cd659b0284f5ca7a55ab15e7e552543d0f603797` |
| [cards/green/MasterfulStab.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/MasterfulStab.java) | `3744a52bf9c72c84c221aaed6798fe21bc67b6271b28f6a4456194d507349ff2` |
| [cards/green/Nightmare.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/Nightmare.java) | `0a60a0a43feabb44eaa9e4ef4e1e9b5d972cb09b5b8bb394422632f3fc4ed7fe` |
| [cards/green/PhantasmalKiller.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/PhantasmalKiller.java) | `ae390df3aa0db5e28531891c8fa56663fe1d369f147a5aa6f86449c43d12b87b` |
| [cards/green/Setup.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/Setup.java) | `e6a48c3f695bd984c434353bb35af7799bcf0e47cabca010426074f3b059d125` |
| [cards/green/ToolsOfTheTrade.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/ToolsOfTheTrade.java) | `3be0ab847fecc066d203137cbac3f1edfd6d83effb69703673d97827f4945a50` |
| [cards/green/WellLaidPlans.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/WellLaidPlans.java) | `ed49d8501252a16da6a23f76b70b78604e5df0857281c5e684321a98a5de1266` |
| [cards/green/WraithForm.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/green/WraithForm.java) | `e711fa1696eca54cf47924e940c7426ce6f4b8c326fbe6ad15b9fcdb2f5d7864` |
| [characters/AbstractPlayer.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/characters/AbstractPlayer.java) | `2720ba8dd7a216781a3b2fcb709f5ec67dc9b2559af25f7f6b89df1ef0947d95` |
| [core/AbstractCreature.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/core/AbstractCreature.java) | `3db6e08c6bd033192aa368e29ad53f4614194898ccf0f525480fe20cb8799f2b` |
| [dungeons/AbstractDungeon.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/dungeons/AbstractDungeon.java) | `8fa0712818487a360c72950d053fe77e1a35efa967080723d15c69037092fd26` |
| [helpers/GetAllInBattleInstances.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/helpers/GetAllInBattleInstances.java) | `056231bdf229b7b32ba5d62cf722c04155acd521206e6a5be72df7a03f791213` |
| [helpers/PotionHelper.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/helpers/PotionHelper.java) | `159ffee06ab09c24063b992f5babe57907916a99a23f4a3ad721b8c922be2a2f` |
| [monsters/AbstractMonster.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/monsters/AbstractMonster.java) | `f95baba14b00bffeb6a93e9fcf04cedad2a42a803c4b4342c1e017535acc601f` |
| [powers/BurstPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/BurstPower.java) | `a1545cde208a3c54818ec8a95e22308fbbadcd89f597e8c26570608eeda3962e` |
| [powers/CorpseExplosionPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/CorpseExplosionPower.java) | `7da1db8b92cbe48cdda233f0cd3575fde953c0540e9d62e22e8ad2b0e31ab4dd` |
| [powers/DoubleDamagePower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/DoubleDamagePower.java) | `5689330decbcdebe84e49a86ca838d95a876d00d692594539a15e72e4fac7631` |
| [powers/IntangiblePlayerPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/IntangiblePlayerPower.java) | `62ca9eecfd78e5b5a018ef069147d36bd58463b9754c8359d5dfb710bb6c52c8` |
| [powers/IntangiblePower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/IntangiblePower.java) | `72c50bdb1563a32483a3e9d608a3bb3d96cf8776fc3492759acc79e7312bdf28` |
| [powers/NightmarePower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/NightmarePower.java) | `f1ff970a2c14551f2668e7dced48b71d8a51acd4f5b3c53ca153c8a51101b0b9` |
| [powers/PhantasmalPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/PhantasmalPower.java) | `2b3957787a10fc6113d90857c7672ac604da3f7364962da1f60240590b4bfe95` |
| [powers/RetainCardPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/RetainCardPower.java) | `65ae46759ff6aa25a6a577d75b966d8e64cf2dc4a4ddf2188425301d48b9687e` |
| [powers/ToolsOfTheTradePower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/ToolsOfTheTradePower.java) | `f58c2e284e1113c4e1f1e45903b23109347a4f6c080bb98e2af0554e007b2dde` |
| [powers/WraithFormPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/WraithFormPower.java) | `821506822c4504046151e72cca2e13d5d9474310aea2aef3ee2b7a44959041db` |
