# 卡牌来源身份与战斗实例身份

`abyss_card_identity` 将两个命名空间分开：`sourceUid` 对应原版卡牌UUID所表达的来源身份，`uid` 唯一标识本场战斗中的实际对象。数字相同可以出现在两个命名空间中，不能据此把它们当成同一对象。模块不运行卡牌效果，也不自动移动牌或更新永久牌组。

固定来源为社区反编译镜像 `aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0`，不是官方二进制认证。实现为独立的数据适配，没有加入Java源文，也没有用数字计数器冒充Java UUID的随机生成算法。

## 来源逐行证据

| 固定文件与行号 | 事实与本地映射 |
| --- | --- |
| [AbstractCard.java:319](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java#L319) | 构造新牌分配新UUID。应用用独立 `nextSourceUid` 为新构造分配来源身份，不消费战斗随机流。 |
| [AbstractCard.java:804–807](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java#L804) | makeSameInstanceOf先做stat-equivalent副本，再把其UUID改为原UUID。对应 `created(state, source, 'same')`，保留sourceUid但分配新combat uid。 |
| [AbstractCard.java:810–833](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java#L810) | makeStatEquivalentCopy从makeCopy的新构造开始，应用升级并复制规定数值，没有覆盖新UUID；818行保留timesUpgraded，831行保留misc。对应new模式的新sourceUid。 |
| [CardGroup.java:55–59](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/CardGroup.java#L55) | 从其他CardGroup建立副本时，对每张牌用makeSameInstanceOf。 |
| [CardGroup.java:911–914](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/CardGroup.java#L911) | 战斗初始化从masterDeck复制DRAW_PILE，所以初始战斗实例应保留永久来源身份。应用的永久 `Run.deck.uid` 映射到其sourceUid；combat uid另分配。 |
| [GetAllInBattleInstances.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/helpers/GetAllInBattleInstances.java) | 按UUID搜cardInUse和draw/discard/exhaust/limbo/hand，以HashSet去重对象。应用返回稳定数组并按对象去重，不宣称HashSet具有本地数组的遍历顺序。 |

连击 `DoubleTapPower` 用makeSameInstanceOf，必须同来源；全知 `OmniscienceAction` 第二次用makeStatEquivalentCopy，必须新来源。两者都需要新的combat uid，不能再把“副本”统一成一种身份操作。

## 稀疏永久UID与独立分配

永久牌组UID不要求从1连续排列。若12张永久牌的UID为1至11和20，战斗实例可分配1至12，下一combat uid为13，但下一新来源必须从21开始。若永久牌组本来还包含source13，combat13仍是合法的另一个命名空间编号；**新生成卡的sourceUid不能因此也取13**。

`init(state, masterDeck)` 必须在任何fromMaster／新生成之前，扫描完整永久牌组，同时扫描已知战斗sourceUid，得到来源最大值。它不会从战斗uid倒推出来源身份。已有更大的合法nextSourceUid会保留，避免已经消失的来源被重用。

模块保存纯数据 `state.cardIdentity`：

- `masterCards`：永久uid到cardId的初始化索引，用于fromMaster校验。
- `sources`：已知永久来源和已经分配的新来源集合，即使对应卡已经purge也保留。
- `combatHighWater/sourceHighWater`：已分配的高水位，防止外部回退计数器后重用已经离开当前牌堆的身份。

`init` 幂等，重复调用保留已有元数据表和计数器引用；重复初始化时永久UID／cardId映射必须相同。战斗中永久添加／移除／变换卡牌，需要根核心设计显式更新协议；本模块不默默重建索引或恢复被外部回退的计数器。

## API

| 方法 | 行为 |
| --- | --- |
| `init(state, masterDeck)` | 预检四牌堆、可空limbo、cardInUse和稠密永久实例列表。初始化独立nextSourceUid及上述元数据；不创建或移动卡，不修改nextUid，也不替root给旧实例猜sourceUid。 |
| `allocateCombatUid(state)` | 从nextUid严格分配1个新runtime uid，更新combat高水位。不跳过冲突。调用者需在同一外围事务内取得实际新实例所有权。 |
| `allocateSourceUid(state)` | 从nextSourceUid严格分配1个新来源，预留source并更新source高水位；不消耗combat uid。 |
| `created(state, template, 'new')` | 创建未附着的新对象，分配新combat uid和新sourceUid。模板可为无uid的构造数据，也可为已存在实例的受支持stat快照。 |
| `created(state, original, 'same')` | 原始实例必须是当前四堆／limbo／cardInUse中的实际对象，且已有预留sourceUid。新对象继承该sourceUid，只分配新combat uid；不是把输入快照中的combat uid当来源。 |
| `fromMaster(state, permanentInstance)` | 永久uid／cardId必须在初始化索引中；分配新combat uid，sourceUid固定为永久uid。保留misc、timesUpgraded、upgraded及已核stat字段，不消费new-source计数器。 |
| `allBattleInstancesBySourceUid(state, sourceUid)` | 只读返回同来源的实际对象；按hand、draw、discard、exhaust、limbo、cardInUse稳定遍历，重复对象仅一次。同combat uid指向不同对象时拒绝，不把损坏图当作可去重别名。 |

所有创建方法返回的牌尚未入堆，不改手牌、抽牌堆、牌序、能量、历史或RNG。Root应在同一整图事务内调用并立刻入目标堆／limbo；随后若失败，连同nextUid、nextSourceUid、来源预留、高水位和原对象引用一起回滚。没有调用任何卡牌规则函数。

四堆是必须存在的稠密数组，limbo可省略，cardInUse可为空。同一个对象在limbo和cardInUse中作为别名出现可只登记一次；不同对象冒用同一个combat uid则失败。普通单一牌堆归属、手牌上限和移动规则仍由根核心负责。

## 数值边界与复制字段

uid、sourceUid与两个分配器采用有限正整数且 `n+1.0>n` 的护栏，**不限制在32位整数**；以浮点加一避免Fengari的32位整型回绕。`2147483647→2147483648` 合法，`4294967298` 的永久来源合法。NaN、Infinity、非整数、零／负值及失去可递增精度的 `9007199254740992` 拒绝。misc、timesUpgraded和已知数值stat另按源int上限2147483647校验；misc允许源signed-int负值，费用只允许合法的-1／-2哨兵。generation／token不属于此模块，仍由原有INTMAX规则管理。

允许stat-copy的当前实例字段包括misc、timesUpgraded、combatCost、turnCost、damageBonus、storedDiscardCost、retainedBlockBonus／retainedDamageBonus／retainedCostReduction、shivAccuracyBonus、expungerHits、freeToPlayOnce及已核的inBottle／isSeen／isLocked标志。upgraded保留；显式timesUpgraded与upgraded矛盾时拒绝，不凭boolean发明未提供的升级次数。

暂态retain、retainedTurn、ethereal、动态exhaust、exhaustOnUseOnce、purgeOnUse、dontTriggerOnUseCard、isInAutoplay、ignoreEnergyOnUse和energyOnUse不会默认继承。源makeStatEquivalentCopy没有盲拷这些字段。永久固有关键词由目录及升级重新产生；需要purge或exhaustOnce的调用者在正确动作时点显式设置。未知stat字段拒绝，不为了兼容未来模块而盲拷；以后新变异需要新增明确源映射。

本模块只保存复制用的事实，不负责多次升级的实际效果重算、特殊卡自定义makeStatEquivalentCopy、SearingBlow数值或永久升级规则。fromMaster能保留timesUpgraded不表示共享cardDefinition已经正确执行全部多次升级。当前旧Auto.clone仍有32位护栏及自身stat映射，root统一接identity之后才可消除该差异；本任务未改冻结Auto文件。

所有预检在分配或元数据写入之前完成。已存在nextUid／nextSourceUid与对象、永久预留、高水位冲突时直接失败，不“找到下一个没被占用的数字”掩盖损坏。模板拒绝函数、元表、循环和非法标志。合法更大的分配器可能留有空洞；这些空洞也不会回填。

## 定向证据与未完成接入

`node scripts/test-lua.mjs tests/lua/card_identity.lua`：`CARD_IDENTITY_COMPONENT_PASS 25`，2069ms，exit0。测试使用真实Combat.new对象及Snapshot.capture整图恢复，没有mock实际卡牌效果。覆盖12张稀疏永久牌、跨命名空间13、所有已知source扫描、32位跨界、较大永久source、new／same／fromMaster差异、原对象去重、冲突拒绝、未知stat、序列化、幂等初始化、未附着／purge来源预留及原引用回滚。

测试末明确输出 `CARD_IDENTITY_CORE_NOT_CONNECTED`：根核心尚需逐一把初始战斗、临时生成、复制、自动播放、永久Deck／masterDeck和持久化入口改为这些接口。组件成功不能等同于所有sourceUuid依赖牌真实可玩；本任务未改Combat或既有生成器，未跑全量、未提交或推送。

## 固定来源SHA-256

| 文件 | SHA-256 |
| --- | --- |
| AbstractCard.java | `bcd472ececfd8ce4150ccd4eb6dd07a2e2dc43e139196fe00de34705cf1a2a61` |
| CardGroup.java | `03de4e22ab22bedf1d90df72bdc83f033ff6aa776ad9d8f7259e1ee9293f7fa8` |
| GetAllInBattleInstances.java | `056231bdf229b7b32ba5d62cf722c04155acd521206e6a5be72df7a03f791213` |
| DoubleTapPower.java | `229c04c01990e446cbc87fab011a373f65734079f542d09c787d35742a3095ee` |
| OmniscienceAction.java | `caf69d4a2d301da290e6787aaeb0d58f6ee99c77b83205a115a0b9a712cfaeaf` |
