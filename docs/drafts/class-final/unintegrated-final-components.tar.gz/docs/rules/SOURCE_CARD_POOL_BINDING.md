# 完整来源牌池的Lua绑定

本片新增 `abyss_source_card_pools.lua` 与30组组件测试。模块包含完整370个全局注册键的有序事实和筛选所需元数据，独立筛选四职业完整池，再绑定调用者**已有**的本地定义。没有修改DefectFinal或共享核心，没有为了补齐池调用其他职业withCards、注入占位牌或创建foreign handler。

## 来源和认证边界

输入为已交的 [SOURCE_CARD_POOL_ORDER.md](SOURCE_CARD_POOL_ORDER.md)、[完整manifest](evidence/source-card-pools-319009-jdk8plus.json) 与 `scripts/source-card-pool-audit.mjs`。固定 `aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0`，来源声明V2.3.4 (12-18-2022)，不是正版PC二进制认证。

- manifest SHA256：`d71234050ae5c9000268e8dff42ff8391e841eefcbf0212238a8d63e458269fd`。
- 全370注册metadata SHA256：`f2a387be3b963ba9fac36a0305ef5add76862666f6055a1d8e058d8f33a53308`。
- 370键有序ID（每键一行）SHA256：`704cf04aede6daf0d2a84105fbc47c3742b53b059aa49f1bb6cec122860f03b9`。
- runtime候选：`jdk8plus-default-string-hashmap-no-tree-bins-v1`。所有370键共同参与，最终512桶，最长链4，没有树化。

本轮只读重跑 `source-card-pool-audit.mjs --verify --java-check`，manifest未变，本机真实OpenJDK21 HashMap逐位置370/370一致。Java API不保证遍历顺序，未知原版bundled JRE仍未认证；Java21交叉检查不是原版Java8客户端实测。模块及返回计划保留 `derived-candidate-runtime-profile-not-original-client-certified` 标识。

绑定profile明确限定全卡／全职业解锁、A0、无每日和外部mod、初始无变异的牌池。模块无法证明调用者的实际PC存档、解锁或JRE；消费者必须真实满足该profile，不能把传入字符串当作认证证据。Colorless/CURSE生成、Diverse/跨色混池、部分解锁及后续src变异不在当前绑定范围。

## 完整事实与数量

模块静态370行保留SourceID、颜色、rarity、type、构造基础费用及canonical HEALING标记；不包含Java实现。`libraryOrder()`可读全部370键，`metadata(sourceId)`读对应事实，返回值与内部数据分离。

| 职业 | 注册含基础 | 普通 | 罕见 | 稀有 | 非基础src | 去HEALING | attack | skill | power |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ironclad | 75 | 20 | 36 | 16 | 72 | 70 | 28 | 28 | 14 |
| silent | 75 | 19 | 33 | 19 | 71 | 70 | 26 | 33 | 11 |
| defect | 75 | 18 | 36 | 17 | 71 | 70 | 23 | 34 | 13 |
| watcher | 75 | 19 | 35 | 17 | 71 | 69 | 24 | 33 | 12 |

普通rarity桶保留HashMap筛选顺序；src桶因addToBottom逐桶反转；combined按src Common→Uncommon→Rare拼接。HEALING从canonical源tags过滤，不能根据回血文案或本地遗漏的tag猜测。排除项包括Feed、Reaper、Venomology、Self Repair、LessonLearned、Wish；例如永久升级的LessonLearned也不能留在战斗随机池。

蓝色HelloWorld为normal/common的完整18张，首Go for the Eyes、末Steam。WhiteNoise和CreativeAI为in_combat/power的完整13张，首Defragment、末Creative AI，不包含Self Repair。此顺序与DefectFinal已有事实表一致，没有借本轮现有56牌子集重新排序或裁剪。

## 明确选择helper

`spec`必须显式包含profile/version/poolRevision，不能省略或使用未知版本：

```lua
local Pools = require('abyss_source_card_pools')
local hello = {
  profile=Pools.profile.id, version=1, poolRevision=0,
  classId='defect', helper='normal', rarity='common'
}
local power = {
  profile=Pools.profile.id, version=1, poolRevision=0,
  classId='defect', helper='in_combat', type='power'
}
```

profile完整ID为 `sts1-319009-jdk8plus-all-unlocked-no-mod-initial-v1`。`poolRevision=0`表示调用者断言尚无初始化后变异，非0或缺失均拒绝。不能每次从静态表重建来覆盖srcTransformCard产生的合法顺序变化；未来若支持该路径，应保存实际池状态并建立新的绑定。

| helper | 参数 | 顺序及筛选 |
|---|---|---|
| normal | rarity必填，type禁止 | 普通初始rarity桶，无HEALING过滤；HelloWorld用此入口 |
| source_rarity | rarity必填，type禁止 | 该src rarity桶，无HEALING过滤；不替代上游rollRarity |
| truly_random | rarity/type都禁止 | src C→U→R，无HEALING过滤，对应returnTrulyRandomCard |
| in_combat | type可省或attack/skill/power；rarity禁止 | src C→U→R，排HEALING，可再按type过滤 |

只支持四个classId，unknown class/helper、错误参数组合或多余字段明确拒绝。没有奖励／商店稀有度概率、Discovery三候选去重、ForeignInfluence跨色组合或隐式fallback。单次选择是完整数组上的一次均匀源索引，不先随机rarity，不对HEALING重抽，不排已持有牌。

## 绑定本地真实定义

```lua
local ids = Pools.sourceIds(power) -- 仅事实，不声称本地已经可玩
local bound = Pools.bind(state.catalog.cards, power)
```

bind只读一个flat `id -> definition` catalog。先识别SourceID，再要求**所有**候选都存在、无歧义、type/rarity/基础cost匹配canonical元数据；本地提供color时也须匹配。最后逐张用真实 `abyss_card_capability.isImplemented` 检查。缺一张、未抽中的某张op不支持、基础metadata错误或重复SourceID都会拒绝整池，不删除候选、不重抽、不默认替换、不添加定义。

SourceID识别优先显式 `sourceId`；有该字段却错误时，不退回名字修补。旧helper部分没有sourceId，或sts_name是展示名（例如Just Lucky与源JustLucky不同），所以本片依据当前完整覆盖账本的238条**已核本地ID→SourceID映射**编译静态别名，不在运行时猜CamelCase、按中文名称匹配或借外国职业构造器补牌。精确sts_name与本地别名若矛盾同样拒绝。

别名输入 `docs/rules/CLASS_CARD_COVERAGE.md` 的本轮快照SHA256：`e7ba7a81477790ece53a7b08f3c9306991d37561b1555fbff3748a892f7900ad`。未来新增牌应提供正确sourceId；没有覆盖的新本地命名不会被模块臆测补上。基本牌／特殊牌不进入这些常规生成池。

Capability检查是当前宿主的声明门禁，并不替代每张牌的真实play、升级、UI和平台验证。生成模板默认未升级；Master Reality等生成后升级仍须由Host另行确认升级能力，不由此组件冒称已支持。

## 纯选择计划与新来源身份

```lua
local plan = Pools.plan(state.catalog.cards, power, state.cardRandomRng, {turnCost=0})
-- 验证整个宿主动作后，由宿主把plan.rngAfter提交回原RNG对象。
-- 再用plan.template调用自己的真实新卡构造器。
```

返回字段：`profile/classId/helper/count/index0/sourceId/cardId/rngAfter/template`。index0是源0基索引；以既有SourceRandom包装在克隆流上执行一次 `randomInt(N-1)`。不给RNG、给legacy整数或无效RNG会拒绝，不会偷偷借其他随机流。所有原RNG字段与primitive对象保持不变；源选择的包装调用计数与底层XS128拒绝采样状态步数仍由既有RNG组件负责。

模板仅为 `{cardId=本地ID,upgraded=false,sourceUidMode='new'}`，不分配uid/sourceUid，不复制已有实例，也不执行effects。Host负责新nextUid与独立nextSourceUid、Genetic的初始misc、ForceField按当前Power历史配置费用、满手溢出及实际生成事件。新source身份分配点仍归统一宿主，不等同makeSameInstanceOf的共享身份。

可选turnCost只接受0，用于WhiteNoise等临时0费；只对源基础非负费用写turnCost=0，X(-1)/不可打出(-2)不被该setter变为0。这遵循AbstractCard.setCostForTurn，而不是把Distraction生成到的所有技能强行免费。原费用和后续回合重置由宿主维护。传uid/sourceUid/upgraded或未知选项拒绝，防止调用者把新牌模板误用作同源复制。

无type的in_combat还返回 `markSeenSourceIds` 全候选列表，供Host按源markCardAsSeen；typed入口没有该副作用计划。组件不改玩家profile。多个Power在开始阶段依序选牌时，Host必须按源Power顺序连续传上个after流或逐次提交，不能让每个hook都从同一旧RNG克隆。

选择时点仍由调用者负责：WhiteNoise／InfernalBlade／Distraction在card.use构造时选择，CreativeAI在atStartOfTurn构造时选择。满手或后续死亡取消实际生成，不能倒退已经成功构造的源随机调用；整牌运行时失败的事务回滚则由统一宿主处理。

## 当前组件证据与接入建议

```sh
node scripts/test-lua.mjs tests/lua/source_card_pools.lua
node /workspace/sts-flow/scripts/source-card-pool-audit.mjs --verify --java-check
```

本轮 `SOURCE_CARD_POOLS_PASS 30`，退出0，约1.39秒；audit verify与Java370位置也通过，未运行全量检查。

测试逐位置对比外部manifest的370全局键、四职业每个normal/src rarity桶、combined与各type；验证HEALING区别、显式版本／revision拒绝、数据副本隔离。正向绑定与选择使用**真实现有**Silent common19和Watcher common19定义，没有编假卡补齐池；M.plan验证一次克隆抽样、新身份模板、原catalog和RNG完全不变。还特别删掉／改坏一个确定未抽中的候选，整池仍拒绝，证明不是只验证命中牌。

本轮探针中，其他某些完整池仍缺实际定义或能力（如旧Defect56缺Redo等Final候选），绑定按事实拒绝。没有因此宣称四职业全部随机生成已接入、所有候选真实play已通过，或当前已达到300张全可玩。

建议root把DefectFinal现有sourcePool/validatePool/drawChoice委派到本组件：common映射normal/common，power映射in_combat/power，返回bound.cardIds或plan.cardId，并保存候选profile标记。该修改归root；本片没有编辑冻结的DefectFinal或任何共享调用点。其他职业按自己已经核准的Dungeon helper接入，不能把同一列表套到不同源函数。

没有做：原版JRE认证、真实unlocks捕获、动态src变异持久化、mods、多色混合池、生成后的完整交互、升级／平台UI、Windows实机、自然路线或全量回归。静态事实完整不代表这些范围认证。
