# 战士最后九张：升级、复制、自动出牌与永久生命

本片只新增独立 `abyss_warrior_final_cards.lua`、`warrior_final_build.lua`和本文，不改共享Core、默认JSON或前序冻结交付。Headbutt/Exhume由另一切片负责，此处不添加。九项在当前默认母表中均不存在。所有事实固定在社区反编译镜像 `aeubanks/sts@319009d5df0a82d9fb0f23cc22322286c6a87ec0`；逐文件SHA-256附后。不复制Java实现或游戏资源，不把社区镜像冒充已认证官方二进制。

## constructor/use/upgrade

| 牌 | 费用/稀有度 | 基础→升级与源码行为 |
| --- | --- | --- |
| Armaments 武装 | 1/Common Skill | 先普通Block5，之后升级1张可升级手牌；升级版改为升级所有可升级手牌，格挡仍5 |
| Havoc 破灭 | 1→0/Common Skill | use时先随机选敌构造PlayTopCardAction；原顶牌免费auto-play并设置一次性消耗；本身无固有消耗 |
| Sword Boomerang 飞剑回旋镖 | 1/Common Attack | 3伤×3→4；每个AttackDamageRandomEnemyAction执行时重新随机目标并重新calculateCardDamage |
| Dual Wield 双持 | 1/Uncommon Skill | 选择Attack或Power，增加1→2张stat-equivalent复制；选择与自动单候选分支的原实例身份处理不同 |
| Infernal Blade 地狱之刃 | 1→0/Uncommon Skill | use时从完整源攻击池抽取并makeCopy，setCostForTurn(0)，再MakeTempCardInHand；消耗 |
| Searing Blow 灼热攻击 | 2/Uncommon Attack | 基础12；每次升级增加4+旧timesUpgraded，可无限次升级；前几级伤害12/16/21/27/34/42 |
| Double Tap 双发 | 1/Rare Skill | 本回合下1→2张攻击牌各额外打一次，不是一张攻击额外打两次；无固有消耗 |
| Feed 狂宴 | 1/Rare Attack | NORMAL10→12，符合死亡条件时立即永久maxHP+3→4并调用同量heal；消耗，带HEALING标签 |
| Juggernaut 势不可挡 | 2/Rare Power | 每次正数onGainedBlock输入时，BOTTOM排随机敌人THORNS5→7 |

withCards独立深拷贝，追加九张与double_tap/juggernaut两个强度型、不自动衰减的buff。marker为experimentalWarriorFinal，新构筑牌color=red/experimental=true。数据存在不等于共享依赖已经完成，更不自动解锁默认牌库。

## 必须接入的共享依赖

- 手牌升级/复制的过滤选择、唯一token、原实例快照、恢复手牌顺序及command事务；不能只新增一个按钮后把选择当作已完成。
- 战斗内升级与永久牌组升级隔离，Searing Blow的次数进入Run、Combat.new、复制、存档读写、校验和显示。
- Havoc与DoubleTap需要独立CardQueue/limbo数据生命周期，普通action全部排空后再消费；不能直接递归C.play或把自动牌临时塞进hand。
- InfernalBlade需要经外部审计的完整、有序runtime src卡池，包含当前尚未实现的成员也不能删掉；没有完整池时明确拒绝。
- Feed需要集体伤害反应收集、立即永久maxHP/治疗、Minion/halfDead判定、Run成功事务与下场战斗的maxHP同步。
- Juggernaut需要所有真正addBlock入口的正数hook与延后随机伤害：卡牌/药水、FNP、Metallicize、Rage及Entrench等；999封顶前调用，不可只看最终delta。

模块的sharedDependencies用纯字符串数组列出上述接点，不把定义标记伪装成已完成的能力开关。

## Armaments与DualWield的身份和顺序

普通canUpgrade规则排除Status/Curse与已经升级的普通牌；SearingBlow覆盖为始终可以升级。武装本身已在cardInUse，不参加手牌候选。基础版单候选自动升级，不耗RNG；多个候选强选一张。升级版按当前hand顺序逐张升级，不走随机/选择。

源ArmamentsAction多候选时暂移不可升级牌，取回所选牌时把它追加回hand，再把排除牌按原顺序追加。因此最终是“未选的可升级牌→所选原牌→原排除牌”。不能升级原位置之后保留整个旧手序，因为这会改变后续随机手牌索引。

DualWield只允许Attack/Power。单候选分支保留原对象，再创建N张复制；多候选手选分支中，源所选原对象被移出hand，未被加回，而是排N+1次MakeTempCardInHand。这相当于一张原位置的替代复制加N张额外复制，所有新对象有新UUID；原选UID不应假装仍在hand。其余候选先保留，再返回原非候选牌，复制牌随后添加，满手溢出遵循MakeTempCardInHandAction进入discard。

copyFinalCard携带sourceInstance纯快照与copyMode=stat_equivalent。host必须实现source stat-copy字段语义，包括费用、次数、战斗成长与不复制的瞬态标记，不能把整个表盲拷为同一UID。未知复制组合应拒绝，不能因为复制后显示同一文字便认定行为一致。BloodForBlood必须使用前一切片的stat-equivalent费用路径；同场升级需先调用其onUpgrade。

## Searing Blow计数、成长与存档

规范实例保存timesUpgraded，完整升级历史对应 `12+n(n+7)/2`。模块upgradeCount验证非负整数、upgraded标记一致性及数值上界；仅有旧upgraded=true而无次数的旧ABI只兼容为+1，不声称能推回丢失的+2以上历史。显式次数和bool互相矛盾时拒绝。

upgradeInstance只修改传入实例。Combat.new必须从永久牌实例复制次数到新的战斗对象；Armaments只升级战斗副本，不能联动永久Run.deck。营地等永久升级应修改永久实例并通过实际保存系统保留次数。真实Run测试要求+3牌进战斗仍+3/27伤，再由战斗升级到+4/34伤而永久牌仍+3。

源SearingBlow.makeCopy有特殊constructor参数，statEquivalent最终还写回源baseDamage与timesUpgraded。模块计数公式描述的是正常升级后的规范牌实例，不宣称可把任意裸constructor(upgrades)内部中间态当成已应用相同伤害的正常存档。host处理生成/复制必须按具体路径区分。

## Havoc与DoubleTap的真正CardQueue

Havoc.use先调用MonsterGroup.getRandomMonster(null,true,cardRandomRng)，所以即使draw/discard全空，仍先有目标随机调用；单活敌也消耗random(0)。无活目标不取随机数。PlayTopCardAction执行时若draw空且discard非空，则TOP排Shuffle，再递归PlayTop；并非视为空手跳过。

原顶牌从draw移出，设置exhaustOnUseOnce=true，进入limbo，**不触发抽牌回调**。之后TOP的Unlimbo与NewQueueCardAction把原对象交给CardQueue，后者immediateCard=false、autoPlay=true。当前Havoc自己的UseCard及已有action尾先完成，动作队列排空后才播放该原对象；这与把复制牌塞hand、收费打出或直接覆盖pendingPlay均不等价。

Havoc目标在use时捕获，不得因后来目标死亡重新随机。NewQueueCardAction执行时捕获energyOnUse。GameActionManager真正消费auto牌时设置isInAutoplay，并将ignoreEnergyOnUse=true；因此自动X牌不走普通snapshot/current clamp，且AbstractPlayer.useCard对自动X设freeToPlayOnce，保留所捕获X量、不扣当前能量。普通自动牌也免常规支付。不可打出的自动牌不执行use：源设置dontTriggerOnUseCard，仅排清理，所以一次性消耗仍可触发FNP/DE，而普通play hook不会发生。Power清理仍优先离开战斗，不因Havoc而成为exhaust事件。

DoubleTap在UseCardAction构造时检查Attack、非purge且次数>0。它立即makeSameInstanceOf，设置purgeOnUse，保留原target/energyOnUse，以ignoreEnergyTotal=true、autoplay=true、immediate=true加入CardQueue，次数立即−1，归零时BOTTOM排移除；回合末仍另有移除hook。复制牌在原action排空后播放，仍触发其他常规出牌hook，但DoubleTap因purge guard不递归。

source makeSameInstanceOf得到独立对象且来源身份相同。项目统一字段为sourceUid：初始牌来自Run.deck.uid，combat uid独立分配；新stat-equivalent/constructor由host的nextSourceUid分配，起点须高于所有永久uid，不能直接拿new combat uid充当sourceUid。makeSameInstanceOf保留原sourceUid、仍分配新combat uid。DoubleTap计划copyMode='same_source'，缺明确sourceUid时拒绝，不回退combat uid。所有永久增长查sourceUid，选择仍查唯一combat uid。前序status模块的复制/增长接线也依赖这项统一身份，但不在冻结文件中盲改。

## Infernal Blade的完整池与负费用哨兵

源returnTrulyRandomCardInCombat(ATTACK)按srcCommonCardPool、srcUncommonCardPool、srcRareCardPool的原顺序合并，过滤非Attack和HEALING标签，再均匀调用cardRandomRng.random(size−1)。不是先选稀有度，也不是从当前支持卡集合抽。Feed/Reaper属于被排除的HEALING攻击；基础牌不在这些src稀有度池。

prepareEffect要求context.attackPool提供commit、scope='runtime_src_pools'、complete=true、manifestSha256和完整有序cardIds。模块验证结构、成员存在/类型/稀有度/非HEALING，不删成员、不回退、不重抽。**这些字段自身不是完整性的独立证明**：完整性、运行来源与原顺序是host安装manifest前的外部审计义务。本片没有提供任何已接受的完整池正例；不得用一个自称complete的子集把这张牌标成已支持。池内缺少任何定义即拒绝，不能跳过该ID后继续抽。

随机选择与makeCopy发生于card.use，而非后续生成action执行时；prepare返回克隆RNG后的状态，由host事务提交。普通非负costForTurn置0；X等负哨兵不变，因为source setCostForTurn只修改旧costForTurn>=0的牌。生成Whirlwind不能硬写成0费普通攻击。MasterReality、不同创建/复制路径等依旧需要各自的真实规则接点，未知组合不得静默降级。

## Feed立即奖励与Juggernaut的正数加盾

FeedAction在同一个update里先target.damage，然后检查 `(isDying || currentHealth<=0) && !halfDead && !hasPower(Minion)`，立即increaseMaxHp(amount)，后者立刻heal(amount)。源字面不按lastDamageTaken>0判奖励；正常CardQueue的目标有效性检查另行存在。Minion即使计数为0仍是有该Power，不能仅判断amount>0。

Thorns在target.damage内部只是排TOP，Feed直接涨上限回血先完成，再执行反伤。因此玩家1HP用Feed击杀带Thorns2敌人，基础可先+3maxHP/回血至4，再反伤到2而胜利；这不同于Reaper的BOTTOM延迟Heal。host必须收集当前伤害反应，立即奖励后再排/执行，不能先调用会自动drain反伤的普通M.damage再尝试救活死人。

永久maxHP要在Run成功事务中发布，尤其在combat_end BurningBlood等治疗使用run.maxHp封顶之前，不能被旧上限反向夹掉；未终局Feed击杀后的保存也不能只留Combat表。下一场Combat的规则上限须使用新run.maxHp。治疗修正/禁疗、无尽FullBelly等未接分支不能冒称已兼容；本片目标仍是普通PC A0。

JuggernautPower.onGainedBlock的正数判断发生在AbstractCreature.addBlock中：先经过玩家遗物修正，对tmp>0调用Power hook，再经过敌Power修正、floor并加当前盾，最后封顶999。因此已999盾仍收到正数addBlock时照常触发，不能按最终新增delta=0拒绝。0输入不触发。其DamageRandomEnemyAction在后续执行时才选当前活敌，单敌random(0)，无活敌无RNG；伤害为玩家owner的THORNS，不受普通攻击修正。

Entrench原DoubleYourBlockAction在currentBlock>0时调用addBlock(currentBlock)，同样触发Juggernaut；它不是直接乘当前表字段，也不重新加Dex/Frail。FNP、Metallicize、药水和其他真实GainBlock入口也要统一经过同一hook。

## 纯数据接口

- withCards / adaptDefinition：独立数据与Searing计数适配。canUpgrade / upgradeInstance只操作明确给出的实例。
- prepareEffect(state,effect,target,context)：Havoc/Infernal的use时点RNG返回第二个afterRng；Feed捕获NORMAL伤害。不能在预览里消费RNG。
- planEffect：TOP数组按执行顺序，host反序pushTop；BOTTOM照数组顺序追加。internalOps声明swordBoomerangHit/juggernautRandomDamage需要再次在执行时调planner，保持延后随机与动态伤害。
- choiceSpec / planChoice：仅提供快照、候选和纯计划，host持有token/暂停/恢复事务。handOrder必须被执行，copyFinalCard的replaceOriginal=true处理所选原实例消失，而非丢弃/消耗。
- prepareUse：纯构造计划含powerChanges和独立cardQueue，不直接消费DoubleTap次数；host须在正确构造时提交。cardQueue与actionQueue分开，不存回调函数。
- onGainedBlock：只接玩家正数pre-cap输入，返回BOTTOM随机伤害计划；planHook(double_tap,turn_end)排移除；feedEligible仅判资格，Core执行直接永久奖励和治疗。

新公共ops：armaments/havoc/swordBoomerang/dualWield/infernalBlade/feedDamage/gainWarriorFinalPower。该专用名称避免与SilentFinal等模块分派歧义，source card/status ID不变。host还需执行upgradeFinalCard、finalHandChoice、copyFinalCard、stageHavocCard、createFinalAttack、resolveFeed、finalThornsDamage、removeFinalPower等typed指令。没有这些执行器就维持明确unsupported，不能因helper能返回表便宣称原牌可玩。

## 验证证据与未完成项

`tests/lua/warrior_final_build.lua`计划25组，组件与真实Core分段报告。组件11组实际通过，覆盖次数成长、升级/选择次序、复制身份、空Havoc仍预抽目标、完整池缺失拒绝、随机动作执行时重算、DoubleTap constructor计划、Minion/halfDead、999盾hook。

当前真实Core在第12组Armaments返回 `unsupported_effect:armaments`，整文件exit1；没有替换规则函数把它伪装成绿。后续真实回归已经写好：Havoc原顶牌免费耗牌、空牌堆随机调用、Sword动态存活目标、Dual自动复制、Infernal无池原子拒绝、Run+3Searing进战斗/战斗副本升级、DoubleTap两张攻击各一次、Feed先回血后Thorns/Minion/Run永久上限/下场上限、Juggernaut满盾与Entrench。

没有真实完整随机池正例，没有宣称存档系统已保留Searing次数，也没有宣称Havoc任意自动牌/所有选择组合已支持。共享选择/自动CardQueue/永久状态/生成池尚需root隔离树接线并复跑。未fullsuite、提交、推送、Backlog修改、平台导入或实机验收。

## 固定来源SHA-256

| 固定来源 | SHA-256 |
| --- | --- |
| [actions/GameActionManager.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/GameActionManager.java) | `a47d1ee9c6b2e194b7d3ef311328f2a15e38f5630330689e438e46685b94d6c3` |
| [actions/common/AttackDamageRandomEnemyAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/AttackDamageRandomEnemyAction.java) | `2d5dce7ccb54cf086c5001d689bf08c5550c456e29048e0987af16f3bdc33c36` |
| [actions/common/DamageRandomEnemyAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/DamageRandomEnemyAction.java) | `f5bec8e7131c871fc52441b8b1f38a6b7224cf77a66349e1527647bd589e5d38` |
| [actions/common/PlayTopCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/common/PlayTopCardAction.java) | `dc0bae486cfa50d1470b54917d08ae240b014d96566e5cf32f3d5b0f4aabfd34` |
| [actions/unique/ArmamentsAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/ArmamentsAction.java) | `3692ce99d8f26b63a5bb92ef6853bcb1d3daf33067da38384f2b4382dae29769` |
| [actions/unique/DoubleYourBlockAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/DoubleYourBlockAction.java) | `09de35c50696a2cd855f44598d5497d2ca89a06c57711535eb23eff836f24d48` |
| [actions/unique/DualWieldAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/DualWieldAction.java) | `5bff1e3565d299b4ddbf8c7f5bacfcf4570f87a1b4303e28da1c59306b362822` |
| [actions/unique/FeedAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/unique/FeedAction.java) | `b6230b7994f75e0131772414d0e33513a3dc32755102b35c48ed22197b52482c` |
| [actions/utility/NewQueueCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/utility/NewQueueCardAction.java) | `8a49f78ae34c588f8d9c0f8243d24950b4945b915e20da5ad7ec026c3e6f3747` |
| [actions/utility/UseCardAction.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/actions/utility/UseCardAction.java) | `90213939af6d7ec83dea01bb2feef4ba762a93400dc1535732e2eebcdb6cab0f` |
| [cards/AbstractCard.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/AbstractCard.java) | `bcd472ececfd8ce4150ccd4eb6dd07a2e2dc43e139196fe00de34705cf1a2a61` |
| [cards/CardQueueItem.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/CardQueueItem.java) | `43e8dcc2ddaae4e7eb1e972e2bf984e3e905664e076db80acbd3496660672b01` |
| [cards/red/Armaments.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/Armaments.java) | `fa2dcc31e4199ba110236727b4c35c4d1aca11feaaa8ebc41194f8e2ef23159a` |
| [cards/red/DoubleTap.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/DoubleTap.java) | `c9b0b20c90c46771bc8be356a92c8a9aab05c16a6cd2cd083ce08cee18154df4` |
| [cards/red/DualWield.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/DualWield.java) | `a48cc9e2c69d56b4309ff3bd71060a1976bfc74089c490d4ccecdbcba70ba5fd` |
| [cards/red/Feed.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/Feed.java) | `f7b4e52500505e72563a747dac94beb5583106ef17c33730e4798f7b94ee9bf8` |
| [cards/red/Havoc.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/Havoc.java) | `3833783e8fb1ed6d4fb5d182eb0b75855cae6e5e3fa0efec851cfb44bc62bfc5` |
| [cards/red/InfernalBlade.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/InfernalBlade.java) | `5bf131e649935ea41eb2194f63c3606b37ca3524fbabd8dfa33441117e0380a2` |
| [cards/red/Juggernaut.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/Juggernaut.java) | `961f7888469394ec2896292ee742d4a9b5775b516692aea211eb51b9484add08` |
| [cards/red/SearingBlow.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/SearingBlow.java) | `93aed26c36c2bdfdac23b3d38da135332dcaefe8b43f66461bdbb69b85a1765b` |
| [cards/red/SwordBoomerang.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/cards/red/SwordBoomerang.java) | `ee3b038998121d6ec725670484ca951de858bada1f4ee2dad903219b797dc389` |
| [characters/AbstractPlayer.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/characters/AbstractPlayer.java) | `2720ba8dd7a216781a3b2fcb709f5ec67dc9b2559af25f7f6b89df1ef0947d95` |
| [core/AbstractCreature.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/core/AbstractCreature.java) | `3db6e08c6bd033192aa368e29ad53f4614194898ccf0f525480fe20cb8799f2b` |
| [dungeons/AbstractDungeon.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/dungeons/AbstractDungeon.java) | `8fa0712818487a360c72950d053fe77e1a35efa967080723d15c69037092fd26` |
| [monsters/MonsterGroup.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/monsters/MonsterGroup.java) | `535770201b8aa8de01b52b185979af537f11ad0862e7d3e71ebb20cc64234221` |
| [powers/DoubleTapPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/DoubleTapPower.java) | `229c04c01990e446cbc87fab011a373f65734079f542d09c787d35742a3095ee` |
| [powers/JuggernautPower.java](https://github.com/aeubanks/sts/blob/319009d5df0a82d9fb0f23cc22322286c6a87ec0/powers/JuggernautPower.java) | `95710b68f4ef9e20b1e5b3fcfb2ead2afe54b0fad5173d205e1b690ed81d19f2` |
