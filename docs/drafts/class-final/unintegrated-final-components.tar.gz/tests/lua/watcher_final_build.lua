package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local Final=require('abyss_watcher_final_cards')
local Flow=require('abyss_watcher_flow_cards')
local Profiles=require('abyss_character_profiles')
local Combat=require('abyss_combat')
local Data=require('abyss_data')
local n=0
local function eq(a,b)assert(a==b,tostring(a)..' ~= '..tostring(b))end
local function test(name,fn)fn();n=n+1;print('ok watcher_final_build '..n..' - '..name)end
local function data()return Final.withCards(Flow.withCards(Profiles.prepare(Data,'watcher')))end
local function map(d)local out={};for _,c in ipairs(d.cards.cards)do out[c.id]=c end;return out end
local function battle(deck)return Combat.new(data(),{seed=42,cardRandomSeed='42',enableStances=true,enemies={'cultist'},deck=deck or {'strike_purple','defend_purple'}})end
local function plain(v,path)if type(v)=='table'then path=path or {};assert(not path[v]and not getmetatable(v));path[v]=true
 for k,x in pairs(v)do assert(type(k)=='number'or type(k)=='string');plain(x,path)end;path[v]=nil
 else assert(type(v)=='boolean'or type(v)=='number'or type(v)=='string')end end
local function unchanged(s)
 local old,waiting={}, {s}
 while #waiting>0 do local t=table.remove(waiting);if not old[t]then local e={};old[t]=e;for k,v in pairs(t)do e[k]=v;if type(v)=='table'then waiting[#waiting+1]=v end end end end
 return function()for t,e in pairs(old)do for k,v in pairs(t)do eq(e[k],v)end;for k,v in pairs(e)do eq(t[k],v)end end end
end
test('mother table subtraction is exactly twenty unique normal purple source cards',function()
 local before=Flow.withCards(Profiles.prepare(Data,'watcher'));local prior=map(before);local d=data();local count=0
 for _,c in ipairs(d.cards.cards)do if c.color=='purple'and c.rarity~='special'then count=count+1 end end
 eq(count,75);local added=0;for _,c in ipairs(d.cards.cards)do if not prior[c.id]and c.color=='purple'then added=added+1 end end;eq(added,20)
 local c=map(d);eq(c.foresight.sourceId,'Wireheading');eq(c.judgment.sourceId,'Judgement');assert(c.vault)
end)
test('definitions and Chinese descriptions are detached and duplicate registration rejects',function()
 local d=data();local original=map(d).conclude.cost;map(d).conclude.cost=9;eq(map(data()).conclude.cost,original)
 local prior=map(Flow.withCards(Profiles.prepare(Data,'watcher')))
 for _,c in ipairs(data().cards.cards)do if not prior[c.id]then assert(c.text and c.upgradeText)end end
 local same=unchanged(d);eq(pcall(Final.withCards,d),false);same()
end)
test('uncommon base upgraded values and ordering are fixed',function()
 local c=map(data());eq(c.foreign_influence.cost,0);eq(c.foreign_influence.exhaust,true);eq(c.foreign_influence.upgrade.effects[1].value,1)
 eq(c.conclude.effects[1].value,12);eq(c.conclude.upgrade.effects[1].value,16);eq(c.conclude.effects[2].op,'watcherFinalEndTurnEarly')
 eq(c.meditate.effects[1].value,1);eq(c.meditate.upgrade.effects[1].value,2);eq(c.meditate.effects[2].stance,'Calm');eq(c.meditate.effects[3].op,'watcherFinalEndTurnEarly')
 eq(c.swivel.cost,2);eq(c.swivel.effects[1].value,8);eq(c.swivel.upgrade.effects[1].value,11);eq(c.swivel.effects[2].status,'free_attack')
 eq(c.wave_of_the_hand.effects[1].value,1);eq(c.wave_of_the_hand.upgrade.effects[1].value,2)
 eq(c.foresight.effects[1].value,3);eq(c.foresight.upgrade.effects[1].value,4)
end)
test('rare flag and cost upgrades preserve their distinct source changes',function()
 local c=map(data());eq(c.alpha.upgrade.innate,true);eq(c.alpha.exhaust,true);eq(c.blasphemy.upgrade.selfRetain,true)
 eq(c.conjure_blade.cost,-1);eq(c.conjure_blade.upgrade.effects[1].value,1);eq(c.deus_ex_machina.cost,-2)
 eq(c.deva_form.ethereal,true);eq(c.deva_form.upgrade.ethereal,false);eq(c.master_reality.upgrade.cost,0)
 eq(c.omniscience.cost,4);eq(c.omniscience.upgrade.cost,3);eq(c.establishment.upgrade.innate,true)
 eq(c.vault.cost,3);eq(c.vault.upgrade.cost,2);eq(c.vault.exhaust,true);eq(c.vault.effects[1].op,'watcherFinalSkipEnemiesTurn')
end)
test('rare numeric upgrades and all six derivatives are complete typed definitions',function()
 local c=map(data());eq(c.judgment.effects[1].value,30);eq(c.judgment.upgrade.effects[1].value,40)
 eq(c.lesson_learned.effects[1].value,10);eq(c.lesson_learned.upgrade.effects[1].value,13)
 eq(c.ragnarok.effects[1].times,5);eq(c.ragnarok.upgrade.effects[1].times,6);eq(c.ragnarok.upgrade.effects[1].value,6)
 eq(c.spirit_shield.effects[1].value,3);eq(c.spirit_shield.upgrade.effects[1].value,4)
 eq(c.beta.cost,2);eq(c.beta.upgrade.cost,1);eq(c.beta.exhaust,true);eq(c.beta.effects[1].cardId,'omega')
 eq(c.omega.cost,3);eq(c.omega.effects[1].value,50);eq(c.omega.upgrade.effects[1].value,60)
 eq(c.expunger.cost,1);eq(c.expunger.effects[1].value,9);eq(c.expunger.upgrade.effects[1].value,15)
 for _,id in ipairs({'become_almighty','fame_and_fortune','live_forever'})do eq(c[id].rarity,'special');eq(c[id].cost,-2);eq(c[id].optionOnly,true)end
end)
test('status metadata preserves EndTurnDeath buff and Establishment priority twenty-five',function()
 local defs={};for _,s in ipairs(data().statuses.statuses)do defs[s.id]=s end
 eq(defs.end_turn_death.kind,'buff');eq(defs.end_turn_death.stack,'none');eq(defs.establishment.priority,25)
 eq(defs.foresight.sourceId,'WireheadingPower');eq(defs.master_reality.stack,'none');eq(defs.wave_of_the_hand.decay,'none')
end)
test('Spirit Shield counts other hand cards by identity then gets ordinary block modifiers once',function()
 local s=battle({'spirit_shield','strike_purple','defend_purple'});local c
 for _,x in ipairs(s.hand)do if x.cardId=='spirit_shield'then c=x end end
 local d=map(data()).spirit_shield;local adapted=Final.adaptDefinition(s,c,d);eq(adapted.effects[1].op,'block');eq(adapted.effects[1].value,6);eq(d.effects[1].op,'watcherFinalSpiritShield')
 c.upgraded=true;eq(Final.adaptDefinition(s,c,d).effects[1].value,8)
 local e=Final.prepareEffect(s,{op='watcherFinalSpiritShield',value=4},{instance=c});eq(e.baseBlock,8)
 local p=Final.planEffect(s,e);eq(p.bottom[1].op,'block');eq(p.bottom[1].value,8)
end)
test('Expunger stored hit count survives adaptation and upgrade changes damage only',function()
 local s=battle({'expunger'});local c=s.hand[1];c.expungerHits=0
 local d=Final.adaptDefinition(s,c,map(data()).expunger);eq(d.effects[1].times,0)
 c.expungerHits=4;c.upgraded=true;d=Final.adaptDefinition(s,c,map(data()).expunger);eq(d.effects[1].times,4);eq(d.effects[1].value,15)
 local p=Final.planEffect(s,d.effects[1],{target=s.enemies[1]});eq(#p.bottom,4);eq(p.bottom[1].op,'damage');eq(p.bottom[4].value,15)
end)
test('Conjure snapshots X plus upgrade and Chemical X without mutating energy',function()
 local s=battle();s.energy=5;local same=unchanged(s)
 local e=Final.prepareEffect(s,{op='watcherFinalConjureBlade',value=1},{energyOnUse=2,freeToPlayOnce=true,chemicalX=true})
 local p=Final.planEffect(s,e);eq(p.bottom[1].instanceFields.expungerHits,5);eq(p.consumeAllEnergy,false);same()
 e=Final.prepareEffect(s,{op='watcherFinalConjureBlade',value=0},{energyOnUse=0});p=Final.planEffect(s,e)
 eq(p.bottom[1].instanceFields.expungerHits,0);eq(#p.bottom,1);eq(p.consumeAllEnergy,true)
end)
test('Conjure energy fallback uses current snapshot only for nil or minus-one sentinel',function()
 local s=battle();s.energy=3
 eq(Final.prepareEffect(s,{op='watcherFinalConjureBlade',value=0},{}).energyOnUse,3)
 eq(Final.prepareEffect(s,{op='watcherFinalConjureBlade',value=0},{energyOnUse=-1}).energyOnUse,3)
 eq(pcall(Final.prepareEffect,s,{op='watcherFinalConjureBlade',value=0},{energyOnUse=-2}),false)
end)
test('Foresight queues TOP shuffle only for empty draw and BOTTOM scry before normal draw',function()
 local s=battle();s.player.statuses.foresight=4;s.draw={};local p=Final.planHook(s,'foresight','turn_start')
 eq(p.top[1].op,'shuffleEmptyDraw');eq(p.bottom[1].op,'scry');eq(p.bottom[1].value,4)
 s.draw={s.hand[1]};p=Final.planHook(s,'foresight','turn_start');eq(#p.top,0);eq(#p.bottom,1)
 eq(#Final.planHook(s,'foresight','turn_end').bottom,0)
end)
test('Blasphemy uses next-start HP loss not direct kill and removes after queued loss',function()
 local s=battle();s.player.statuses.end_turn_death=1;local p=Final.planHook(s,'end_turn_death','turn_start')
 eq(#p.bottom,2);eq(p.bottom[1].op,'loseHp');eq(p.bottom[1].value,99999);eq(p.bottom[1].sourceId,s.player.id)
 eq(p.bottom[2].op,'removeWatcherFinalPower');eq(#Final.planHook(s,'end_turn_death','turn_end').bottom,0)
end)
test('Deva stack changes gain immediately and recharge separates gain from future increment',function()
 local s=battle();eq(Final.planPowerApplied(s,'deva_form',1).updates.devaEnergyGain,1)
 s.player.statuses.deva_form=1;s.devaEnergyGain=3
 eq(Final.planPowerApplied(s,'deva_form',1).updates.devaEnergyGain,4)
 s.player.statuses.deva_form=2;local p=Final.planHook(s,'deva_form','energy_recharge')
 eq(p.immediate[1].value,3);eq(#p.bottom,0);eq(p.updates.devaEnergyGain,5);eq(s.devaEnergyGain,3)
end)
test('Swivel free attack persists beyond round but purge repeats do not consume a layer',function()
 local s=battle();s.player.statuses.free_attack=2
 eq(Final.freeAttack(s,{type='attack'}),true);eq(Final.freeAttack(s,{type='skill'}),false)
 local p=Final.planUseCard(s,{type='attack'});eq(p.updates.free_attack,1);eq(#p.top,0)
 eq(Final.planUseCard(s,{type='attack',purgeOnUse=true}).updates.free_attack,nil)
 s.player.statuses.free_attack=1;p=Final.planUseCard(s,{type='attack'});eq(p.updates.free_attack,0);eq(p.top[1].op,'removeWatcherFinalPower')
 eq(#Final.planHook(s,'free_attack','round_end').bottom,0)
end)
test('Wave sees positive float callback even at cap or below floor and applies Weak BOTTOM',function()
 local s=battle();s.player.statuses.wave_of_the_hand=2;s.player.block=999
 local p=Final.planGainedBlock(s,0.25);eq(#p.bottom,1);eq(p.bottom[1].op,'applyStatus');eq(p.bottom[1].status,'weak');eq(p.bottom[1].value,2)
 eq(#Final.planGainedBlock(s,0).bottom,0);eq(#Final.planGainedBlock(s,-1).bottom,0)
 eq(Final.planHook(s,'wave_of_the_hand','round_end').bottom[1].op,'removeWatcherFinalPower')
end)
test('Establishment defers scanning retained cards until action executes and handles both cost branches',function()
 local s=battle({'defend_purple'});local c=s.hand[1];s.player.statuses.establishment=2
 eq(Final.planHook(s,'establishment','turn_end').bottom[1].op,'discountRetainedFinal')
 eq(Final.planRetainDiscount(s,c,{cost=5}),nil);c.retain=true
 local p=Final.planRetainDiscount(s,c,{cost=5});eq(p.combatCost,3);eq(p.turnCost,3)
 c.combatCost=5;c.turnCost=0;p=Final.planRetainDiscount(s,c,{cost=5});eq(p.combatCost,3);eq(p.turnCost,0)
 c.combatCost=-1;c.turnCost=-1;eq(Final.planRetainDiscount(s,c,{cost=-1}),nil)
end)
test('Omega is ownerless THORNS and plated armor block occurs before end cards',function()
 local s=battle();s.player.statuses.omega=50;s.player.statuses.plated_armor=6
 local p=Final.planHook(s,'omega','turn_end');eq(p.bottom[1].damageType,'THORNS');eq(p.bottom[1].sourceIsNil,true);eq(p.bottom[1].fixed,true)
 eq(#Final.planHook(s,'omega','turn_end',{isPlayer=false}).bottom,0)
 eq(#Final.planHook(s,'plated_armor','turn_end').bottom,0);eq(Final.planHook(s,'plated_armor','turn_end_pre_cards').bottom[1].value,6)
end)
test('Plated Armor falls only after actual external NORMAL HP damage',function()
 local s=battle();s.player.statuses.plated_armor=6
 eq(Final.planPowerApplied(s,'plated_armor',999).updates.plated_armor,999)
 eq(#Final.planHpLost(s,{damageType='NORMAL',damage=1,sourceId='cultist'}).bottom,1)
 for _,c in ipairs({{damageType='NORMAL',damage=0,sourceId='cultist'},{damageType='THORNS',damage=1,sourceId='cultist'},
  {damageType='HP_LOSS',damage=1,sourceId='cultist'},{damageType='NORMAL',damage=1,sourceId=s.player.id},{damageType='NORMAL',damage=1}})do
  eq(#Final.planHpLost(s,c).bottom,0)
 end
end)
test('Deus Ex Machina draw order exhausts original before generating normal Miracles',function()
 local s=battle({'deus_ex_machina'});local c=s.hand[1];local p=Final.planDrawn(s,c)
 eq(p.top[1].op,'exhaustSpecificFinal');eq(p.top[1].uid,c.uid);eq(p.top[2].op,'watcherFinalGenerate');eq(p.top[2].cardId,'miracle');eq(p.top[2].value,2)
 c.upgraded=true;eq(Final.planDrawn(s,c).top[2].value,3);eq(Final.planDrawn(s,c).top[2].upgraded,false)
 eq(Combat.canPlay(s,c.uid),false)
end)
test('Meditate auto-all marks retain even when full while manual overflow does not',function()
 local s=battle();s.discard=s.hand;s.hand={};local uid=s.discard[1].uid
 for i=1,10 do s.hand[i]={uid=100+i,cardId='defend_purple'}end
 local auto=Final.planMeditateChoice(s,{uid},true);eq(auto.updates[1].retain,true);eq(auto.updates[1].moveToHand,false)
 local manual=Final.planMeditateChoice(s,{uid},false);eq(manual.updates[1].retain,nil);eq(manual.updates[1].moveToHand,false)
 s.discard[1].retain=true;manual=Final.planMeditateChoice(s,{uid},false);eq(manual.updates[1].retain,nil);eq(s.discard[1].retain,true)
 table.remove(s.hand);manual=Final.planMeditateChoice(s,{uid},false);eq(manual.updates[1].retain,true);eq(manual.updates[1].moveToHand,true);eq(manual.updates[1].handHook,false)
end)
test('Meditate validates source identity and no duplicate selected UID before mutation',function()
 local s=battle();s.discard=s.hand;s.hand={};local same=unchanged(s)
 eq(pcall(Final.planMeditateChoice,s,{s.discard[1].uid,s.discard[1].uid},true),false);same()
 eq(pcall(Final.planMeditateChoice,s,{999},false),false);same()
end)
test('Omniscience moves original then queues stat-equivalent new-source purge copy in FIFO order',function()
 local s=battle();s.draw=s.hand;s.hand={};local selected=s.draw[1];local same=unchanged(s)
 local p=Final.planOmniscienceChoice(s,selected.uid,2);eq(p.move.from,'draw');eq(p.move.to,'limbo');eq(p.move.instanceFields.exhaust,true)
 eq(p.bottom[1].copy,false);eq(p.bottom[1].purgeOnUse,false);eq(p.bottom[2].copyMode,'statEquivalentNewSource');eq(p.bottom[2].purgeOnUse,true)
 eq(p.bottom[1].randomTarget,true);eq(p.bottom[2].randomTarget,true);eq(p.bottom[1].immediate,false);same();plain(p)
end)
test('Lesson snapshots ordinary damage but upgrades eligible master deck via misc RNG after actual kill',function()
 local s=battle();s.player.statuses.strength=2;local e=Final.prepareEffect(s,{op='watcherFinalLessonLearned',value=10},{target=s.enemies[1]})
 eq(e.normalAmount,12);local p=Final.planEffect(s,e,{target=s.enemies[1]});eq(p.bottom[1].op,'lessonDamageAndUpgrade');eq(p.bottom[1].upgradeBeforeVictoryClear,true)
 local enemy=s.enemies[1];enemy.hp=0;p=Final.planLessonResult(enemy,{'master-1','master-2'});eq(p.bottom[1].rng,'miscRng');eq(#p.bottom[1].candidateKeys,2)
 enemy.halfDead=true;eq(#Final.planLessonResult(enemy,{'master-1'}).bottom,0);enemy.halfDead=false;enemy.statuses.minion=1
 eq(#Final.planLessonResult(enemy,{'master-1'}).bottom,0);enemy.statuses.minion=nil;eq(#Final.planLessonResult(enemy,{}).bottom,0)
end)
test('Judgment schedules direct HP-zero action at cutoff without treating it as damage',function()
 local s=battle();s.enemies[1].hp=30;local p=Final.planEffect(s,{op='watcherFinalJudgment',value=30},{target=s.enemies[1]})
 eq(p.top[1].op,'instantKill');eq(p.top[1].sourceIsNil,true);s.enemies[1].hp=31;eq(#Final.planEffect(s,{op='watcherFinalJudgment',value=30},{target=s.enemies[1]}).top,0)
end)
test('Ragnarok keeps six distinct RNG target and damage recalculations without planning RNG use',function()
 local s=battle();local same=unchanged(s);local p=Final.planEffect(s,{op='watcherFinalRagnarok',value=6,times=6},{instance=s.hand[1]})
 eq(#p.bottom,6);for _,a in ipairs(p.bottom)do eq(a.op,'randomAttackRecalculate');eq(a.rng,'cardRandomRng');eq(a.value,6)end;same()
end)
test('Master Reality records each real generation stage without upgrading existing retrieved cards',function()
 local s=battle();s.player.statuses.master_reality=1
 for _,stage in ipairs({'hand_action_constructor','hand_effect','discard_effect','draw_action_update'})do
  eq(Final.planGenerated(s,{type='attack'},stage).bottom[1].op,'upgradeGeneratedFinal')
  eq(#Final.planGenerated(s,{type='status'},stage).bottom,0);eq(#Final.planGenerated(s,{type='curse'},stage).bottom,0)
 end
 eq(pcall(Final.planGenerated,s,{type='skill'},'retrieved_existing'),false)
end)
test('Foreign Influence demands complete unlocked non-healing Attack pool and explicit rarity rolls',function()
 local s=battle();local same=unchanged(s);local p=Final.planEffect(s,{op='watcherFinalForeignInfluence',value=1})
 eq(p.bottom[1].poolContract,'full_CardLibrary_attack_nonhealing_unlocked');eq(p.bottom[1].rarityRoll.common,55)
 eq(p.bottom[1].rarityRoll.uncommon,30);eq(p.bottom[1].rarityRoll.rare,15);eq(p.bottom[1].zeroCostForTurn,true);eq(p.bottom[1].uniqueBy,'sourceId')
 eq(p.bottom[1].rarityRng,'cardRandomRng');eq(p.bottom[1].shuffleRng,'cardRandomRng');eq(p.bottom[1].selectionRng,'cardRng');eq(p.bottom[1].selectionSort,'sourceId_Java_compareTo');same()
end)
test('Wish has three genuine typed options with base/up values and no deck generation',function()
 for _,up in ipairs({false,true})do
  local opts=Final.wishChoices(up);eq(#opts,3);eq(opts[1].id,'become_almighty');eq(opts[2].id,'fame_and_fortune');eq(opts[3].id,'live_forever')
  eq(opts[1].effects[1].value,up and 4 or 3);eq(opts[2].effects[1].value,up and 30 or 25);eq(opts[3].effects[1].value,up and 8 or 6)
  for _,opt in ipairs(opts)do local p=Final.planWishChoice(opt.id,up);eq(#p.bottom,1);assert(p.bottom[1].op~='watcherFinalGenerate');plain(p)end
 end
 eq(pcall(Final.planWishChoice,'invented',false),false)
end)
test('Vault orders skip-monster before early-turn cleanup and does not replay enemy turn',function()
 local s=battle();local c=map(data()).vault
 local a=Final.planEffect(s,c.effects[1]);local b=Final.planEffect(s,c.effects[2])
 eq(a.bottom[1].op,'setSkipMonsterTurn');eq(b.bottom[1].op,'pressEndTurnEarly')
end)
test('plans contain plain data and invalid fields reject without changing real state',function()
 local s=battle();local same=unchanged(s);plain(Final.planEffect(s,{op='watcherFinalWish',value=0}))
 eq(pcall(Final.prepareEffect,s,{op='watcherFinalRagnarok',value=6,times=0}),false)
 eq(pcall(Final.prepareEffect,s,{op='watcherFinalForeignInfluence',value=0,callback=function()end}),false)
 local cyclic={op='watcherFinalForeignInfluence',value=0};cyclic.self=cyclic;eq(pcall(Final.prepareEffect,s,cyclic),false);same()
end)
print('WATCHER_FINAL_COMPONENT_PASS '..n)
print('WATCHER_FINAL_CORE_NOT_CONNECTED: definitions/plans are not real Combat.play evidence')
