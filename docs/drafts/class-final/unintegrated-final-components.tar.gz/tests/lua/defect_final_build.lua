package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local C=require('abyss_combat')
local O=require('abyss_orbs')
local R=require('abyss_sts_random')
local F=require('abyss_defect_final_cards')
local raw=require('abyss_data')
local base=require('abyss_character_profiles').prepare(raw,'defect')
local function has(data,id)for _,c in ipairs(data.cards.cards)do if c.id==id then return true end end end
if not has(base,'claw')then base=require('abyss_defect_engine_cards').withCards(base)end
local available,retrieval=pcall(require,'abyss_retrieval_cards')
if available and not has(base,'hologram')then base=retrieval.withCards(base,'defect')end
local data=has(base,'rebound')and base or F.withCards(base)
local n=0
local function eq(a,b)assert(a==b,tostring(a)..' ~= '..tostring(b))end
local function test(name,fn)fn();n=n+1;print('ok '..n..' '..name)end
local function sourceOptions(deck)
 return {seed=42,roomSeed='17',roomStreams={cardRandomRng=R.fromSeed('17'),shuffleRng=R.fromSeed('17'),
  aiRng=R.fromSeed('17'),monsterHpRng=R.fromSeed('17')},orbSlots=3,deck=deck,enemies={'jaw_worm','jaw_worm'}}
end
local function setup(id,up,count)
 local deck={};for i=1,(count or 1)do deck[i]={cardId=id,upgraded=up or false}end
 local s=C.new(data,sourceOptions(deck));s.defectSourcePoolProfile=F.poolProfile;return s
end
local function uid(s,id)for _,c in ipairs(s.hand)do if c.cardId==id then return c.uid end end;error('not in hand '..id)end
local function play(s,id,target)assert(C.play(s,uid(s,id),target))end
local function count(pile,id)local n=0;for _,c in ipairs(pile)do if c.cardId==id then n=n+1 end end;return n end
local function fixtureAttack(s,value)
 for i,a in ipairs(s.enemies)do a.ai=nil;a.intents={{id='probe',effects={i==1 and {op='damage',value=value}or{op='block',value=0}}}};a.intentIndex=1 end
end
test('nineteen final definitions preserve source IDs costs upgrades and healing tag',function()
 local by={};for _,c in ipairs(data.cards.cards)do by[c.id]=c end
 local ids={'rebound','recursion','force_field','genetic_algorithm','hello_world','recycle','scrape','self_repair','static_discharge','equilibrium','white_noise','all_for_one','amplify','buffer','creative_ai','echo_form','fission','machine_learning','reboot'}
 for _,id in ipairs(ids)do local c=assert(by[id]);assert(c.sourceId and c.text and c.upgradeText and c.upgrade)end
 eq(by.recursion.sourceId,'Redo');eq(by.equilibrium.sourceId,'Undo');eq(by.genetic_algorithm.misc,1);eq(by.self_repair.sourceTags[1],'HEALING')
 eq(by.echo_form.ethereal,true);eq(by.echo_form.upgrade.ethereal,false);eq(by.creative_ai.cost,3);eq(by.creative_ai.upgrade.cost,2)
 assert(not pcall(F.withCards,data))
end)
test('sourceUid permanent identity is separate from new battle UID',function()
 local c=F.makeBattleInstance({uid=91,cardId='genetic_algorithm',misc=7},1)
 eq(c.uid,1);eq(c.sourceUid,91);eq(c.misc,7);eq(c.sourceUuid,nil)
 eq(F.makeBattleInstance('zap',2,200).sourceUid,200)
 eq(F.makeBattleInstance({uid=5,cardId='zap'},3,201).sourceUid,201)
 eq(F.makeBattleInstance({uid=5,sourceUid=91,cardId='zap'},4,202).sourceUid,202)
 eq(F.makeBattleInstance({uid=5,sourceUid=91,cardId='zap'},4).sourceUid,91)
 assert(not pcall(F.makeBattleInstance,'zap',1))
end)
test('pure Genetic plan updates matching master and limbo copies without mutation',function()
 local s=setup('genetic_algorithm',false,2)
 for _,c in ipairs(s.hand)do c.sourceUid=91;c.misc=7 end
 s.masterDeck={{uid=91,cardId='genetic_algorithm',misc=7}};s.limbo={{uid=99,sourceUid=91,cardId='genetic_algorithm',misc=7}}
 local p=F.planEffect(s,{op='increaseGeneticMisc',value=2},{instance=s.hand[1]})
 eq(#p.instanceChanges,3);eq(#p.masterChanges,1);eq(p.masterChanges[1].changes.misc,9);eq(s.masterDeck[1].misc,7);eq(s.limbo[1].misc,7)
 for _,change in ipairs(p.instanceChanges)do eq(change.changes.misc,9)end
end)
test('pure incoming plan Buffer gates all positive post-block types before Static',function()
 local s=setup('buffer');s.player.statuses.buffer=1;s.player.statuses.static_discharge=2
 for _,kind in ipairs({'NORMAL','THORNS','HP_LOSS'})do
  local p=F.incomingPlan(s,{owner=s.enemies[1],target=s.player,type=kind},3)
  eq(p.amount,0);eq(#p.top,1);eq(p.top[1].status,'buffer');eq(s.player.statuses.buffer,1)
 end
 eq(#F.incomingPlan(s,{target=s.player,type='HP_LOSS'},0).top,0)
 s.player.statuses.buffer=nil
 local p=F.incomingPlan(s,{owner=s.enemies[1],target=s.player,type='NORMAL'},3);eq(p.top[1].remaining,2)
 eq(#F.incomingPlan(s,{owner=s.enemies[1],target=s.player,type='THORNS'},3).top,0)
 eq(#F.incomingPlan(s,{owner=s.player,target=s.player,type='NORMAL'},3).top,0)
end)
test('pure copy plans share sourceUid purge copies and count Echo versus real history',function()
 local s=setup('amplify');F.applyPower(s,'echo_form',1);F.applyPower(s,'amplify',2)
 s.cardsPlayedThisTurn={{type='power'}};local c=s.hand[1];c.sourceUid=91
 local p=F.prepareUse(s,{type='power'},c,{energyOnUse=3,targetId=s.enemies[1].id})
 eq(#p.copyRequests,2);eq(p.copyRequests[1].sourceUid,91);eq(p.copyRequests[1].sourceUidMode,'same');eq(p.copyRequests[1].purgeOnUse,true)
 eq(p.stateChanges.echoDoubledThisTurn,1);eq(p.statusChanges.amplify,1);eq(s.player.statuses.amplify,2);eq(s.echoDoubledThisTurn,nil)
 c.purgeOnUse=true;eq(#F.prepareUse(s,{type='power'},c,{}).copyRequests,0)
end)
test('full source generation pools have exact order and refuse incomplete catalogs',function()
 local common,power=F.sourcePool('common'),F.sourcePool('power');eq(#common,18);eq(#power,13)
 eq(common[1],'go_for_the_eyes');eq(common[18],'steam_barrier');eq(power[1],'defragment');eq(power[13],'creative_ai')
 for _,id in ipairs(power)do assert(id~='self_repair','HEALING tag must exclude SelfRepair')end
 local s=setup('white_noise');s.catalog.cards.defragment=nil
 assert(not pcall(F.validatePool,s,'power'),'must not fall back to twelve candidates')
 s.defectSourcePoolProfile=nil;assert(not pcall(F.validatePool,s,'common'))
end)
test('pure Reboot consumes both shuffle calls and one card RNG draw per remaining hand card',function()
 local s=setup('reboot',false,8);local shuffle,card=s.shuffleRng.counter,s.cardRandomRng.counter
 local p=F.planEffect(s,{op='rebootCards',value=4});eq(p.shuffleRng.counter,shuffle+2);eq(p.cardRandomRng.counter,card+#s.hand)
 eq(#p.pileOrders.draw,#s.hand+#s.draw+#s.discard);eq(#p.pileOrders.hand,0);eq(p.top[1].value,4)
 eq(s.shuffleRng.counter,shuffle);eq(s.cardRandomRng.counter,card);eq(#s.hand,5)
end)
for _,up in ipairs({false,true})do
 local tag=up and '+'or''
 test('Rebound'..tag..' skips itself then returns next attack to deck top',function()
  local s=C.new(data,sourceOptions({{cardId='rebound',upgraded=up},'strike_blue'}));local hp=s.enemies[1].hp;play(s,'rebound',1)
  eq(s.enemies[1].hp,hp-(up and 12 or 9));eq(s.player.statuses.rebound,1);play(s,'strike_blue',1)
  eq(s.draw[#s.draw].cardId,'strike_blue');eq(count(s.discard,'strike_blue'),0);eq(s.player.statuses.rebound,nil);eq(s.energy,1)
 end)
 test('Recursion'..tag..' reuses the same Dark growth and counts rechannel',function()
  local s=setup('recursion',up);assert(O.channel(s,'dark',C));O.endTurn(s,C);local stored=s.orbs.balls[1].stored;play(s,'recursion')
  eq(s.energy,up and 3 or 2);eq(#s.orbs.balls,1);eq(s.orbs.balls[1].stored,stored);eq(s.orbChannelCounts.dark,2)
 end)
 test('ForceField'..tag..' power play lowers persistent cost before use',function()
  local s=C.new(data,sourceOptions({{cardId='force_field',upgraded=up},'defragment'}));s.energy=4;play(s,'defragment')
  local instance;for _,c in ipairs(s.hand)do if c.cardId=='force_field'then instance=c end end
  eq(C.cardDefinition(s,instance).cost,3);play(s,'force_field');eq(s.energy,0);eq(s.player.block,up and 16 or 12)
 end)
 test('Genetic'..tag..' uses old misc block then grows matching permanent identity',function()
  local master={{uid=91,cardId='genetic_algorithm',misc=7,upgraded=up}};local opts=sourceOptions(master);opts.masterDeck=master
  local s=C.new(data,opts);play(s,'genetic_algorithm');eq(s.player.block,7);eq(s.energy,2);eq(s.exhaust[1].sourceUid,91)
  eq(master[1].misc,up and 10 or 9);eq(s.exhaust[1].misc,up and 10 or 9)
 end)
 test('HelloWorld'..tag..' draws no card immediately then generates full-pool common next turn',function()
  local s=setup('hello_world',up);play(s,'hello_world');eq(s.energy,2);eq(#s.hand,0);eq(s.player.statuses.hello_world,1)
  local rng=R.cloneState(s.cardRandomRng);local list=F.sourcePool('common');local wanted=list[R.randomInt(rng,#list-1)+1]
  assert(C.endTurn(s));eq(#s.hand,1);eq(s.hand[1].cardId,wanted);eq(s.cardRandomRng.counter,rng.counter)
 end)
 test('Recycle'..tag..' one other card auto-exhausts and grants its current cost',function()
  local s=C.new(data,sourceOptions({{cardId='recycle',upgraded=up},'strike_blue'}));play(s,'recycle')
  eq(count(s.exhaust,'strike_blue'),1);eq(count(s.discard,'recycle'),1);eq(s.energy,up and 4 or 3)
 end)
 test('Scrape'..tag..' discards only newly drawn nonzero cards rather than existing hand',function()
  local s=setup('scrape',up,12);play(s,'scrape',1);eq(s.energy,2);eq(#s.hand,4);eq(#s.discard,up and 6 or 5)
 end)
 test('SelfRepair'..tag..' heals actual victory once after permanent Power use',function()
  local s=C.new(data,sourceOptions({{cardId='self_repair',upgraded=up},'strike_blue'}));s.player.hp=50;s.enemies[1].hp=1;s.enemies[2].hp=0
  play(s,'self_repair');eq(s.player.hp,50);play(s,'strike_blue',1);eq(s.phase,'victory');eq(s.player.hp,up and 60 or 57)
 end)
 test('StaticDischarge'..tag..' external normal post-block HP damage channels source amount',function()
  local s=setup('static_discharge',up);fixtureAttack(s,3);local hp=s.player.hp;play(s,'static_discharge');assert(C.endTurn(s))
  eq(s.player.hp,hp-3);eq(#s.orbs.balls,up and 2 or 1);eq(s.orbChannelCounts.lightning,up and 2 or 1)
 end)
 test('Equilibrium'..tag..' keeps nonethereal hand through real endTurn then expires',function()
  local s=C.new(data,sourceOptions({{cardId='equilibrium',upgraded=up},'strike_blue'}));local strike=uid(s,'strike_blue');play(s,'equilibrium')
  eq(s.player.block,up and 16 or 13);assert(C.endTurn(s));eq(s.player.statuses.equilibrium,nil);eq(uid(s,'strike_blue'),strike)
  local retained=false;for _,event in ipairs(s.events)do if event.kind=='retain'and event.detail.count>0 then retained=true end end;assert(retained)
 end)
 test('WhiteNoise'..tag..' complete-pool Power gets temporary zero cost and new source identity',function()
  local s=setup('white_noise',up);local source=s.hand[1].sourceUid;local rng=R.cloneState(s.cardRandomRng);local list=F.sourcePool('power');local wanted=list[R.randomInt(rng,#list-1)+1]
  play(s,'white_noise');eq(s.energy,up and 3 or 2);eq(#s.hand,1);eq(s.hand[1].cardId,wanted);eq(C.cardDefinition(s,s.hand[1]).cost,0)
  assert(s.hand[1].sourceUid~=source);eq(s.cardRandomRng.counter,rng.counter);eq(count(s.exhaust,'white_noise'),1)
 end)
 test('AllForOne'..tag..' selects upgraded base-zero cards before own cleanup',function()
  local s=C.new(data,sourceOptions({{cardId='all_for_one',upgraded=up},{cardId='zap',upgraded=true},'ftl','defend_blue','dualcast'}))
  play(s,'zap');play(s,'ftl',1);play(s,'all_for_one',1);eq(s.energy,1);eq(count(s.hand,'zap'),1);eq(count(s.hand,'ftl'),1);eq(count(s.discard,'all_for_one'),1)
 end)
 test('Amplify'..tag..' really replays next power free without storing a duplicate',function()
  local s=C.new(data,sourceOptions({{cardId='amplify',upgraded=up},'defragment'}));play(s,'amplify');play(s,'defragment')
  eq(s.energy,1);eq(s.player.statuses.focus,2);eq(s.player.statuses.amplify,up and 1 or nil);eq(#s.cardsPlayedThisTurn,3);eq(#s.discard,1)
 end)
 test('Buffer'..tag..' blocks positive normal HP damage and consumes exactly one stack',function()
  local s=setup('buffer',up);fixtureAttack(s,3);local hp=s.player.hp;play(s,'buffer');assert(C.endTurn(s))
  eq(s.player.hp,hp);eq(s.player.statuses.buffer,up and 1 or nil)
 end)
 test('CreativeAI'..tag..' source cost and next-turn complete-pool Power',function()
  local s=setup('creative_ai',up);play(s,'creative_ai');eq(s.energy,up and 1 or 0);eq(#s.hand,0)
  local rng=R.cloneState(s.cardRandomRng);local list=F.sourcePool('power');local wanted=list[R.randomInt(rng,#list-1)+1]
  assert(C.endTurn(s));eq(#s.hand,1);eq(s.hand[1].cardId,wanted);eq(s.cardRandomRng.counter,rng.counter)
 end)
 test('EchoForm'..tag..' next turn first real card doubles once and copy is purged',function()
  local s=C.new(data,sourceOptions({{cardId='echo_form',upgraded=up},'strike_blue','defend_blue'}));play(s,'echo_form');assert(C.endTurn(s))
  local hp=s.enemies[1].hp;play(s,'strike_blue',1);eq(s.enemies[1].hp,hp-12);eq(s.energy,2);eq(count(s.discard,'strike_blue'),1)
  play(s,'defend_blue');eq(s.player.block,5);eq(#s.cardsPlayedThisTurn,3)
 end)
 test('Fission'..tag..' removes or evokes all before per-filled-orb energy and draw',function()
  local s=setup('fission',up,8);for i=1,3 do assert(O.channel(s,'frost',C))end;play(s,'fission')
  eq(#s.orbs.balls,0);eq(s.energy,6);eq(s.player.block,up and 15 or 0);eq(#s.hand,7);eq(#s.exhaust,1)
 end)
 test('MachineLearning'..tag..' next ordinary opening draws six without immediate draw',function()
  local s=setup('machine_learning',up,8);local hand=#s.hand;play(s,'machine_learning');eq(#s.hand,hand-1)
  assert(C.endTurn(s));eq(#s.hand,6);eq(s.player.statuses.machine_learning,1)
 end)
 test('Reboot'..tag..' source shuffles and random hand moves exclude card in use',function()
  local s=setup('reboot',up,8);local shuffle,card,hand=s.shuffleRng.counter,s.cardRandomRng.counter,#s.hand;play(s,'reboot')
  eq(#s.hand,up and 6 or 4);eq(#s.exhaust,1);eq(s.shuffleRng.counter,shuffle+2);eq(s.cardRandomRng.counter,card+hand-1)
 end)
end
test('Recursion final lethal evoke cancels rechannel and preserves original history',function()
 local s=setup('recursion');assert(O.channel(s,'lightning',C));s.enemies[1].hp=1;s.enemies[2].hp=0;play(s,'recursion')
 eq(s.phase,'victory');eq(#s.orbs.balls,0);eq(s.orbChannelCounts.lightning,1)
end)
test('Rebound is consumed by a Power without returning that Power',function()
 local s=C.new(data,sourceOptions({'rebound','defragment'}));play(s,'rebound',1);play(s,'defragment');eq(s.player.statuses.rebound,nil);eq(count(s.draw,'defragment'),0)
end)
test('Genetic late runtime failure rolls back both master misc and all instance references',function()
 local master={{uid=91,cardId='genetic_algorithm',misc=7}};local opts=sourceOptions(master);opts.masterDeck=master;local s=C.new(data,opts)
 s.catalog.cards.genetic_algorithm.effects[3]={op='gainFocus',value=2147483648};local original=s.hand[1]
 assert(not pcall(C.play,s,original.uid));eq(master[1].misc,7);eq(s.hand[1],original);eq(original.misc,7);eq(s.energy,3);eq(#s.exhaust,0)
end)
test('Echo Genetic copy shares sourceUid grows limbo before use and purges without double exhaust',function()
 local master={{uid=91,cardId='echo_form'},{uid=92,cardId='genetic_algorithm',misc=1}}
 local opts=sourceOptions(master);opts.masterDeck=master;local s=C.new(data,opts)
 play(s,'echo_form');assert(C.endTurn(s));play(s,'genetic_algorithm')
 eq(s.player.block,4);eq(master[2].misc,5);eq(count(s.exhaust,'genetic_algorithm'),1);eq(s.exhaust[1].misc,5);eq(s.exhaust[1].sourceUid,92)
end)
test('Genetic misc persists through actual Run victory rewards and next combat construction',function()
 -- Deliberate unit fixture, not a natural starter/reward route: two-card deck,
 -- no starter relic, and an explicit small-slime encounter. HP is never reset.
 local Run=require('abyss_run');local fixture=C.copy(data)
 fixture.cards.starter_deck.cards={'genetic_algorithm','strike_blue'};fixture.rules.player.startingRelics={}
 fixture.enemies.encounters[#fixture.enemies.encounters+1]={id='genetic_probe',tier='normal',minFloor=1,maxFloor=17,enemies={'spike_slime_s'}}
 local run=Run.new(fixture,'17');assert(Run.startCombat(run,'genetic_probe'))
 local first=run.combat;assert(Run.play(run,uid(first,'genetic_algorithm')));eq(run.deck[1].misc,3)
 local steps=0
 while run.phase=='combat'do
  steps=steps+1;assert(steps<=20,'bounded Genetic unit battle failed')
  local s=run.combat;local attack
  for _,c in ipairs(s.hand)do if C.canPlay(s,c.uid,1)then attack=c;break end end
  if attack then assert(Run.play(run,attack.uid,1))else assert(Run.endTurn(run))end
 end
 eq(run.phase,'reward');eq(run.lastResult.outcome,'victory');local hp=run.hp
 assert(Run.claimCardReward(run,0));if run.rewards.goldClaimed==false then assert(Run.claimGoldReward(run))end
 assert(Run.leaveCombatRewards(run));run.floor=run.floor+1;assert(Run.startCombat(run,'genetic_probe'))
 eq(run.combat.player.hp,hp);local c
 for _,card in ipairs(run.combat.hand)do if card.cardId=='genetic_algorithm'then c=card end end
 assert(c);eq(c.sourceUid,run.deck[1].uid);eq(c.misc,3);eq(C.cardDefinition(run.combat,c).effects[2].value,3)
end)
test('Buffer protects HP_LOSS and THORNS while fully blocked damage does not spend',function()
 local s=setup('buffer',true);play(s,'buffer');local hp=s.player.hp;s.player.block=5
 C.damage(s,s.enemies[1],s.player,3);eq(s.player.statuses.buffer,2);eq(s.player.block,2)
 C.retaliate(s,s.enemies[1],s.player,4);eq(s.player.hp,hp);eq(s.player.statuses.buffer,1)
 C.applyEffects(s,{{op='loseHp',value=2}},s.player,s.player);eq(s.player.hp,hp);eq(s.player.statuses.buffer,nil)
 local v=C.new(data,sourceOptions({{cardId='buffer',upgraded=true},'burn'}));fixtureAttack(v,0)
 local before=v.player.hp;play(v,'buffer');assert(C.endTurn(v));eq(v.player.hp,before);eq(v.player.statuses.buffer,1)
end)
test('Static excludes self damage THORNS and HP_LOSS and lethal attacks never actually channel',function()
 local s=setup('static_discharge');play(s,'static_discharge');C.retaliate(s,s.enemies[1],s.player,1)
 C.applyEffects(s,{{op='loseHp',value=1}},s.player,s.player);C.damage(s,s.player,s.player,1)
 eq(#s.orbs.balls,0);eq(s.orbChannelCounts.lightning,0)
 local v=setup('static_discharge');fixtureAttack(v,3);play(v,'static_discharge');v.player.hp=1;assert(C.endTurn(v));eq(v.phase,'defeat');eq(#v.orbs.balls,0)
 local burn=C.new(data,sourceOptions({'static_discharge','burn'}));fixtureAttack(burn,0);play(burn,'static_discharge');assert(C.endTurn(burn));eq(#burn.orbs.balls,0)
end)
test('Buffer cancels damage before Static can queue an actual Lightning',function()
 local s=C.new(data,sourceOptions({'buffer','static_discharge'}));fixtureAttack(s,3);play(s,'buffer');play(s,'static_discharge');assert(C.endTurn(s))
 eq(#s.orbs.balls,0);eq(s.orbChannelCounts.lightning,0);eq(s.player.statuses.buffer,nil)
end)
test('Recycle X cost snapshots remaining current energy rather than negative sentinel',function()
 local s=C.new(data,sourceOptions({'recycle','multi_cast'}));play(s,'recycle');eq(s.energy,4);eq(count(s.exhaust,'multi_cast'),1)
end)
test('Scrape last enemy kill cancels subsequent draw and follow-up discard',function()
 local s=setup('scrape',true,8);s.enemies[1].hp=1;s.enemies[2].hp=0;play(s,'scrape',1);eq(s.phase,'victory');eq(#s.hand,4)
end)
test('Equilibrium skips ethereal cards while preserving ordinary hand',function()
 local s=C.new(data,sourceOptions({'equilibrium','echo_form','strike_blue'}));play(s,'equilibrium');assert(C.endTurn(s))
 eq(count(s.exhaust,'echo_form'),1);eq(count(s.hand,'strike_blue'),1)
end)
test('Fission upgraded last kill cancels energy draw but removes every prequeued orb',function()
 local s=setup('fission',true,8);for i=1,3 do assert(O.channel(s,'lightning',C))end
 s.enemies[1].hp=1;s.enemies[2].hp=0;play(s,'fission');eq(s.phase,'victory');eq(s.energy,3);eq(#s.orbs.balls,0);eq(#s.hand,4)
end)
test('source pool missing one candidate fails WhiteNoise before spending and advancing RNG',function()
 local s=setup('white_noise');s.catalog.cards.defragment=nil;local card=s.hand[1];local rng=s.cardRandomRng.counter
 local ok,result=pcall(C.play,s,card.uid);assert(not ok or result==false);eq(s.energy,3);eq(s.hand[1],card);eq(s.cardRandomRng.counter,rng)
end)
print('DEFECT_FINAL_BUILD_PASS '..n)
