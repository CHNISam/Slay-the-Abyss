package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local Combat,Silent,Actors=require('abyss_combat'),require('abyss_silent'),require('abyss_actor')
local Cards=require('abyss_silent_final_cards')
local data=Cards.withCardDefinitions(require('abyss_silent_tactics_cards').withCardDefinitions(require('abyss_silent_attack_cards').withCardDefinitions(Silent.withFoundationCards(require('abyss_data')))))
local count,failed=0,0
local function eq(a,b,label)assert(a==b,(label or 'value')..': '..tostring(a)..' ~= '..tostring(b))end
local function test(name,fn)
 count=count+1;local ok,reason=pcall(fn)
 if ok then print('ok Silent final '..count..' - '..name)else failed=failed+1;print('not ok Silent final '..count..' - '..name..': '..tostring(reason))end
end
local function fresh(ids,handSize,two)
 local s=Combat.new(data,{deck=ids,enemies=two and {'jaw_worm','jaw_worm'}or{'jaw_worm'},seed=42,experimental=true})
 local all={};for _,name in ipairs({'hand','draw','discard','exhaust'})do for _,c in ipairs(s[name])do all[#all+1]=c end end
 table.sort(all,function(a,b)return a.uid<b.uid end)
 s.hand,s.draw,s.discard,s.exhaust={},{},{},{}
 for i,c in ipairs(all)do local pile=i<=(handSize or #all)and s.hand or s.draw;pile[#pile+1]=c end
 for _,enemy in ipairs(s.enemies)do enemy.hp,enemy.maxHp=300,300 end
 return s,all
end
local function held(s,id)for _,c in ipairs(s.hand)do if c.cardId==id then return c end end;error('not in hand: '..id)end
local function play(s,id,target)local ok,reason=Combat.play(s,held(s,id).uid,target);assert(ok,'real play refused: '..tostring(reason))end
local function card(id,up)return{cardId=id,upgraded=up}end
local function selected(s,mode,uid)
 assert(type(Combat.chooseFinalHand)=='function','shared final hand-choice command required')
 assert(s.pendingFinalHand,'real final selection pending required')
 assert(Combat.chooseFinalHand(s,{uid},s.pendingFinalHand.token))
end

test('final definitions carry all 14 source identities and exact Power priorities',function()
 local ids={};for _,c in ipairs(data.cards.cards)do ids[c.id]=c end
 for _,id in ipairs({'distraction','endless_agony','masterful_stab','setup','well_laid_plans','bullet_time','burst','corpse_explosion','doppelganger','nightmare','phantasmal_killer','tools_of_the_trade','alchemize','wraith_form'})do
  assert(ids[id]and ids[id].sourceId and ids[id].sts_name==ids[id].sourceId and ids[id].name and ids[id].text)
 end
 local powers={};for _,p in ipairs(data.statuses.statuses)do powers[p.id]=p end
 eq(powers.tools_of_the_trade.priority,25);eq(powers.intangible.priority,75);eq(powers.double_damage.priority,6)
 eq(powers.wraith_form.allowNegative,true);assert(not pcall(Cards.withCardDefinitions,data))
end)
test('copy template excludes runtime identity, preserves supported base modifiers and resetTurn distinction',function()
 local s,all=fresh({'endless_agony'});local original=all[1]
 original.sourceUid=10001;original.combatCost=2;original.turnCost=0;original.freeToPlayOnce=true;original.damageBonus=3;original.retain=true
 local ordinary=Cards.copyTemplate(s,original,false,false);eq(ordinary.uid,nil);eq(ordinary.sourceUid,nil)
 eq(ordinary.combatCost,2);eq(ordinary.turnCost,0);eq(ordinary.freeToPlayOnce,true);eq(ordinary.damageBonus,3);eq(ordinary.retain,nil)
 local nightmare=Cards.copyTemplate(s,original,true,false);eq(nightmare.turnCost,nil);eq(nightmare.combatCost,2);eq(nightmare.freeToPlayOnce,true)
 local burst=Cards.copyTemplate(s,original,false,true);eq(burst.sourceUid,10001);eq(burst.uid,nil)
 original.damageBonus=99;eq(ordinary.damageBonus,3)
end)
test('Endless Agony onDraw produces one TOP non-draw copy with upgrade and stat fields',function()
 local s,all=fresh({card('endless_agony',true)});all[1].damageBonus=2
 local actions=Cards.onDraw(s,all[1]);eq(#actions,1);eq(actions[1].op,'makeStatCardCopy');eq(actions[1].value,1)
 eq(actions[1].template.upgraded,true);eq(actions[1].template.damageBonus,2);eq(actions[1].template.uid,nil)
 eq(#Cards.onDraw(s,{cardId='defend'}),0)
end)
test('Masterful Stab positive HP event updates three piles once and preserves turn cost diff',function()
 local s,all=fresh({'masterful_stab','masterful_stab','masterful_stab','masterful_stab','masterful_stab'})
 s.hand={all[1]};s.draw={all[2]};s.discard={all[3]};s.exhaust={all[4]};s.cardInUse=all[5]
 all[1].combatCost=2;all[1].turnCost=0
 eq(Cards.onHpLost(s,s.player,0),false);eq(all[1].combatCost,2)
 assert(Cards.onHpLost(s,s.player,7));eq(all[1].combatCost,3);eq(all[1].turnCost,1)
 eq(all[2].combatCost,1);eq(all[3].combatCost,1);eq(all[4].combatCost,nil);eq(all[5].combatCost,nil)
 eq(Cards.onHpLost(s,s.enemies[1],4),false);eq(all[1].combatCost,3)
end)
test('Burst plan consumes old Power only for non-purged Skill and queues actual same-source card',function()
 local s,all=fresh({'defend'});s.player.statuses.burst=1;all[1].sourceUid=10002
 local plan=Cards.planOnUse(s,Combat.cardDefinition(s,all[1]),all[1],{targetId='enemy',energyOnUse=2})
 eq(plan.consumeBurst,true);eq(#plan.cardQueue,1);eq(plan.cardQueue[1].template.sourceUid,10002)
 eq(plan.cardQueue[1].purgeOnUse,true);eq(plan.cardQueue[1].autoplay,true);eq(plan.cardQueue[1].energyOnUse,2)
 eq(plan.top[1].status,'burst');eq(s.player.statuses.burst,1,'pure plan must not consume')
 all[1].purgeOnUse=true;eq(Cards.planOnUse(s,{type='skill'},all[1]).consumeBurst,false)
end)
test('Doppelganger zero-X upgrade and free snapshot are pure BOTTOM next-turn powers',function()
 local s=fresh({'doppelganger'});s.energy=0
 local plan=Cards.planEffect(s,{op='doppelganger',value=0},{energyOnUse=0});eq(#plan.bottom,0);eq(plan.consumeAllEnergy,false)
 plan=Cards.planEffect(s,{op='doppelganger',value=1},{energyOnUse=0,freeToPlayOnce=true})
 eq(plan.bottom[1].op,'nextEnergy');eq(plan.bottom[1].value,1);eq(plan.bottom[2].status,'draw_next_turn');eq(plan.consumeAllEnergy,false)
 assert(not pcall(Cards.planEffect,s,{op='doppelganger',value=0},{energyOnUse=1,chemicalX=2}))
end)
test('Setup makes only base-positive cards free and does not alter X base costs',function()
 local s,all=fresh({'defend','skewer'});local plan=Cards.planChoice(s,'setup',all[1]);eq(plan[1].freeToPlayOnce,true)
 plan=Cards.planChoice(s,'setup',all[2]);eq(plan[1].freeToPlayOnce,false)
end)
test('Phantasmal constructor-one/raw-stack distinction and Tools postdraw order',function()
 local s=fresh({'defend'});s.player.statuses.phantasmal=3;s.player.statuses.tools_of_the_trade=2
 local plan=Cards.planHook(s,'phantasmal','turn_start_pre_draw');eq(plan[1].value,3);eq(plan[1].constructorAmount,1);eq(plan[2].op,'reduceFinalPower')
 plan=Cards.planHook(s,'tools_of_the_trade','turn_start_post_draw');eq(plan[1].op,'draw');eq(plan[1].value,2);eq(plan[2].op,'requestDiscard');eq(plan[2].value,2)
end)
test('Corpse death is null-owner THORNS for max HP times layers, no last-enemy fake explosion',function()
 local s=fresh({'defend'},1,true);local enemy=s.enemies[1];enemy.hp=0;enemy.maxHp=31;enemy.statuses.corpse_explosion=2
 local plan=Cards.planCorpseDeath(s,enemy);eq(plan[1].value,62);eq(plan[1].damageType,'THORNS');eq(plan[1].sourceNull,true)
 s.enemies[2].hp=0;eq(#Cards.planCorpseDeath(s,enemy),0)
end)
test('incomplete skill and potion pools never use subset or caller-provided completeness flags',function()
 local s=fresh({'defend'});s.completeSkillPool=true;s.completePotionPool=true
 for _,case in ipairs({{'distraction','unsupported_complete_skill_pool'},{'alchemize','unsupported_complete_potion_pool'}})do
  local ok,reason=Cards.canPlay(s,{id=case[1]});eq(ok,false);eq(reason,case[2])
  local called,err=pcall(Cards.prepareEffect,s,{op=case[1]});eq(called,false);eq(err,case[2])
 end
end)

test('damage adapters preserve zero, HP-loss clamp, NORMAL-only doubling and strict Power ids',function()
 local s=fresh({'defend'});s.player.statuses.intangible=0;s.player.statuses.double_damage=2
 eq(Cards.capIncomingDamage(s,s.player,0),0);eq(Cards.capIncomingDamage(s,s.player,7),1)
 eq(Cards.capIncomingDamage(s,s.enemies[1],7),7)
 eq(Cards.damageMultiplier(s,s.player,'NORMAL'),2);eq(Cards.damageMultiplier(s,s.player,'THORNS'),1);eq(Cards.damageMultiplier(s,s.player,'HP_LOSS'),1)
 assert(not pcall(Cards.planEffect,s,{op='gainSilentFinalPower',status='not_a_power',value=1}))
 assert(not pcall(Cards.planEffect,s,{op='gainSilentFinalPower',status='wraith_form',value=1}))
end)

for _,up in ipairs({false,true})do
 local suffix=' upgraded='..tostring(up)
 test('Endless Agony real draw creates one new identity without recursive draw copies'..suffix,function()
  local s,all=fresh({'defend',card('endless_agony',up)},1)
  local drawn=s.draw[#s.draw];local before={};local beforeTotal=0
  for _,name in ipairs({'hand','draw','discard','exhaust'})do for _,c in ipairs(s[name])do before[c.uid]=true;beforeTotal=beforeTotal+1 end end
  Combat.draw(s,1);local afterTotal=0;local created
  for _,name in ipairs({'hand','draw','discard','exhaust'})do for _,c in ipairs(s[name])do afterTotal=afterTotal+1;if not before[c.uid]then created=c end end end
  eq(afterTotal,beforeTotal+1);assert(created and created.sourceUid and drawn.sourceUid and created.sourceUid~=drawn.sourceUid,'stat-equivalent copy requires a new source identity')
  local copies={};for _,c in ipairs(s.hand)do if c.cardId=='endless_agony'then copies[#copies+1]=c end end
  eq(#copies,2);assert(copies[1].uid~=copies[2].uid);eq(copies[1].upgraded,up);eq(copies[2].upgraded,up)
  play(s,'endless_agony',1);eq(s.enemies[1].hp,300-(up and 6 or 4));eq(#s.exhaust,1)
 end)
 test('Masterful Stab actual HP loss increases cost once and normal play uses updated cost'..suffix,function()
  local s=fresh({card('masterful_stab',up)});Combat.applyEffects(s,{{op='loseHp',value=5}},s.player,s.player)
  eq(Combat.cardDefinition(s,s.hand[1]).cost,1);play(s,'masterful_stab',1);eq(s.energy,2);eq(s.enemies[1].hp,300-(up and 16 or 12))
 end)
 test('Setup one-card auto choice moves to top and next use is actually free'..suffix,function()
  local s,all=fresh({card('setup',up),'dash'});play(s,'setup');eq(#s.hand,0);eq(s.draw[#s.draw],all[2])
  Combat.draw(s,1);local energy=s.energy;play(s,'dash',1);eq(s.energy,energy);eq(all[2].freeToPlayOnce,false)
 end)
 test('Well Laid Plans has real up-to retention choice and retains chosen original card across turn'..suffix,function()
  local s,all=fresh({card('well_laid_plans',up),'defend','strike','slice'});play(s,'well_laid_plans')
  eq(s.player.statuses.well_laid_plans,up and 2 or 1);assert(Combat.endTurn(s));assert(s.pendingRetainChoice,'real retain selection required')
  assert(type(Combat.chooseRetain)=='function','shared retain command required')
  assert(Combat.chooseRetain(s,{all[2].uid},s.pendingRetainChoice.token));eq(s.phase,'player')
  local found=false;for _,c in ipairs(s.hand)do if c==all[2]then found=true end end;assert(found)
 end)
 test('Bullet Time real NoDraw and current-hand zero costs preserve X/unplayable'..suffix,function()
  local s,all=fresh({card('bullet_time',up),'dash','skewer','reflex'});play(s,'bullet_time')
  eq(s.player.noDraw,true);eq(Combat.cardDefinition(s,all[2]).cost,0);eq(Combat.cardDefinition(s,all[3]).cost,-1);eq(Combat.cardDefinition(s,all[4]).cost,-2)
  eq(s.energy,up and 1 or 0)
 end)
 test('Burst uses actual auto-card command, one charge and doubled Block'..suffix,function()
  local s=fresh({card('burst',up),'defend'});play(s,'burst');play(s,'defend')
  eq(s.player.block,10);eq(s.energy,1);eq(s.player.statuses.burst or 0,up and 1 or 0)
  eq(#s.discard,2,'purged automatic copy must not become a third physical discard')
  eq(#s.cardsPlayedThisTurn,3,'automatic play remains a real card-use event')
 end)
 test('Corpse Explosion independent Artifact and true death THORNS chain'..suffix,function()
  local s=fresh({card('corpse_explosion',up)},1,true);s.enemies[1].statuses.artifact=1
  play(s,'corpse_explosion',1);eq(s.enemies[1].statuses.poison or 0,0);eq(s.enemies[1].statuses.corpse_explosion,1)
  s.enemies[1].hp=1;Combat.damage(s,s.player,s.enemies[1],1,true)
  eq(s.enemies[2].hp,0,'max HP=300 explosion must hit remaining target')
 end)
 test('Doppelganger actual X payment, next energy and extra draw exactly once'..suffix,function()
  local ids={card('doppelganger',up)};for _=1,13 do ids[#ids+1]='defend'end
  local s=fresh(ids,1);play(s,'doppelganger');eq(s.energy,0);eq(s.player.statuses.draw_next_turn,up and 4 or 3)
  assert(Combat.endTurn(s));eq(s.energy,up and 7 or 6);eq(#s.hand,up and 9 or 8);eq(s.player.statuses.draw_next_turn,nil)
 end)
 test('Nightmare one-card choice freezes stat copy and creates three pre-draw next turn'..suffix,function()
  local s,all=fresh({card('nightmare',up),card('slice',true)});play(s,'nightmare');eq(s.player.statuses.nightmare,3)
  eq(#s.hand,1);assert(Combat.endTurn(s))
  local n=0;local uids={};for _,c in ipairs(s.hand)do if c.cardId=='slice'then n=n+1;assert(c.upgraded);assert(not uids[c.uid]);uids[c.uid]=true end end
  eq(n,4);eq(s.player.statuses.nightmare,nil);eq(s.nightmareTemplate,nil)
 end)
 test('Phantasmal Killer applies only next turn NORMAL x2 and lasts one round'..suffix,function()
  local s=fresh({card('phantasmal_killer',up),'slice','slice'});play(s,'phantasmal_killer');play(s,'slice',1);eq(s.enemies[1].hp,294)
  assert(Combat.endTurn(s));play(s,'slice',1);eq(s.enemies[1].hp,282);eq(s.player.statuses.double_damage,1)
  assert(Combat.endTurn(s));eq(s.player.statuses.double_damage,nil)
 end)
 test('Tools of the Trade postdraw creates genuine discard selection before any other command'..suffix,function()
  local ids={card('tools_of_the_trade',up)};for _=1,12 do ids[#ids+1]='defend'end
  local s=fresh(ids,1);play(s,'tools_of_the_trade');eq(s.player.statuses.tools_of_the_trade,1)
  assert(Combat.endTurn(s));assert(s.pendingDiscard);eq(#s.hand,6)
  assert(Combat.chooseDiscard(s,{s.hand[1].uid},s.pendingDiscard.token));eq(#s.hand,5);eq(s.pendingDiscard,nil);eq(s.actionQueue,nil)
 end)
 test('Wraith Form Artifact can block dex-loss Power after Intangible has already applied'..suffix,function()
  local s=fresh({card('wraith_form',up)});s.player.statuses.artifact=1;play(s,'wraith_form')
  eq(s.player.statuses.intangible,up and 3 or 2);eq(s.player.statuses.wraith_form,nil);eq(s.player.statuses.artifact or 0,0)
  local hp=s.player.hp;Combat.applyEffects(s,{{op='loseHp',value=7}},s.player,s.player);eq(s.player.hp,hp-1,'Intangible includes HP_LOSS')
 end)
end

test('Wraith Form NORMAL before Block, THORNS and HP_LOSS all clamp independently',function()
 local s=fresh({'wraith_form'});play(s,'wraith_form');s.player.block=5;local hp=s.player.hp
 Combat.damage(s,s.enemies[1],s.player,12);eq(s.player.hp,hp);eq(s.player.block,4)
 Actors.retaliate(s,s.enemies[1],s.player,9);eq(s.player.hp,hp);eq(s.player.block,3)
 Combat.applyEffects(s,{{op='loseHp',value=9}},s.player,s.player);eq(s.player.hp,hp-1);eq(s.player.block,3)
end)
test('Wraith debuff drains Dex this turn and Artifact may block each later negative Dex application',function()
 local s=fresh({'wraith_form'});play(s,'wraith_form');eq(s.player.statuses.wraith_form,-1)
 s.player.statuses.artifact=1;assert(Combat.endTurn(s));eq(s.player.statuses.dexterity or 0,0);eq(s.player.statuses.artifact or 0,0)
 assert(Combat.endTurn(s));eq(s.player.statuses.dexterity,-1)
end)
test('full random pools are rejected through real canPlay without spending energy or cards',function()
 for _,id in ipairs({'distraction','alchemize'})do
  local s,all=fresh({id});local events=#s.events;local ok,reason=Combat.canPlay(s,all[1].uid)
  eq(ok,false);eq(reason,id=='distraction'and'unsupported_complete_skill_pool'or'unsupported_complete_potion_pool')
  eq(s.energy,3);eq(#s.hand,1);eq(#s.events,events)
 end
end)
print('SILENT_FINAL_BUILD_RESULT '..(count-failed)..'/'..count)
assert(failed==0,'Silent final shared integration incomplete: '..failed..' cases')
print('SILENT_FINAL_BUILD_PASS '..count)
