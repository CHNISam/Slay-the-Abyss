package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local B=require('abyss_block_triggers')
local C=require('abyss_combat')
local A=require('abyss_actor')
local Q=require('abyss_action_queue')
local Schedule=require('abyss_power_schedule')
local Flow=require('abyss_flow_actions')
local R=require('abyss_sts_random')
local Snapshot=require('abyss_snapshot')
local n=0
local function eq(a,b) assert(a==b,tostring(a)..' ~= '..tostring(b)) end
local function test(name,fn) fn();n=n+1;print('ok block triggers '..n..' - '..name) end
local function battle(count)
 local enemies={};for _=1,count or 1 do enemies[#enemies+1]='cultist' end
 local s=C.new(require('abyss_data'),{seed=42,deck={},enemies=enemies,cardRandomSeed='42'})
 for _,d in ipairs(B.definitions()) do s.catalog.statuses[d.id]=d end
 for _,e in ipairs(s.enemies) do e.hp=200;e.maxHp=200 end
 return s
end
local function applied(s,id,amount)
 local before=rawget(s.player.statuses,id)
 assert(A.applyPower(s,s.player,id,amount,s.player))
 local recorded=false
 for _,entry in ipairs(s.player.powerScheduleOrder or {}) do if entry.id==id then recorded=true end end
 -- Independent host-contract fixture: current Core may not yet record these
 -- two Power IDs. Reuse its real membership registry, never invent ordering.
 if not recorded then Schedule.recordApplied(s,s.player,id,before) end
end
local function enemy(s,id) for _,e in ipairs(s.enemies) do if e.id==id then return e end end end
local function freeze(root)
 local saved,pending={}, {root}
 while #pending>0 do
  local t=table.remove(pending)
  if not saved[t] then
   local values={};saved[t]=values
   for k,v in pairs(t) do values[k]=v;if type(v)=='table' then pending[#pending+1]=v end end
  end
 end
 return function()
  for t,values in pairs(saved) do
   for k,v in pairs(values) do eq(t[k],v) end
   for k,v in pairs(t) do eq(values[k],v) end
  end
 end
end
-- This is a component host for the NEW typed plans. Damage/status arithmetic
-- is real Combat/Actor; it does not replace their rules or claim Actor wiring.
local function handlers(trace,fail)
 return {allow=function(s,a)
  if s.player.hp<=0 then return false end
  if C.outcome(s)=='victory' then return a.effect.op=='blockTriggerDamage' or a.effect.op=='blockTriggerRandomDamage' end
  return true
 end,effect=function(s,a,queue)
  local e=a.effect;trace[#trace+1]=e.op
  if e.op=='blockTriggerRandomDamage' then Flow.enqueue(s,B.planRandomDamage(s,e),queue)
  elseif e.op=='blockTriggerWeak' then Flow.enqueue(s,B.planWeak(s,e),queue)
  elseif e.op=='blockTriggerDamage' then
   eq(e.damageType,'THORNS');local target=enemy(s,e.targetId)
   if target and target.hp>0 then C.damage(s,s.player,target,e.value,true) end
  elseif e.op=='applyStatus' then
   local target=enemy(s,e.targetId);if target and target.hp>0 then A.applyPower(s,target,e.status,e.value,s.player,false) end
  elseif e.op=='blockTriggerRemoveWave' then
   Schedule.remove(s,s.player,e.status);s.player.statuses[e.status]=nil
  elseif e.op=='energy' then C.applyEffects(s,{e},s.player,s.player)
  else error('unknown test-host operation '..e.op) end
  if fail and e.op=='applyStatus' then error('block-trigger fault after real Weak application') end
  return true
 end}
end
test('positive fractional Block input plans both Powers before floor without changing state',function()
 local s=battle();applied(s,'juggernaut',5);applied(s,'wave_of_the_hand',1)
 local unchanged=freeze(s);local p=B.plan(s,s.player,0.25);unchanged()
 eq(#p.top,0);eq(#p.bottom,2);eq(p.bottom[1].effect.op,'blockTriggerRandomDamage')
 eq(p.bottom[2].effect.op,'blockTriggerWeak');eq(s.enemies[1].hp,200);eq(s.cardRandomRng.counter,0)
end)
test('positive input still plans at 999 Block even when actual floored/capped delta would be zero',function()
 local s=battle();applied(s,'juggernaut',5);s.player.block=999
 eq(#B.plan(s,s.player,5).bottom,1);eq(#B.plan(s,s.player,0.5).bottom,1);eq(s.player.block,999)
end)
test('zero negative and other-owner Block do not trigger while invalid floats reject without writes',function()
 local s=battle();applied(s,'juggernaut',5)
 eq(#B.plan(s,s.player,0).bottom,0);eq(#B.plan(s,s.player,-2).bottom,0)
 eq(#B.plan(s,s.enemies[1],5).bottom,0)
 for _,value in ipairs({0/0,math.huge,-math.huge,'5'}) do
  local unchanged=freeze(s);eq(pcall(B.plan,s,s.player,value),false);unchanged()
 end
end)
for _,first in ipairs({'juggernaut','wave_of_the_hand'}) do
 test('BOTTOM plans preserve source acquisition order with '..first..' first',function()
  local s=battle(2);applied(s,first,first=='juggernaut' and 5 or 2)
  applied(s,first=='juggernaut' and 'wave_of_the_hand' or 'juggernaut',first=='juggernaut' and 2 or 5)
  local p=B.plan(s,s.player,1);eq(#p.bottom,3)
  local j=first=='juggernaut' and 1 or 3;eq(p.bottom[j].effect.op,'blockTriggerRandomDamage')
  local w=first=='juggernaut' and 2 or 1
  eq(p.bottom[w].effect.targetId,s.enemies[1].id);eq(p.bottom[w+1].effect.targetId,s.enemies[2].id)
  Q.start(s,p.bottom) -- Existing pure-data queue accepts the entire plan.
 end)
end
test('stacking retains the original Power slot and both source priorities remain five',function()
 local s=battle();applied(s,'juggernaut',5);applied(s,'wave_of_the_hand',1);applied(s,'juggernaut',7)
 local p=B.plan(s,s.player,1);eq(p.bottom[1].effect.value,12);eq(p.bottom[2].effect.value,1)
 eq(#s.player.powerScheduleOrder,2)
 for _,entry in ipairs(s.player.powerScheduleOrder) do eq(entry.priority,5) end
end)
test('two unrecorded Power slots are refused instead of guessing an alphabetical order',function()
 local s=battle();A.addStatus(s.player,'juggernaut',5);A.addStatus(s.player,'wave_of_the_hand',1)
 local unchanged=freeze(s);eq(pcall(B.plan,s,s.player,1),false);unchanged()
end)
test('Juggernaut no-current-target execution produces no RNG call including when its stream is absent',function()
 local s=battle();applied(s,'juggernaut',5);local e=B.plan(s,s.player,1).bottom[1].effect
 s.enemies[1].hp=0;eq(#B.planRandomDamage(s,e).top,0);eq(s.cardRandomRng.counter,0)
 s.cardRandomRng=nil;eq(#B.planRandomDamage(s,e).top,0)
end)
test('Juggernaut target selection is late and ignores halfDead dying and escaping actors',function()
 local s=battle(4);applied(s,'juggernaut',5);local e=B.plan(s,s.player,1).bottom[1].effect
 s.enemies[1].halfDead=true;s.enemies[2].isDying=true;s.enemies[3].isEscaping=true
 local p=B.planRandomDamage(s,e);eq(p.top[1].effect.targetId,s.enemies[4].id)
 eq(p.top[1].effect.damageType,'THORNS');eq(p.top[1].effect.value,5)
 eq(R.snapshot(p.cardRandomRng).counter,1);eq(s.cardRandomRng.counter,0)
end)
test('single live target still consumes random(0) only when the host commits execution RNG',function()
 local s=battle();applied(s,'juggernaut',5);local e=B.plan(s,s.player,1).bottom[1].effect
 local original,primitive=s.cardRandomRng,s.cardRandomRng.primitive
 local p=B.planRandomDamage(s,e);eq(s.cardRandomRng.counter,0);Flow.commitRng(s,p.cardRandomRng)
 eq(s.cardRandomRng,original);eq(original.primitive,primitive);eq(original.counter,1)
 local nextPlan=B.planRandomDamage(s,e);eq(R.snapshot(nextPlan.cardRandomRng).counter,2)
end)
test('queued Juggernaut uses fixed THORNS through Block without NORMAL modifiers or recursive Thorns',function()
 local s=battle();applied(s,'juggernaut',5)
 s.player.statuses.strength=100;s.player.statuses.weak=1
 s.enemies[1].statuses.vulnerable=1;s.enemies[1].statuses.thorns=10;s.enemies[1].block=2
 Q.start(s,B.plan(s,s.player,1).bottom);local trace={};assert(Q.run(s,handlers(trace)))
 eq(s.enemies[1].hp,197);eq(s.enemies[1].block,0);eq(s.player.hp,s.player.maxHp)
 eq(table.concat(trace,','),'blockTriggerRandomDamage,blockTriggerDamage');eq(s.cardRandomRng.counter,1)
end)
test('Wave captures original target IDs and does not weaken a later spawned enemy',function()
 local s=battle(2);applied(s,'wave_of_the_hand',2)
 local p=B.plan(s,s.player,1);eq(#p.bottom,2);s.enemies[1].hp=0
 local spawned=C.copy(s.enemies[2]);spawned.id='spawned_after_block';s.enemies[#s.enemies+1]=spawned
 Q.start(s,p.bottom);assert(Q.run(s,handlers({})))
 eq(s.enemies[1].statuses.weak,nil);eq(s.enemies[2].statuses.weak,2);eq(spawned.statuses.weak,nil)
 eq(s.cardRandomRng.counter,0)
end)
for _,first in ipairs({'juggernaut','wave_of_the_hand'}) do
 test('source order controls Artifact consumption before a final kill with '..first..' first',function()
  local s=battle();s.enemies[1].hp=1;s.enemies[1].statuses.artifact=1
  applied(s,first,first=='juggernaut' and 5 or 1)
  applied(s,first=='juggernaut' and 'wave_of_the_hand' or 'juggernaut',first=='juggernaut' and 1 or 5)
  Q.start(s,B.plan(s,s.player,1).bottom);assert(Q.run(s,handlers({})))
  eq(s.enemies[1].hp,0);eq(s.enemies[1].statuses.artifact,first=='juggernaut' and 1 or 0)
  eq(s.cardRandomRng.counter,1)
 end)
end
test('an existing action remains before new BOTTOM block triggers',function()
 local s=battle();applied(s,'juggernaut',5);local trace={};local energy=s.energy
 Q.start(s,{{kind='effect',effect={op='energy',value=1}}})
 Flow.enqueue(s,B.plan(s,s.player,0.5),Q);eq(s.enemies[1].hp,200);assert(Q.run(s,handlers(trace)))
 eq(trace[1],'energy');eq(trace[2],'blockTriggerRandomDamage');eq(s.energy,energy+1);eq(s.enemies[1].hp,195)
end)
test('victory defeat and dead-player plans cancel without touching RNG',function()
 local s=battle();applied(s,'juggernaut',5);applied(s,'wave_of_the_hand',1)
 local p=B.plan(s,s.player,1);local random,weak=p.bottom[1].effect,p.bottom[2].effect
 for _,phase in ipairs({'victory','defeat'}) do
  s.phase=phase;eq(#B.plan(s,s.player,1).bottom,0);eq(#B.planRandomDamage(s,random).top,0);eq(#B.planWeak(s,weak).top,0)
 end
 s.phase='player';s.player.hp=0;eq(#B.plan(s,s.player,1).bottom,0);eq(s.cardRandomRng.counter,0)
end)
test('Wave end-of-round removal updates real membership history while Juggernaut persists',function()
 local s=battle();applied(s,'juggernaut',5);applied(s,'wave_of_the_hand',1)
 Q.start(s,B.planEndRound(s,s.player).bottom);assert(Q.run(s,handlers({})))
 eq(s.player.statuses.wave_of_the_hand,nil);eq(s.player.statuses.juggernaut,5)
 local p=B.plan(s,s.player,1);eq(#p.bottom,1);eq(p.bottom[1].effect.op,'blockTriggerRandomDamage')
 eq(#s.player.powerScheduleOrder,1)
end)
test('failed real damage and Weak execution restore original graph and RNG references before retry',function()
 local s=battle();applied(s,'juggernaut',5);applied(s,'wave_of_the_hand',1)
 Q.start(s,B.plan(s,s.player,1).bottom)
 local q,actions,rng,primitive,statuses,events=s.actionQueue,s.actionQueue.actions,s.cardRandomRng,s.cardRandomRng.primitive,s.enemies[1].statuses,s.events
 local unchanged=freeze(s);local restore=Snapshot.capture(s)
 local ok,why=pcall(Q.run,s,handlers({},true));eq(ok,false);assert(tostring(why):find('after real Weak application',1,true))
 eq(s.enemies[1].hp,195);eq(s.enemies[1].statuses.weak,1);eq(rng.counter,1)
 restore();unchanged();eq(s.actionQueue,q);eq(q.actions,actions);eq(q.current,nil)
 eq(s.cardRandomRng,rng);eq(rng.primitive,primitive);eq(s.enemies[1].statuses,statuses);eq(s.events,events)
 eq(s.enemies[1].hp,200);eq(rng.counter,0)
 assert(Q.run(s,handlers({})));eq(s.enemies[1].hp,195);eq(s.enemies[1].statuses.weak,1);eq(rng.counter,1)
end)
print('BLOCK_TRIGGERS_PASS'..n)
