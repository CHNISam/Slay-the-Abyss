package.path="src/lua/?.lua;build/lua/?.lua;"..package.path
local Auto=require("abyss_autoplay_queue")
local Combat=require("abyss_combat")
local Queue=require("abyss_action_queue")
local Data=require("abyss_data")
local n,generation=0,41
local function eq(a,b)assert(a==b,tostring(a).." ~= "..tostring(b))end
local function test(name,fn)fn();n=n+1;print("ok autoplay_queue "..n.." - "..name)end
local function setup(deck)return Combat.new(Data,{seed=42,cardRandomSeed="42",enemies={"cultist"},deck=deck or {"strike","defend","bash"}})end
local function options(extra)
    local out={generation=generation,energyOnUse=3,targetId="cultist"}
    for k,v in pairs(extra or {})do out[k]=v end;return out
end
local function freeze(value)
    local saved,waiting={}, {value}
    while #waiting>0 do local t=table.remove(waiting)
        if not saved[t]then local entries={};saved[t]=entries
            for k,v in pairs(t)do entries[k]=v;if type(v)=="table"then waiting[#waiting+1]=v end end
        end
    end
    return function()for t,entries in pairs(saved)do
        for k,v in pairs(entries)do eq(t[k],v)end;for k,v in pairs(t)do eq(entries[k],v)end
    end end
end
local function copy(value)if type(value)~="table"then return value end;local out={};for k,v in pairs(value)do out[k]=copy(v)end;return out end
local function plain(value,path)
    if type(value)=="table"then path=path or {};assert(not path[value] and not getmetatable(value));path[value]=true
        for k,v in pairs(value)do assert(type(k)=="string" or type(k)=="number");plain(v,path)end;path[value]=nil
    else assert(type(value)=="number" or type(value)=="string" or type(value)=="boolean")end
end
test("empty queue peeks and pops without creating saved state",function()
    local s=setup();local same=freeze(s);eq(Auto.peek(s,generation),nil);eq(Auto.pop(s,generation),nil);eq(Auto.active(s),false);same()
end)
test("enqueue references a real owned instance without moving it or spending energy",function()
    local s=setup();local card=s.hand[1];local hand=s.hand;local rng=freeze(s.cardRandomRng);local nextUid=s.nextUid
    assert(Auto.enqueue(s,card,options()));local item,original=Auto.peek(s,generation)
    eq(original,card);eq(s.hand,hand);eq(s.hand[1],card);eq(item.uid,card.uid);eq(item.sourceUid,card.uid)
    eq(item.energyOnUse,3);eq(item.autoplayCard,true);eq(s.energy,3);eq(s.nextUid,nextUid);rng()
end)
test("queue snapshots flags target and energy independently of later source flag mutations",function()
    local s=setup();local card=s.hand[1];card.freeToPlayOnce=true;card.exhaustOnUseOnce=true
    assert(Auto.enqueue(s,card,options({energyOnUse=1,purgeOnUse=true,ignoreEnergyTotal=true})))
    card.freeToPlayOnce=false;card.exhaustOnUseOnce=false;s.energy=0
    local item=Auto.peek(s,generation);eq(item.freeToPlayOnce,true);eq(item.exhaustOnUseOnce,true)
    eq(item.purgeOnUse,true);eq(item.ignoreEnergyTotal,true);eq(item.energyOnUse,1);eq(item.targetId,"cultist")
end)
test("peek returns a detached entry and the exact original card",function()
    local s=setup();local card=s.hand[1];assert(Auto.enqueue(s,card,options()))
    local a,original=Auto.peek(s,generation);a.uid=999;a.targetId="foreign"
    local b=Auto.peek(s,generation);eq(b.uid,card.uid);eq(b.targetId,"cultist");eq(original,card)
end)
test("ordinary appends are FIFO and waiting-only immediate entries stack LIFO",function()
    local s=setup();local a,b,c=s.hand[1],s.hand[2],s.hand[3]
    assert(Auto.enqueue(s,a,options()));assert(Auto.enqueue(s,b,options({immediate=true})));assert(Auto.enqueue(s,c,options({immediate=true})))
    eq(select(2,Auto.pop(s,generation)),c);eq(select(2,Auto.pop(s,generation)),b);eq(select(2,Auto.pop(s,generation)),a)
    eq(s.pendingAutoPlays,nil)
end)
test("an already queued combat UID refuses atomically while same source UID clones can coexist",function()
    local s=setup();local card=s.hand[1];assert(Auto.enqueue(s,card,options()))
    local same=freeze(s);eq(Auto.enqueue(s,card,options()),false);same()
    local clone=assert(Auto.clone(s,card,generation));assert(Auto.enqueue(s,clone,options()))
    eq(s.pendingAutoPlays[1].sourceUid,s.pendingAutoPlays[2].sourceUid);assert(card.uid~=clone.uid)
end)
test("action queue fully drains before queued card can be claimed",function()
    local s=setup();local card=s.hand[1];assert(Auto.enqueue(s,card,options()))
    Queue.start(s,{{kind="effect",effect={op="block",value=2}},{kind="effect",effect={op="block",value=4}}})
    local item,reason=Auto.pop(s,generation);eq(item,nil);eq(reason,"actions_pending")
    assert(Queue.run(s,{effect=function(current,a)
        eq(Auto.peek(current,generation),nil)
        Combat.applyEffects(current,{a.effect},current.player,current.enemies[1]);return true
    end}))
    eq(s.player.block,6);eq(select(2,Auto.pop(s,generation)),card)
end)
test("paused action current blocks cards until a genuine Queue resume completes",function()
    local s=setup();assert(Auto.enqueue(s,s.hand[1],options()))
    Queue.start(s,{{kind="effect",effect={op="block",value=1}},{kind="effect",effect={op="block",value=2}}})
    eq(Queue.run(s,{effect=function()return "pause"end}),"pause")
    eq(Auto.pop(s,generation),nil)
    assert(Queue.resume(s,{effect=function(current,a)Combat.applyEffects(current,{a.effect},current.player,current.enemies[1]);return true end}))
    eq(s.player.block,2);assert(Auto.pop(s,generation))
end)
test("pre-turn actions and each choice or current-card marker block claiming",function()
    for _,field in ipairs({"preTurnActions","pendingDiscard","pendingScry","pendingHandChoice","pendingPileChoice","pendingPlay"})do
        local s=setup();assert(Auto.enqueue(s,s.hand[1],options()));s[field]={{fact=true}}
        local same=freeze(s);eq(Auto.pop(s,generation),nil);same();s[field]=nil;assert(Auto.pop(s,generation))
    end
    local s=setup();local card=table.remove(s.hand);s.cardInUse=card;assert(Auto.enqueue(s,card,options()))
    eq(Auto.pop(s,generation),nil);s.cardInUse=nil;s.limbo={card};assert(Auto.pop(s,generation))
end)
test("wrong exact generation cannot peek pop enqueue clone or drop and never auto-discards records",function()
    local s=setup();assert(Auto.enqueue(s,s.hand[1],options()));local same=freeze(s)
    eq(Auto.peek(s,generation+1),nil);eq(Auto.pop(s,generation+1),nil)
    eq(Auto.enqueue(s,s.hand[2],options({generation=generation+1})),false)
    eq(Auto.clone(s,s.hand[2],generation+1),false);eq(Auto.drop(s,generation+1,"combat_reset"),false);same()
end)
test("allocator consumes one unique combat UID without touching source identity or RNG",function()
    local s=setup();local nextUid=s.nextUid;local rng=freeze(s.cardRandomRng)
    eq(Auto.allocateUid(s),nextUid);eq(s.nextUid,nextUid+1);rng()
end)
test("allocator does not skip a collision in any pile limbo or using card",function()
    for _,place in ipairs({"hand","draw","discard","exhaust","limbo","using"})do
        local s=setup();local card=table.remove(s.hand);s.nextUid=card.uid
        if place=="using"then s.cardInUse=card else s[place]=s[place]or {};s[place][#s[place]+1]=card end
        local same=freeze(s);eq(pcall(Auto.allocateUid,s),false);same()
    end
end)
test("duplicate UID or duplicate ownership refuses before queue mutation",function()
    local s=setup();s.limbo={s.hand[1]};local same=freeze(s)
    eq(pcall(Auto.enqueue,s,s.hand[2],options()),false);same()
end)
test("clone keeps source UUID lineage but allocates a unique combat UID in limbo",function()
    local s=setup();local card=s.hand[1];card.sourceUUID="java-source-uuid";card.upgraded=true
    local uid=s.nextUid;local originalHand=s.hand;local clone=assert(Auto.clone(s,card,generation))
    eq(clone.uid,uid);eq(clone.sourceUid,"java-source-uuid");eq(clone.sourceUUID,nil);eq(clone.upgraded,true)
    eq(clone.cardId,card.cardId);eq(s.limbo[1],clone);eq(s.hand,originalHand);eq(s.hand[1],card);eq(s.nextUid,uid+1)
end)
test("stat-equivalent clone preserves supported base-stat adapters but resets transient flags",function()
    local s=setup();local source=s.hand[1]
    for _,field in ipairs({"combatCost","turnCost","damageBonus","storedDiscardCost","retainedDamageBonus","shivAccuracyBonus"})do source[field]=2 end
    source.freeToPlayOnce=true;source.retain=true;source.retainedTurn=7;source.exhaustOnUseOnce=true
    source.dontTriggerOnUseCard=true;source.energyOnUse=9;source.isInAutoplay=true
    local clone=assert(Auto.clone(s,source,generation))
    for _,field in ipairs({"combatCost","turnCost","damageBonus","storedDiscardCost","retainedDamageBonus","shivAccuracyBonus"})do eq(clone[field],2)end
    eq(clone.freeToPlayOnce,true);eq(clone.purgeOnUse,true)
    for _,field in ipairs({"retain","retainedTurn","exhaustOnUseOnce","dontTriggerOnUseCard","energyOnUse","isInAutoplay"})do eq(clone[field],nil)end
end)
test("a repeat clone cannot clone itself again so purge prevents recursive repetition",function()
    local s=setup();local clone=assert(Auto.clone(s,s.hand[1],generation));local same=freeze(s)
    eq(Auto.clone(s,clone,generation),false);same()
end)
test("unknown stat-copy fields or nextUid overflow reject before allocation or limbo creation",function()
    for _,bad in ipairs({"futureStat","badUid"})do
        local s=setup();if bad=="futureStat"then s.hand[1].futureStat=4 else s.nextUid=2147483647 end
        local same=freeze(s);eq(pcall(Auto.clone,s,s.hand[1],generation),false);same()
    end
end)
test("function metatable cyclic and malformed snapshot options are rejected without changes",function()
    local cyclic={};cyclic.self=cyclic
    for _,bad in ipairs({options({callback=function()end}),setmetatable(options(),{}),options({future=cyclic}),
        options({generation=-1}),options({energyOnUse=0/0}),options({targetId={}}),options({freeToPlayOnce=1})})do
        local s=setup();local same=freeze(s);eq(pcall(Auto.enqueue,s,s.hand[1],bad),false);same()
    end
end)
test("missing original foreign clone and disappearing queued ownership never silently succeed",function()
    local s=setup();local same=freeze(s);eq(pcall(Auto.enqueue,s,copy(s.hand[1]),options()),false);same()
    assert(Auto.enqueue(s,s.hand[1],options()));table.remove(s.hand,1);local changed=freeze(s)
    eq(pcall(Auto.peek,s,generation),false);changed()
end)
test("malformed instance flags costs or source identities fail before assigning queue or UID",function()
    for _,bad in ipairs({{key="freeToPlayOnce",value=1},{key="combatCost",value={}},
        {key="damageBonus",value=-1},{key="sourceUid",value=""},{key="sourceUUID",value=false}})do
        local s=setup();s.hand[1][bad.key]=bad.value;local same=freeze(s)
        eq(pcall(Auto.enqueue,s,s.hand[1],options()),false);eq(pcall(Auto.clone,s,s.hand[1],generation),false);same()
    end
end)
test("serialized queue restores independent instances and entirely plain data",function()
    local s=setup();local clone=assert(Auto.clone(s,s.hand[1],generation));assert(Auto.enqueue(s,clone,options()))
    plain(s.pendingAutoPlays);plain(s.limbo);local restored=copy(s)
    local item,original=Auto.pop(restored,generation);eq(original,restored.limbo[1]);assert(original~=clone)
    eq(item.sourceUid,s.hand[1].uid);eq(#s.pendingAutoPlays,1);eq(restored.pendingAutoPlays,nil)
end)
test("generation-reset drop removes queue records only and keeps original instances untouched",function()
    local s=setup();local original=s.hand[1];assert(Auto.enqueue(s,original,options()))
    local dropped=Auto.drop(s,generation,"combat_reset");eq(#dropped,1);eq(dropped[1].uid,original.uid)
    eq(dropped[1].needsUseCardCleanup,false);eq(s.pendingAutoPlays,nil);eq(s.hand[1],original);eq(#s.exhaust,0)
end)
test("early-turn drop exposes cleanup obligations instead of silently exhausting or purging",function()
    local s=setup();local a,b=s.hand[1],s.hand[2]
    assert(Auto.enqueue(s,a,options()));assert(Auto.enqueue(s,b,options({autoplayCard=false})))
    local dropped=Auto.drop(s,generation,"end_turn_early")
    eq(dropped[1].needsUseCardCleanup,true);eq(dropped[2].needsUseCardCleanup,false)
    eq(a.dontTriggerOnUseCard,nil);eq(#s.exhaust,0);eq(#s.hand,3)
end)
test("cannot-use target-dead and ordinary status are not accepted as silent drop reasons",function()
    for _,reason in ipairs({"cannot_use","target_dead","insufficient_energy"})do
        local s=setup();assert(Auto.enqueue(s,s.hand[1],options()));local same=freeze(s)
        eq(pcall(Auto.drop,s,generation,reason),false);same()
    end
end)
test("dead target does not retarget or consume RNG at the pure queue layer",function()
    local s=setup();assert(Auto.enqueue(s,s.hand[1],options({randomTarget=true})));s.enemies[1].hp=0
    local rng=freeze(s.cardRandomRng);local item,card=Auto.pop(s,generation)
    eq(item.targetId,"cultist");eq(item.randomTarget,true);eq(card,s.hand[1]);rng()
end)
print("AUTOPLAY_QUEUE_COMPONENT_PASS "..n)
print("AUTOPLAY_CORE_NOT_CONNECTED: component checks do not execute an automatic card")
