package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local C=require('abyss_combat')
local R=require('abyss_sts_random')
local Q=require('abyss_action_queue')
local F=require('abyss_warrior_final_cards')
local W=require('abyss_warrior_cards')
local E=require('abyss_warrior_exhaust_cards')
local S=require('abyss_warrior_strength_cards')
local T=require('abyss_warrior_status_cards')
local base=T.withCards(S.withCards(E.withCards(W.withFoundationCards(require('abyss_data')))))
local data=F.withCards(base)
local n=0
local function eq(a,b) assert(a==b,tostring(a)..' ~= '..tostring(b)) end
local function test(name,fn) fn();n=n+1;print('ok warrior final '..n..' - '..name) end
local function inst(id,up) return {cardId=id,upgraded=up} end
local function held(s,id) for _,c in ipairs(s.hand) do if c.cardId==id then return c end end;error('missing '..id) end
local function play(s,id,target) local ok,why=C.play(s,held(s,id).uid,target);assert(ok,why) end
local function battle(deck,enemies)
 local s=C.new(data,{seed=42,deck=deck or {},enemies=enemies or {'cultist'},cardRandomSeed='42'})
 for _,e in ipairs(s.enemies) do e.hp=200;e.maxHp=200 end;return s
end
local function arrange(s,ids)
 local all={};for _,p in ipairs({s.hand,s.draw,s.discard,s.exhaust}) do for _,c in ipairs(p) do all[#all+1]=c end end
 s.hand={};s.draw={};s.discard={};s.exhaust={}
 for _,id in ipairs(ids) do
  local found;for i,c in ipairs(all) do if c.cardId==id then found=table.remove(all,i);break end end
  s.hand[#s.hand+1]=assert(found)
 end
 for _,c in ipairs(all) do s.draw[#s.draw+1]=c end
end
local function detach(s,id)
 local c=held(s,id);for i,v in ipairs(s.hand) do if v==c then table.remove(s.hand,i);break end end;s.cardInUse=c;return c
end
local function raw(s,c)
 local d=C.copy(s.catalog.cards[c.cardId]);if c.upgraded then for k,v in pairs(d.upgrade or {}) do d[k]=C.copy(v) end end;return d
end
test('final helper independently appends exactly nine cards and two Powers',function()
 eq(#data.cards.cards,#base.cards.cards+9);eq(#data.statuses.statuses,#base.statuses.statuses+2)
 eq(base.experimentalWarriorFinal,nil);eq(pcall(F.withCards,data),false)
 for _,id in ipairs({'armaments','havoc','sword_boomerang','dual_wield','infernal_blade','searing_blow','double_tap','feed','juggernaut'}) do
  local count=0;for _,c in ipairs(data.cards.cards) do if c.id==id then count=count+1;eq(c.color,'red');eq(c.experimental,true) end end;eq(count,1)
 end
end)
test('Searing Blow component preserves repeated upgrade count and the increasing damage sequence',function()
 local s=battle({'searing_blow'});local c=held(s,'searing_blow')
 for i,damage in ipairs({12,16,21,27,34,42}) do
  local count=i-1;c.upgraded=count>0;c.timesUpgraded=count
  eq(F.adaptDefinition(s,c,raw(s,c)).effects[1].value,damage);assert(F.canUpgrade(s,c))
 end
 local permanent={cardId='searing_blow',upgraded=true,timesUpgraded=3};local combat=C.copy(permanent)
 assert(F.upgradeInstance(s,combat));eq(combat.timesUpgraded,4);eq(permanent.timesUpgraded,3)
 eq(pcall(F.upgradeCount,{timesUpgraded=-1}),false)
 eq(pcall(F.upgradeCount,{timesUpgraded=3,upgraded=false}),false)
end)
test('Armaments component auto-upgrades the only eligible card and includes upgraded Searing Blow in all mode',function()
 local s=battle({'armaments','strike',inst('defend',true),'dazed'});detach(s,'armaments')
 local p=F.planEffect(s,{op='armaments',all=false});eq(#p.top,1);eq(p.top[1].effect.uid,held(s,'strike').uid)
 assert(F.upgradeInstance(s,held(s,'strike')));eq(held(s,'strike').upgraded,true);eq(s.cardRandomRng.counter,0)
 local x=battle({'armaments','strike',inst('searing_blow',true),'dazed'});detach(x,'armaments')
 local all=F.planEffect(x,{op='armaments',all=true});eq(#all.top,2)
end)
test('Armaments selection plan restores selected and excluded cards in source order and rejects changed metadata',function()
 local s=battle({'armaments','dazed','strike','bash'});arrange(s,{'armaments','dazed','strike','bash'});detach(s,'armaments')
 local spec=F.choiceSpec(s,'armaments',1);local strike,bash,dazed=held(s,'strike'),held(s,'bash'),held(s,'dazed')
 local p=F.planChoice(s,spec,strike.uid);eq(p.handOrder[1],bash.uid);eq(p.handOrder[2],strike.uid);eq(p.handOrder[3],dazed.uid)
 strike.upgraded=true;eq(pcall(F.planChoice,s,spec,strike.uid),false)
end)
test('Dual Wield distinguishes auto original retention from selected original replacement',function()
 local s=battle({'dual_wield','strike','defend'});detach(s,'dual_wield')
 local p=F.planEffect(s,{op='dualWield',value=2});eq(p.top[1].effect.value,2);eq(p.top[1].effect.replaceOriginal,false)
 local x=battle({'dual_wield','defend','strike','combust','wound'});arrange(x,{'dual_wield','defend','strike','combust','wound'});detach(x,'dual_wield')
 local spec=F.choiceSpec(x,'dual_wield',1);local strike=held(x,'strike');local result=F.planChoice(x,spec,strike.uid)
 eq(result.top[1].effect.value,2);eq(result.top[1].effect.replaceOriginal,true)
 eq(result.top[1].effect.sourceInstance.uid,strike.uid);assert(result.top[1].effect.sourceInstance~=strike)
 eq(result.handOrder[1],held(x,'combust').uid);eq(result.handOrder[2],held(x,'defend').uid);eq(result.handOrder[3],held(x,'wound').uid)
end)
test('Havoc constructor target RNG is prepared even with empty piles without mutating its source stream',function()
 local s=battle();local prepared,rng=F.prepareEffect(s,{op='havoc'},nil)
 eq(prepared.targetId,s.enemies[1].id);eq(R.snapshot(rng).counter,1);eq(s.cardRandomRng.counter,0)
 local p=F.planEffect(s,prepared);eq(p.top[1].effect.op,'stageHavocCard')
 eq(p.top[1].effect.autoPlay,true);eq(p.top[1].effect.exhaustOnUseOnce,true)
end)
test('Infernal Blade refuses missing or incomplete source pools without sampling an implemented subset',function()
 local s=battle({'infernal_blade'});local counter=s.cardRandomRng.counter
 eq(pcall(F.prepareEffect,s,{op='infernalBlade'},nil),false)
 eq(pcall(F.prepareEffect,s,{op='infernalBlade'},nil,{attackPool={complete=false,cardIds={'strike'}}}),false)
 eq(s.cardRandomRng.counter,counter)
end)
test('Boomerang component reselects current living targets and recomputes modifiers at each hit',function()
 local s=battle({'sword_boomerang'});s.player.statuses.strength=2
 local first=F.planEffect(s,{op='swordBoomerangHit',value=3});eq(first.top[1].effect.normalAmount,5)
 require('abyss_flow_actions').commitRng(s,first.cardRandomRng);eq(s.cardRandomRng.counter,1)
 s.player.statuses.strength=5
 local second=F.planEffect(s,{op='swordBoomerangHit',value=3});eq(second.top[1].effect.normalAmount,8)
 eq(R.snapshot(second.cardRandomRng).counter,2);eq(s.cardRandomRng.counter,1)
end)
test('Double Tap constructor plan captures one purge copy per next Attack and decrements uses immediately',function()
 local s=battle({'strike'});assert(F.applyPower(s,'double_tap',2));local c=held(s,'strike');c.sourceUid=501
 local p=F.prepareUse(s,c,raw(s,c),{targetId=s.enemies[1].id,energyOnUse=3})
 eq(p.powerChanges[1].value,1);eq(#p.cardQueue,1);eq(p.cardQueue[1].immediate,true)
 eq(p.cardQueue[1].sourceUid,501);eq(p.cardQueue[1].copyMode,'same_source')
 eq(p.cardQueue[1].purgeOnUse,true);eq(p.cardQueue[1].autoPlay,true)
 eq(s.player.statuses.double_tap,2) -- A plan has not committed the constructor change.
 c.purgeOnUse=true;eq(#(F.prepareUse(s,c,raw(s,c)).cardQueue or {}),0)
end)
test('Feed component accepts dead nonminions but excludes halfDead and even zero-amount Minion membership',function()
 local t={hp=0,statuses={}};eq(F.feedEligible(t),true)
 t.halfDead=true;eq(F.feedEligible(t),false);t.halfDead=false;t.statuses.minion=0;eq(F.feedEligible(t),false)
end)
test('Juggernaut component triggers positive pre-cap block input and samples a target only on later action execution',function()
 local s=battle();assert(F.applyPower(s,'juggernaut',5));s.player.block=999
 local p=F.onGainedBlock(s,1);eq(#p.bottom,1);eq(p.bottom[1].effect.op,'juggernautRandomDamage');eq(s.cardRandomRng.counter,0)
 eq(#F.onGainedBlock(s,0).bottom,0)
 local attack=F.planEffect(s,p.bottom[1].effect);eq(attack.top[1].effect.op,'finalThornsDamage');eq(R.snapshot(attack.cardRandomRng).counter,1)
 Q.start(s,attack.top);eq(#s.actionQueue.actions,1)
end)
print('WARRIOR_FINAL_COMPONENT_PASS'..n)
test('real Armaments grants five Block then upgrades its only eligible remaining hand card',function()
 local s=battle({'armaments','strike'});local strike=held(s,'strike');play(s,'armaments')
 eq(s.player.block,5);eq(strike.upgraded,true);eq(C.cardDefinition(s,strike).effects[1].value,9);eq(s.energy,2)
end)
test('real Armaments plus upgrades all eligible hand cards and allows Searing Blow to upgrade again',function()
 local s=battle({inst('armaments',true),'strike',inst('searing_blow',true),'dazed'})
 play(s,'armaments');eq(s.player.block,5);eq(held(s,'strike').upgraded,true)
 eq(C.cardDefinition(s,held(s,'searing_blow')).effects[1].value,21)
end)
test('real Havoc uses the original top card for free and exhausts it after native effects',function()
 for _,up in ipairs({false,true}) do
  local s=battle({inst('havoc',up),'strike'});arrange(s,{'havoc'});local original=s.draw[1]
  play(s,'havoc');eq(s.enemies[1].hp,194);eq(s.energy,up and 3 or 2)
  eq(s.exhaust[1],original);eq(s.discard[1].cardId,'havoc');eq(s.cardRandomRng.counter,1)
 end
end)
test('real empty Havoc still spends its constructor target random call',function()
 local s=battle({'havoc'});play(s,'havoc');eq(s.cardRandomRng.counter,1);eq(#s.exhaust,0);eq(#s.discard,1)
end)
test('real Sword Boomerang retargets after an early kill and rolls even for one surviving enemy',function()
 for _,up in ipairs({false,true}) do
  local s=battle({inst('sword_boomerang',up)},{'cultist','cultist'})
  local clone=R.cloneState(s.cardRandomRng);local first=R.randomInt(clone,1)+1;local other=first==1 and 2 or 1
  s.enemies[first].hp=2;play(s,'sword_boomerang')
  eq(s.enemies[first].hp,0);eq(s.enemies[other].hp,up and 191 or 194);eq(s.cardRandomRng.counter,up and 4 or 3)
 end
end)
test('real Dual Wield auto path retains the chosen original and makes the source number of new copies',function()
 for _,up in ipairs({false,true}) do
  local s=battle({inst('dual_wield',up),'strike','defend'});local original=held(s,'strike');play(s,'dual_wield')
  local count,seen=0,{}
  for _,c in ipairs(s.hand) do assert(not seen[c.uid]);seen[c.uid]=true;if c.cardId=='strike' then count=count+1 end end
  eq(count,up and 3 or 2);assert(seen[original.uid]);eq(s.cardRandomRng.counter,0)
 end
end)
test('real Infernal Blade without a complete audited pool refuses atomically instead of returning a subset card',function()
 local s=battle({'infernal_blade'});local card=s.hand[1];local energy=s.energy;local counter=s.cardRandomRng.counter
 local called,result=pcall(C.play,s,card.uid);assert(not called or result==false)
 eq(s.hand[1],card);eq(s.energy,energy);eq(s.cardRandomRng.counter,counter);eq(#s.discard,0);eq(#s.exhaust,0)
end)
test('real Searing Blow keeps multiple permanent upgrades through Run and Combat construction',function()
 local Run=require('abyss_run');local run=Run.new(data,42)
 run.deck={{uid=1,cardId='searing_blow',upgraded=true,timesUpgraded=3}};run.nextDeckUid=2
 assert(Run.startCombat(run,'cultist_solo'));local c=held(run.combat,'searing_blow')
 eq(c.timesUpgraded,3);eq(C.cardDefinition(run.combat,c).effects[1].value,27)
 assert(F.upgradeInstance(run.combat,c));eq(c.timesUpgraded,4);eq(run.deck[1].timesUpgraded,3)
end)
test('real upgraded Double Tap copies each of two Attacks once and does not copy its purge replay recursively',function()
 local s=battle({inst('double_tap',true),'strike','strike'});play(s,'double_tap')
 play(s,'strike',1);eq(s.enemies[1].hp,188);eq(s.player.statuses.double_tap,1)
 play(s,'strike',1);eq(s.enemies[1].hp,176);eq(s.player.statuses.double_tap or 0,0)
 eq(#s.discard,3);eq(#s.exhaust,0);eq(s.cardRandomRng.counter,0)
end)
test('real Feed gains permanent max HP and heals before queued lethal Thorns',function()
 for _,up in ipairs({false,true}) do
  local s=battle({inst('feed',up)});s.enemies[1].hp=1;s.enemies[1].statuses.thorns=2;s.player.hp=1
  local max=s.player.maxHp;play(s,'feed',1)
  eq(s.player.maxHp,max+(up and 4 or 3));eq(s.player.hp,up and 3 or 2);eq(s.phase,'victory');eq(#s.exhaust,1)
 end
end)
test('real Feed cannot gain max HP from a Minion',function()
 local s=battle({'feed'});s.enemies[1].hp=1;s.enemies[1].minion=true;local max=s.player.maxHp
 play(s,'feed',1);eq(s.player.maxHp,max);eq(#s.exhaust,1)
end)
test('real Feed max HP is published to Run after victory rather than lost with the Combat object',function()
 local Run=require('abyss_run');local run=Run.new(data,42)
 run.deck={{uid=1,cardId='feed',upgraded=false}};run.nextDeckUid=2
 assert(Run.startCombat(run,'cultist_solo'));run.combat.enemies[1].hp=1;local max=run.maxHp
 assert(Run.play(run,held(run.combat,'feed').uid,1));eq(run.maxHp,max+3)
 run.phase='map' -- This fixture skips reward presentation, not max-HP propagation.
 assert(Run.startCombat(run,'cultist_solo'));eq(run.combat.player.maxHp,max+3)
end)
test('real Juggernaut follows positive GainBlock calls even when the Block cap absorbs the entire gain',function()
 for _,up in ipairs({false,true}) do
  local s=battle({inst('juggernaut',up),'defend'});play(s,'juggernaut');s.player.block=999
  play(s,'defend');eq(s.player.block,999);eq(s.enemies[1].hp,up and 193 or 195);eq(s.cardRandomRng.counter,1)
 end
end)
test('real Entrench uses the same positive addBlock hook and does not trigger Juggernaut at zero Block',function()
 for _,block in ipairs({0,10}) do
  local s=battle({'juggernaut','entrench'});s.energy=5;play(s,'juggernaut');s.player.block=block
  s.player.statuses.dexterity=10;s.player.statuses.frail=1;play(s,'entrench')
  eq(s.player.block,block*2);eq(s.enemies[1].hp,block>0 and 195 or 200);eq(s.cardRandomRng.counter,block>0 and 1 or 0)
 end
end)
print('WARRIOR_FINAL_BUILD_PASS'..n)
