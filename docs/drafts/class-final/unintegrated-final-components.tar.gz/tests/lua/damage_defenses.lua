package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local Defenses=require('abyss_damage_defenses')
local Defect=require('abyss_defect_final_cards') -- actual production helper, no stub
local Silent=require('abyss_silent_final_cards')
local count=0
local function eq(a,b,label)assert(a==b,(label or 'value')..': '..tostring(a)..' ~= '..tostring(b))end
local function test(name,fn)fn();count=count+1;print('ok damage defenses '..count..' - '..name)end
local function fresh()
 local p={id='player',hp=20,maxHp=20,block=0,statuses={}}
 local e={id='enemy',hp=30,maxHp=30,block=0,statuses={}}
 return {phase='player',player=p,enemies={e}},p,e
end
test('IntangiblePlayer source priority is75 and info preserves actual owner identity',function()
 local s,p,e=fresh();eq(Defenses.intangiblePriority,75)
 local info=Defenses.info(e,p,'NORMAL');eq(info.owner,e);eq(info.target,p);eq(info.type,'NORMAL')
end)
for _,kind in ipairs({'NORMAL','THORNS','HP_LOSS'})do
 test(kind..' Intangible caps before Block including zero-stack presence',function()
  local s,p,e=fresh();p.statuses.intangible=0;p.block=5
  local record=Defenses.info(e,p,kind);local plan=Defenses.planHit(s,record,12)
  eq(plan.beforeBlock,1);eq(plan.blocked,kind=='HP_LOSS'and 0 or 1)
  eq(plan.blockAfter,kind=='HP_LOSS'and 5 or 4);eq(plan.amount,kind=='HP_LOSS'and 1 or 0)
  eq(p.hp,20);eq(p.block,5);eq(p.statuses.intangible,0);eq(#plan.top,0)
 end)
 test(kind..' positive postBlock Buffer suppresses damage and queues exactly one TOP reduction',function()
  local s,p,e=fresh();p.statuses.buffer=2;p.statuses.static_discharge=3;p.block=3
  local record=Defenses.info(e,p,kind);local plan=Defenses.planHit(s,record,12)
  eq(plan.postBlock,kind=='HP_LOSS'and 12 or 9);eq(plan.amount,0);eq(#plan.top,1)
  eq(plan.top[1].op,'reduceDefectPower');eq(plan.top[1].status,'buffer');eq(plan.top[1].value,1)
  eq(p.statuses.buffer,2,'plan must not consume the Power inline');eq(p.hp,20);eq(p.block,3)
 end)
 test(kind..' zero damage does not consume Buffer or create Static channel',function()
  local s,p,e=fresh();p.statuses.buffer=1;p.statuses.static_discharge=3
  local plan=Defenses.planHit(s,Defenses.info(e,p,kind),0)
  eq(plan.amount,0);eq(#plan.top,0);eq(p.statuses.buffer,1)
 end)
end

test('full Block leaves Buffer untouched, then a later positive hit can consume it',function()
 local s,p,e=fresh();p.block=10;p.statuses.buffer=1
 local first=Defenses.planHit(s,Defenses.info(e,p,'NORMAL'),7)
 eq(first.blocked,7);eq(first.amount,0);eq(#first.top,0)
 p.block=first.blockAfter
 local second=Defenses.planHit(s,Defenses.info(e,p,'NORMAL'),7)
 eq(second.postBlock,4);eq(second.amount,0);eq(#second.top,1);eq(p.statuses.buffer,1)
end)
test('Buffer zero-stack Power still blocks and schedules its source reduction/removal',function()
 local s,p,e=fresh();p.statuses.buffer=0
 local plan=Defenses.afterBlock(s,Defenses.info(nil,p,'HP_LOSS'),4)
 eq(plan.amount,0);eq(plan.top[1].status,'buffer');eq(plan.top[1].value,1);eq(p.statuses.buffer,0)
end)
test('Static external positive NORMAL creates the actual Defect descriptor before HP deduction',function()
 local s,p,e=fresh();p.statuses.static_discharge=2;p.block=3
 local plan=Defenses.planHit(s,Defenses.info(e,p,'NORMAL'),7)
 eq(plan.amount,4);eq(#plan.top,1);eq(plan.top[1].op,'engineChannelRounds')
 eq(plan.top[1].orb,'lightning');eq(plan.top[1].remaining,2);eq(p.hp,20)
 eq(Defenses.mayExecuteQueued(s),true)
end)
test('Static excludes self, null owner, THORNS and HP_LOSS without a channel',function()
 for _,case in ipairs({{'NORMAL','self'},{'NORMAL','null'},{'THORNS','external'},{'HP_LOSS','external'}})do
  local s,p,e=fresh();p.statuses.static_discharge=2
  local owner=case[2]=='self'and p or(case[2]=='external'and e or nil)
  local plan=Defenses.afterBlock(s,Defenses.info(owner,p,case[1]),7);eq(plan.amount,7);eq(#plan.top,0)
 end
end)
test('non-player target bypasses these player-only Power adapters',function()
 local s,p,e=fresh();p.statuses.intangible=3;p.statuses.buffer=1;p.statuses.static_discharge=3
 e.block=2;local plan=Defenses.planHit(s,Defenses.info(p,e,'NORMAL'),9)
 eq(plan.beforeBlock,9);eq(plan.amount,7);eq(#plan.top,0);eq(p.statuses.buffer,1)
end)
test('all three effects compose: Block resolves before Buffer and prevents Static',function()
 local s,p,e=fresh();p.statuses.intangible=2;p.statuses.buffer=1;p.statuses.static_discharge=2
 local plan=Defenses.planHit(s,Defenses.info(e,p,'NORMAL'),15)
 eq(plan.beforeBlock,1);eq(plan.postBlock,1);eq(plan.amount,0);eq(#plan.top,1);eq(plan.top[1].status,'buffer')
 p.block=1;plan=Defenses.planHit(s,Defenses.info(e,p,'NORMAL'),15)
 eq(plan.blocked,1);eq(plan.postBlock,0);eq(#plan.top,0)
end)
test('lethal Static hit only plans channel; death and terminal phases disallow execution',function()
 local s,p,e=fresh();p.hp=3;p.statuses.static_discharge=2
 local plan=Defenses.planHit(s,Defenses.info(e,p,'NORMAL'),5);eq(plan.amount,5);eq(#plan.top,1);eq(p.hp,3)
 p.hp=0;eq(Defenses.mayExecuteQueued(s),false)
 p.hp=3;s.phase='defeat';eq(Defenses.mayExecuteQueued(s),false)
 s.phase='victory';eq(Defenses.mayExecuteQueued(s),false)
 s.phase='enemy';e.hp=0;eq(Defenses.mayExecuteQueued(s),false)
 e.hp=30;eq(Defenses.mayExecuteQueued(s),true)
end)
test('queue predicate includes zero-layer Buffer and only eligible Static incoming hits',function()
 local s,p,e=fresh();eq(Defenses.needsQueue(s),false)
 p.statuses.intangible=2;eq(Defenses.needsQueue(s),false)
 p.statuses.buffer=0;eq(Defenses.needsQueue(s),true);p.statuses.buffer=nil
 p.statuses.static_discharge=1;eq(Defenses.needsQueue(s),true)
 eq(Defenses.needsQueue(s,Defenses.info(e,p,'NORMAL')),true)
 eq(Defenses.needsQueue(s,Defenses.info(e,p,'THORNS')),false)
 eq(Defenses.needsQueue(s,Defenses.info(nil,p,'NORMAL')),false)
end)
test('invalid DamageType and unsafe amounts refuse without mutating actors',function()
 local s,p,e=fresh();p.statuses.buffer=1;p.block=5
 for _,n in ipairs({-1,0.5,2147483648,'3'})do assert(not pcall(Defenses.planHit,s,Defenses.info(e,p,'NORMAL'),n))end
 assert(not pcall(Defenses.info,e,p,'HPLOSS'))
 eq(p.hp,20);eq(p.block,5);eq(p.statuses.buffer,1)
end)
test('stage delegation matches the exact existing Final helpers, not parallel mechanics',function()
 local s,p,e=fresh();p.statuses.intangible=1;p.statuses.static_discharge=3
 eq(Defenses.beforeBlock(s,Defenses.info(e,p,'NORMAL'),8),Silent.capIncomingDamage(s,p,8))
 local expected=Defect.incomingPlan(s,Defenses.info(e,p,'NORMAL'),4)
 local actual=Defenses.afterBlock(s,Defenses.info(e,p,'NORMAL'),4)
 eq(actual.amount,expected.amount);eq(actual.top[1].op,expected.top[1].op);eq(actual.top[1].remaining,expected.top[1].remaining)
end)
print('DAMAGE_DEFENSES_COMPONENT_PASS '..count)
