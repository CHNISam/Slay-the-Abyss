package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local Identity=require('abyss_card_identity')
local Combat=require('abyss_combat')
local Snapshot=require('abyss_snapshot')
local Data=require('abyss_data')
local n=0
local function eq(a,b)assert(a==b,tostring(a)..' ~= '..tostring(b))end
local function test(name,fn)fn();n=n+1;print('ok card_identity '..n..' - '..name)end
local function battle(deck)
 local s=Combat.new(Data,{seed=42,cardRandomSeed='42',enemies={'cultist'},deck=deck or {}})
 -- Isolate explicit identity initialization from the integrated Core.new entry.
 s.cardIdentity=nil;s.nextSourceUid=nil;return s
end
local function master(uid,id,extra)local c={uid=uid,cardId=id or 'strike',upgraded=false};for k,v in pairs(extra or {})do c[k]=v end;return c end
local function setup(deck)local s=battle();Identity.init(s,deck or {});return s end
local function attach(s,c,pile)s[pile or 'hand']=s[pile or 'hand']or {};s[pile or 'hand'][#s[pile or 'hand']+1]=c;return c end
local function sameGraph(s)
 local saved,waiting={}, {s}
 while #waiting>0 do local t=table.remove(waiting);if not saved[t]then local values={};saved[t]=values
  for k,v in pairs(t)do values[k]=v;if type(v)=='table'then waiting[#waiting+1]=v end end end end
 return function()for t,v in pairs(saved)do for k,x in pairs(t)do eq(v[k],x)end;for k,x in pairs(v)do eq(t[k],x)end end end
end
local function copy(v)if type(v)~='table'then return v end;local t={};for k,x in pairs(v)do t[k]=copy(x)end;return t end
local function plain(v,path)if type(v)=='table'then path=path or {};assert(not path[v]and not getmetatable(v));path[v]=true
 for k,x in pairs(v)do assert(type(k)=='string'or type(k)=='number');plain(x,path)end;path[v]=nil
 else assert(type(v)=='string'or type(v)=='number'or type(v)=='boolean')end end
test('empty init is idempotent and neither creates cards nor changes combat allocator',function()
 local s=battle();local uid=s.nextUid;assert(Identity.init(s,{}));eq(s.nextUid,uid);eq(s.nextSourceUid,1)
 local meta=s.cardIdentity;local sources=meta.sources;local same=sameGraph(s)
 assert(Identity.init(s,{}));eq(s.cardIdentity,meta);eq(meta.sources,sources);same()
end)
test('twelve-card sparse permanent IDs reserve all source IDs independently of combat thirteen',function()
 local deck,ids={},{};for i=1,11 do deck[#deck+1]=master(i);ids[#ids+1]='strike'end;deck[#deck+1]=master(20);ids[#ids+1]='strike'
 local s=battle(ids);eq(s.nextUid,13);Identity.init(s,deck);eq(s.nextSourceUid,21)
 local c=Identity.created(s,{cardId='strike'},'new');eq(c.uid,13);eq(c.sourceUid,21);eq(s.nextSourceUid,22)
 eq(s.cardIdentity.sources[20],true);eq(s.cardIdentity.sources[13],nil)
end)
test('combat thirteen may equal a reserved permanent source thirteen without namespace collision',function()
 local deck={master(13),master(20)};local s=setup(deck);s.nextUid=13
 local c=Identity.created(s,{cardId='strike'},'new');eq(c.uid,13);eq(c.sourceUid,21)
 local from=Identity.fromMaster(s,deck[1]);eq(from.uid,14);eq(from.sourceUid,13);assert(c.sourceUid~=from.sourceUid)
end)
test('init scans already known source UIDs without inferring any source UID from combat UID',function()
 local s=battle({'strike','defend'});s.hand[1].uid=700;s.hand[1].sourceUid=99;s.hand[2].uid=800;s.nextUid=801
 Identity.init(s,{master(20)});eq(s.nextSourceUid,100);eq(s.cardIdentity.sources[700],nil);eq(s.cardIdentity.sources[800],nil)
end)
test('an existing higher source counter is preserved across init and purge history',function()
 local s=battle();s.nextSourceUid=101;Identity.init(s,{master(20)});eq(s.nextSourceUid,101)
 local c=Identity.created(s,{cardId='strike'},'new');eq(c.sourceUid,101);eq(s.nextSourceUid,102)
 local same=sameGraph(s);Identity.init(s,{master(20)});same()
end)
test('new constructor and stat-equivalent copies allocate separate source and combat identities',function()
 local s=setup({master(20)});local a=attach(s,Identity.created(s,{cardId='strike'},'new'))
 local b=Identity.created(s,a,'new');eq(a.uid,1);eq(b.uid,2);eq(a.sourceUid,21);eq(b.sourceUid,22)
end)
test('same-instance copy inherits reserved source identity but gets a distinct runtime UID',function()
 local s=setup({master(20)});local original=attach(s,Identity.created(s,{cardId='strike'},'new'))
 local nextSource=s.nextSourceUid;local c=Identity.created(s,original,'same');eq(c.sourceUid,original.sourceUid);assert(c.uid~=original.uid);eq(s.nextSourceUid,nextSource)
end)
test('same copy refuses missing source UID unowned snapshots or invented source identity',function()
 local s=battle({'strike'});s.hand[1].sourceUid=nil;Identity.init(s,{});local c=s.hand[1];local same=sameGraph(s)
 eq(pcall(Identity.created,s,c,'same'),false);same()
 local real=attach(s,Identity.created(s,{cardId='defend'},'new'));local snapshot=copy(real);same=sameGraph(s)
 eq(pcall(Identity.created,s,snapshot,'same'),false);same()
 real.sourceUid=999;local changed=sameGraph(s);eq(pcall(Identity.created,s,real,'same'),false);changed()
end)
test('fromMaster preserves permanent source UID misc upgrade count and upgrade flag',function()
 local p=master(20,'strike',{misc=7,timesUpgraded=2,upgraded=true});local s=setup({p});local same=sameGraph(p)
 local c=Identity.fromMaster(s,p);eq(c.uid,1);eq(c.sourceUid,20);eq(c.misc,7);eq(c.timesUpgraded,2);eq(c.upgraded,true);assert(c~=p);same()
end)
test('fromMaster never consumes the new-source allocator or copies the permanent UID as combat UID',function()
 local p=master(100);local s=setup({p});s.nextUid=13;local source=s.nextSourceUid
 local c=Identity.fromMaster(s,p);eq(c.uid,13);eq(c.sourceUid,100);eq(s.nextSourceUid,source)
end)
test('unregistered permanent cards and conflicting permanent source fields refuse atomically',function()
 local p=master(20);local s=setup({p});local same=sameGraph(s)
 eq(pcall(Identity.fromMaster,s,master(21)),false);eq(pcall(Identity.fromMaster,s,master(20,'defend')),false);same()
 p.sourceUid=21;same=sameGraph(s);eq(pcall(Identity.fromMaster,s,p),false);same()
end)
test('stat-copy whitelist preserves current modifiers and Expunger hits without transient flags',function()
 local s=setup();local source={cardId='strike',upgraded=true,timesUpgraded=1,misc=5,combatCost=2,turnCost=0,damageBonus=4,
  storedDiscardCost=2,retainedDamageBonus=3,retainedBlockBonus=2,retainedCostReduction=1,shivAccuracyBonus=4,expungerHits=7,
  freeToPlayOnce=true,inBottleFlame=true,retain=true,retainedTurn=9,ethereal=true,exhaust=true,exhaustOnUseOnce=true,purgeOnUse=true,
  dontTriggerOnUseCard=true,isInAutoplay=true,ignoreEnergyOnUse=true,energyOnUse=3}
 local c=Identity.created(s,source,'new')
 for _,k in ipairs({'misc','timesUpgraded','combatCost','turnCost','damageBonus','storedDiscardCost','retainedDamageBonus','retainedBlockBonus','retainedCostReduction','shivAccuracyBonus','expungerHits','freeToPlayOnce','inBottleFlame'})do eq(c[k],source[k])end
 for _,k in ipairs({'retain','retainedTurn','ethereal','exhaust','exhaustOnUseOnce','purgeOnUse','dontTriggerOnUseCard','isInAutoplay','ignoreEnergyOnUse','energyOnUse'})do eq(c[k],nil)end
end)
test('unknown stat fields invalid flags and inconsistent counts are preflight failures',function()
 for _,t in ipairs({{cardId='strike',futureStat=7},{cardId='strike',retain=1},{cardId='strike',misc=2147483648.0},
  {cardId='strike',upgraded=false,timesUpgraded=1},{cardId='strike',upgraded=true,timesUpgraded=0},
  {cardId='strike',expungerHits=-1},{cardId='strike',turnCost=-3}})do
  local s=setup();local same=sameGraph(s);eq(pcall(Identity.created,s,t,'new'),false);same()
 end
end)
test('both allocators legally cross signed 32-bit boundary independently',function()
 local s=setup();s.nextUid=2147483647.0;s.nextSourceUid=2147483647.0
 local a=Identity.created(s,{cardId='strike'},'new');eq(a.uid,2147483647.0);eq(a.sourceUid,2147483647.0);attach(s,a)
 local b=Identity.created(s,a,'new');eq(b.uid,2147483648.0);eq(b.sourceUid,2147483648.0)
 eq(s.nextUid,2147483649.0);eq(s.nextSourceUid,2147483649.0)
end)
test('large permanent and already known source IDs initialize without 32-bit truncation',function()
 local s=battle({'strike'});s.hand[1].sourceUid=4294967300.0;Identity.init(s,{master(4294967298.0)})
 eq(s.nextSourceUid,4294967301.0);eq(Identity.allocateSourceUid(s),4294967301.0)
end)
test('NaN infinity fractional nonpositive and nonincrementable counters are atomic failures',function()
 for _,value in ipairs({0,-1,0.5,0/0,math.huge,9007199254740992.0})do
  for _,key in ipairs({'nextUid','nextSourceUid'})do
   local s=setup();s[key]=value
   local priorUid,priorSource,meta=s.nextUid,s.nextSourceUid,s.cardIdentity
   eq(pcall(Identity.created,s,{cardId='strike'},'new'),false)
   assert(s.nextUid==priorUid or s.nextUid~=s.nextUid and priorUid~=priorUid)
   assert(s.nextSourceUid==priorSource or s.nextSourceUid~=s.nextSourceUid and priorSource~=priorSource);eq(s.cardIdentity,meta)
  end
 end
end)
test('rewound counters never skip gaps or silently repair allocation collisions',function()
 local s=setup({master(20)});local c=Identity.created(s,{cardId='strike'},'new');attach(s,c)
 s.nextUid=c.uid;local same=sameGraph(s);eq(pcall(Identity.allocateCombatUid,s),false);same()
 s.nextUid=c.uid+1.0;s.nextSourceUid=13;same=sameGraph(s);eq(pcall(Identity.allocateSourceUid,s),false);same()
end)
test('allocated but unattached identities remain reserved after simulated purge',function()
 local s=setup();local a=Identity.created(s,{cardId='strike'},'new');eq(a.sourceUid,1)
 s.nextSourceUid=1;local same=sameGraph(s);eq(pcall(Identity.created,s,{cardId='strike'},'new'),false);same()
 s.nextSourceUid=2;s.nextUid=1;same=sameGraph(s);eq(pcall(Identity.allocateCombatUid,s),false);same()
end)
test('lookup traverses four piles limbo and using object once in stable order',function()
 local p=master(20);local s=setup({p});local original=attach(s,Identity.fromMaster(s,p),'hand');local expected={original}
 for _,pile in ipairs({'draw','discard','exhaust','limbo'})do local c=attach(s,Identity.created(s,original,'same'),pile);expected[#expected+1]=c end
 s.cardInUse=original
 local found=Identity.allBattleInstancesBySourceUid(s,20);eq(#found,5);for i,c in ipairs(expected)do eq(found[i],c)end
 eq(#Identity.allBattleInstancesBySourceUid(s,21),0)
end)
test('lookup and allocation reject equal runtime UID on different objects but allow object aliases',function()
 local s=setup();local c=attach(s,Identity.created(s,{cardId='strike'},'new'));s.limbo={c};s.cardInUse=c
 eq(#Identity.allBattleInstancesBySourceUid(s,c.sourceUid),1)
 s.limbo={copy(c)};local same=sameGraph(s);eq(pcall(Identity.allBattleInstancesBySourceUid,s,c.sourceUid),false);same()
 eq(pcall(Identity.allocateCombatUid,s),false);same()
end)
test('duplicate sparse permanent lists and counter conflicts fail before identity init writes',function()
 local s=battle();local same=sameGraph(s);eq(pcall(Identity.init,s,{master(20),master(20)}),false);same()
 eq(pcall(Identity.init,s,{[1]=master(20),[3]=master(21)}),false);same()
 s.nextSourceUid=13;local changed=sameGraph(s);eq(pcall(Identity.init,s,{master(20)}),false);changed();eq(s.cardIdentity,nil)
end)
test('init idempotence refuses changing permanent source mappings midway through battle',function()
 local s=setup({master(20)});local same=sameGraph(s)
 eq(pcall(Identity.init,s,{master(20,'defend')}),false);same()
 eq(pcall(Identity.init,s,{}),false);same()
end)
test('serialization restores counters and source lineage without original object addresses',function()
 local p=master(20);local s=setup({p});local original=attach(s,Identity.fromMaster(s,p));attach(s,Identity.created(s,original,'same'),'discard')
 plain(s.cardIdentity);local restored=copy(s);Identity.init(restored,{copy(p)})
 local found=Identity.allBattleInstancesBySourceUid(restored,20);eq(#found,2);assert(found[1]~=original)
 local next=Identity.created(restored,found[1],'new');eq(next.sourceUid,21);eq(s.nextSourceUid,21)
end)
test('whole graph rollback restores counters reservations objects and metadata references',function()
 local s=setup({master(20)});local original=attach(s,Identity.fromMaster(s,master(20)));local same=sameGraph(s);local meta=s.cardIdentity
 local restore=Snapshot.capture(s);local c=attach(s,Identity.created(s,original,'same'),'limbo');attach(s,Identity.created(s,c,'new'),'discard')
 restore();same();eq(s.cardIdentity,meta);eq(s.limbo,nil);eq(#s.discard,0);eq(s.hand[1],original)
end)
test('no callbacks metatables or cyclic data enter identity templates',function()
 local cycle={cardId='strike'};cycle.loop=cycle
 for _,c in ipairs({{cardId='strike',callback=function()end},setmetatable({cardId='strike'},{}),cycle})do
  local s=setup();local same=sameGraph(s);eq(pcall(Identity.created,s,c,'new'),false);same()
 end
end)
print('CARD_IDENTITY_COMPONENT_PASS '..n)
print('CARD_IDENTITY_CORE_NOT_CONNECTED: host must stamp actual construction and generation sites')
